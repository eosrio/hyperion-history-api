import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {mkdirSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const repo=process.argv[2],load=path=>import(pathToFileURL(join(repo,path)).href);
const fixture=fileURLToPath(new URL('./main-source-await-controlled-config/',import.meta.url));
mkdirSync(join(fixture,'config'),{recursive:true});
writeFileSync(join(fixture,'chain.json'),JSON.stringify({settings:{chain:'controlled',eosio_alias:'sysio'},indexer:{},features:{},scaling:{},api:{}}));
writeFileSync(join(fixture,'config/connections.json'),'{}');
process.env.CONFIG_JSON=join(fixture,'chain.json');process.chdir(fixture);
const {default:MainDS}=await load('build/indexer/workers/deserializer.js');
const {ProofConsumerScope}=await load('build/indexer/protocol/proof-consumer-scope.js');
const {ProtocolSourceBindingReadError}=await load('build/indexer/protocol/source-bindings.js');
let enter,release;const entered=new Promise(yes=>{enter=yes;}),held=new Promise(yes=>{release=yes;});
const effects=[],worker=Object.create(MainDS.prototype),message={content:Buffer.from('retained original bytes'),
    properties:{headers:{'x-hyperion-source-selection':'h45srcsel1:'+ '1'.repeat(64)}}};
const channel={ack(){effects.push('ack');}};
Object.assign(worker,{protocolReady:Promise.resolve(),protocolDeliveryOwners:new WeakMap([[message,channel]]),
    protocolId:'wire',protocol:{profileId:'controlled'},protocolComponents:[],chainId:'c'.repeat(64),
    ch:channel,ch_ready:true,profiler:{start(){return ()=>{};}},protocolSourceBindingStore:{
        async readSelection(){enter();await held;throw new ProtocolSourceBindingReadError('missing','selection','h45srcsel1:'+ '1'.repeat(64),'controlled held selection');},
        async quarantine(){effects.push('quarantine');return {id:'controlled-existing-store'};}
    }});
const {protocolSourceSelectionHeader}=await load('build/indexer/protocol/source-bindings.js');
message.properties.headers={[protocolSourceSelectionHeader]:'h45srcsel1:'+ '1'.repeat(64)};
const scope=new ProofConsumerScope('root-held-main-source-read');
const work=scope.run(()=>worker.processProtocolSourceDelivery(message,async()=>{effects.push('processBound');}));
void work.catch(()=>{});await entered;scope.fence();release();
const result=await Promise.allSettled([work]);await scope.closeAndDrain();
console.log(JSON.stringify({case:'actual-main-source-await-fence',effects,result:result.map(x=>({status:x.status,reason:String(x.reason??'')}))}));
assert.deepEqual(effects,[],'a fenced actual MainDS source lookup cannot start fresh durable quarantine after its retained selection read rejects');
