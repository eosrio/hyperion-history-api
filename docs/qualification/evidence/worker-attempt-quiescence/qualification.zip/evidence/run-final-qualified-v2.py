from pathlib import Path
import subprocess,os,json,hashlib,time,sys
sys.stdout.reconfigure(encoding='utf8')
root=Path(r'C:/Users/igorl/AppData/Local/Temp/hapi-settlement-277-6vj2lav7');repo=root/'qualification';expected=sys.argv[1]
out=root/'qualification-evidence'/('final-'+expected[:8]);out.mkdir(exist_ok=False);sha=lambda data:hashlib.sha256(data).hexdigest()
node22=Path(r'P:/eosrio/hyperion-tools/out/sequence-coverage/runtimes/node-v22.23.3-win-x64/node.exe');node24=Path(r'C:/Users/igorl/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe');bun=Path(r'C:/Users/igorl/AppData/Local/Temp/wire-workers-270-hwvxai73/runtimes/bun144-windows-x64/bun.exe');npm=Path(r'C:/Program Files/nodejs/node_modules/npm/bin/npm-cli.js')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==expected
tests=['tests/unit/worker-attempt-quiescence.test.ts','tests/unit/worker-attempt-quiescence-worker.mjs','tests/unit/worker-attempt-ipc.mjs','tests/unit/worker-attempt-ipc-child.mjs']
names=subprocess.check_output(['git','ls-files','src','packages','package.json','package-lock.json','tsconfig.json','tests/unit/action-attempt-disposition-worker.mjs','tests/unit/protocol-frontier-memory.mjs'],cwd=repo,text=True).splitlines()
def source():return {rel:sha((repo/rel).read_bytes()) for rel in names+tests if (repo/rel).is_file()}
initial=source();test_rows=[]
for rel in tests:
    data=(repo/rel).read_bytes();target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);test_rows.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
changed=subprocess.check_output(['git','diff','--name-only','65c3b46d3161257b00ceac21a27e98ed600e1c16',head],cwd=repo,text=True).splitlines()
canonical=[]
for rel in changed:
    if not rel.startswith('src/') or not (repo/rel).is_file():continue
    data=subprocess.check_output(['git','show',head+':'+rel],cwd=repo);raw=(repo/rel).read_bytes();target=out/'product'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    canonical.append({'path':rel,'canonicalSha256':sha(data),'rawSha256':sha(raw),'canonicalBytes':len(data),'rawBytes':len(raw)})
rows=[];emissions={};matrix=[]
commands=[('native22-build',node22,[str(node22),str(npm),'run','build']),('whole-project-check',node22,[str(bun),'check','-p','tsconfig.json']),('native22-focused',node22,[str(bun),'test','tests/unit/worker-attempt-quiescence.test.ts']),('native24-build',node24,[str(node24),str(npm),'run','build']),('native24-focused',node24,[str(bun),'test','tests/unit/worker-attempt-quiescence.test.ts'])]
for name,node,cmd in commands:
    env=os.environ.copy();env['PATH']=str(node.parent)+os.pathsep+str(bun.parent)+os.pathsep+env.get('PATH','');env['HYPERION_NATIVE_NODE']=str(node)
    for key in ('NODE_OPTIONS','NODE_PATH','BUN_OPTIONS'):env.pop(key,None)
    if name.endswith('-focused'):
        capture=out/(name+'-raw');capture.mkdir();env['HYPERION_QUALIFICATION_OUTPUT']=str(capture)
    before=source();started=time.monotonic();p=subprocess.run(cmd,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    log=out/(name+'.log');log.write_bytes(p.stdout);after=source();assert before==after==initial;assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==expected
    row={'name':name,'command':cmd,'nativeNode':str(node),'nativeNodeVersion':subprocess.check_output([str(node),'--version'],text=True).strip(),'nativeNodeSha256':sha(node.read_bytes()),'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-started,'log':log.name,'logSha256':sha(p.stdout),'sourceBefore':before,'sourceAfter':after};rows.append(row)
    (out/'command-checkpoint.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print(json.dumps({'name':name,'exitCode':p.returncode,'elapsedSeconds':row['elapsedSeconds']}),flush=True);print(p.stdout.decode(errors='replace')[-900:],flush=True)
    assert p.returncode==0
    if name.endswith('-build'):
        emitted={str(path.relative_to(repo)).replace('\\','/'):sha(path.read_bytes()) for path in sorted((repo/'build').rglob('*.js'))}
        emitted.update({str(path.relative_to(repo)).replace('\\','/'):sha(path.read_bytes()) for path in sorted((repo/'packages/backend-mongodb/dist').rglob('*.js'))})
        emission={'nativeBuild':name,'modules':emitted};manifest=out/(name+'-emitted.json');manifest.write_bytes((json.dumps(emission,indent=2)+'\n').encode());emissions[name]={'manifest':manifest.name,'sha256':sha(manifest.read_bytes())}
        for rel in canonical:
            js=rel['path'].replace('src/','build/',1).replace('.ts','.js')
            if not (repo/js).is_file():continue
            target=out/name/js;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((repo/js).read_bytes())
    if name.endswith('-focused'):
        logs=[]
        for stdout in sorted(capture.glob('*.stdout.log')):
            stderr=stdout.with_name(stdout.name.replace('.stdout.log','.stderr.log'));assert stderr.read_bytes()==b''
            result=json.loads(stdout.read_bytes().decode().splitlines()[-1]);assert result['passed']
            observations=[]
            for case in result['cases']:
                reduced={key:value for key,value in case.items() if key not in ('reads','summary')};observations.append(reduced)
            matrix.append({'runtime':row['nativeNodeVersion'],'mode':result['mode'],'cases':observations,'stdout':str(stdout.relative_to(out)).replace('\\','/'),'stdoutSha256':sha(stdout.read_bytes()),'stderrSha256':sha(stderr.read_bytes())})
        assert len(list(capture.glob('*.stdout.log')))==23

comparison=[]
for label in ['native22','native24']:
    baseline=json.loads((root/'qualification-evidence/cache-baseline-f80'/('node'+label[-2:]+'.measurement.json')).read_text())
    current=json.loads((out/(label+'-focused-raw/local-wire-cache.stdout.log')).read_text().splitlines()[-1])['cases'][0]
    for key in ['originalArchiveSha256','original36FrameSha256','transactionId','traceOrdinal','dispatchPayloadSha256','deliveryTags','outputNames','acknowledgments']:
        assert baseline[key]==current[key],key
    for payloads in [baseline['outputPayloadSha256'],current['outputPayloadSha256']]:assert payloads[0]==payloads[2] and payloads[1]==payloads[3]
    b={(value['stage'],value['index'],value['family']):value for value in baseline['summary']};c={(value['stage'],value['index'],value['family']):value for value in current['summary']};families=[]
    for key in sorted(b.keys()|c.keys()):
        old=b.get(key,{});new=c.get(key,{});families.append({'stage':key[0],'index':key[1],'family':key[2],'baseline':old,'final':new,'deltaGET':new.get('getCalls',0)-old.get('getCalls',0),'deltaSuccessfulReturnedJsonBytes':new.get('successfulReturnedJsonBytes',0)-old.get('successfulReturnedJsonBytes',0)})
    comparison.append({'runtime':label,'sameLogicalInputAndCargo':True,'twoIndependentPhysicalReceipts':True,'withinRunDuplicateOutputsExact':True,'crossRunOutputMetadataExpectedToDiffer':True,'crossRunRawOutputByteEqualityClaim':False,'byteDefinition':current['byteDefinition'],'networkOrThroughputClaim':False,'families':families})
(out/'cache-comparison.json').write_bytes((json.dumps(comparison,indent=2)+'\n').encode())
(out/'case-matrix.json').write_bytes((json.dumps(matrix,indent=2)+'\n').encode())
packet={'createdBy':'windows:codex:hyperion-tools','productHead':head,'productTree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip(),'tests':test_rows,'canonicalProductSources':canonical,'commands':rows,'emissions':emissions,'bunVersion':subprocess.check_output([str(bun),'--version'],text=True).strip(),'bunSha256':sha(bun.read_bytes()),'caseMatrixSha256':sha((out/'case-matrix.json').read_bytes()),'cacheComparisonSha256':sha((out/'cache-comparison.json').read_bytes()),'remainingGates':['No reader capacity activation or count/byte/restart/retention settlement','No complete unchanged original1..1480 Linux Wire/Mongo qualification','Root still owns fullsuite once, independent review and PR/CI'],'scope':'23 focused actual-class/nativeIPC wrappers per native22/24; raw individual observations retained; no fullsuite/services/deployment'}
(out/'packet.json').write_bytes((json.dumps(packet,indent=2)+'\n').encode());print(json.dumps({'packet':str(out/'packet.json'),'sha256':sha((out/'packet.json').read_bytes()),'observedSchedules':sum(len(value['cases']) for value in matrix)}),flush=True)
