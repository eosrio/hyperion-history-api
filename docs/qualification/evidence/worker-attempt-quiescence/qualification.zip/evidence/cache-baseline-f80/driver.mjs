/** Original Wire frames through emitted reader/MainDS/DS/admission and the normal installed native provider.
 * Public admission remains disabled. This fixture explicitly enables its existing engineering seam;
 * broker confirms, cache and ES transports are controlled. No live-service or consensus qualification. */
import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {basename, dirname, join, resolve} from 'node:path';
import {EventEmitter} from 'node:events';
import {createHash} from 'node:crypto';
import {frontierMemoryClient} from "file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/tests/unit/protocol-frontier-memory.mjs";

import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
let nativeAddonResolutions = 0;
const hooks = registerHooks({resolve(specifier, context, next) {
    if (specifier.includes('node-abieos')) {nativeAddonResolutions++; throw new Error('Wire admission resolved the Antelope native addon');}
    return next(specifier, context);
}});
const previousDirectory = process.cwd(), previousSend = process.send;
const directory = mkdtempSync(join(tmpdir(), 'hyperion-attempt-worker-original-'));
const chain = 'handoff-worker-original', chainId = '9ccd94e823fda51363bd4265ad618a909c4985c445078c79f8d030fe9697b71d', blockId = number => number.toString(16).padStart(64, '0');
const hash = value => createHash('sha256').update(value).digest('hex');
const mode = process.argv[2] ?? 'lifecycle';
const events = [], sourceFrames = [], blockWrites = [], cache = [];
let reader, coordinator, draining = Promise.resolve();
process.send = (event, callback) => {
    events.push(event);
    if (event.event === 'protocol_abi_prepared') draining = coordinator.drain();
    callback?.(null); return true;
};
class ControlledConsumer extends EventEmitter {
    acked = [];
    streamed = [];
    onAck;
    ack(message) {this.onAck?.(message); this.acked.push(message);}
    publish(_exchange, queue, payload, options) {this.streamed.push({queue, payload: Buffer.from(payload), options: structuredClone(options)}); return true;}
}
class ControlledPublisher extends EventEmitter {
    sent = [];
    held;
    entered;
    automatic = true;
    writable = true;
    sendToQueue(queue, payload, options, confirm) {
        this.sent.push({queue, payload: Buffer.from(payload), options: structuredClone(options), confirm});
        if (!this.automatic) return this.writable;
        if (this.held) {this.entered?.(); this.held.then(() => confirm());}
        else queueMicrotask(() => confirm()); return this.writable;
    }
}
function message(sent) {return {content: Buffer.from(sent.payload), properties: {headers: structuredClone(sent.options.headers)}, fields: {deliveryTag: 1}};}
async function ticks() {for (let index = 0; index < 5; index++) await new Promise(resolve => setImmediate(resolve));}
function gate() {let release; const held = new Promise(resolve => {release = resolve;}); return {held, release};}
async function until(test, label) {const deadline = Date.now() + 5000; while (!test()) {assert(Date.now() < deadline, label); await ticks();}}
function ids(memory, prefix) {
    return [...memory.documents.values()].map(value => value.document)
        .filter(value => value.kind === 'manifest' && value.bundle_id.startsWith(prefix)).map(value => value.bundle_id);
}
function retained(memory, index, id) {
    const manifest = memory.documents.get(memory.key(index, id)).document;
    return JSON.parse(Buffer.concat(manifest.chunk_ids.map(chunk =>
        Buffer.from(memory.documents.get(memory.key(index, chunk)).document.payload, 'base64'))).toString());
}
try {
    const repo = "C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration";
    const sourceFixture = join(repo, 'tests/fixtures/portable-state-worker');
    assert.equal(hash(readFileSync(join(sourceFixture, 'source-1-1480-20261020.tar.gz'))), '42d092f3ecf6f428ecdba4825580377acdd27f2818ce445d4f197719e6ab72b7');
    const extraction = spawnSync(process.platform === 'win32' ? 'python' : 'python3', [join(sourceFixture, 'prepare.py'), join(directory, 'capture')],
        {encoding: 'utf8', timeout: 20000, maxBuffer: 1024 * 1024});
    assert.equal(extraction.status, 0, extraction.stderr);
    const extracted = JSON.parse(extraction.stdout);
    assert.equal(extracted.files, 1488); assert.equal(extracted.bytes, 27982958); assert.equal(extracted.selectedBlocks, 1480);
    assert.equal(hash(readFileSync(extracted.plan)), extracted.planSha256);
    assert.equal(extracted.archiveSha256, '42d092f3ecf6f428ecdba4825580377acdd27f2818ce445d4f197719e6ab72b7');
    const sourceDir = join(directory, 'capture/source'), schemaJson = readFileSync(join(sourceDir, 'schema.json'), 'utf8');
    assert.equal(hash(schemaJson), '94c5661306467f8c49f22180213e390db10d290be9ebf512fb63314f440ef6f9');
    const receipt = JSON.parse(readFileSync(join(sourceDir, 'receipt.json'))), frameIndex = new Map(receipt.frames.map(row => [row.blockNum, row]));
    assert.equal(receipt.chainId, chainId); assert.equal(receipt.complete, true);
    const wireRoot = dirname(dirname(fileURLToPath("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/node_modules/%40eosrio/hyperion-wire-plugin/dist/protocol-provider.json")));
    const originalDir = join(wireRoot, 'fixtures/codec/native-onblock-6508-20261022');
    const manifest = JSON.parse(readFileSync(join(originalDir, 'manifest.json')));
    for (const member of manifest.members) {const bytes = readFileSync(join(originalDir, member.path)); assert.equal(bytes.length, member.bytes); assert.equal(hash(bytes), member.sha256);}
    const expected = new Map(JSON.parse(readFileSync(join(originalDir, 'expected.json'))).map(row => [row.blockNum, row]));
    const profileId = 'wire-sysio-6508c9e8-native-engineering-v1';
    const fixture = {profileId, handshake: JSON.parse(schemaJson), frameHex: readFileSync(join(sourceDir, 'block-000033.bin')).toString('hex')};
    const config = {settings: {chain, parser: '3.2', protocol: {provider: 'extension', package: '@eosrio/hyperion-wire-plugin', profileId},
        eosio_alias: 'sysio', system_contract: 'sysio', index_version: 'v1', index_partition_size: 1000, es_replicas: 0,
        protocol_abi_coordination: {recovery_window_blocks: 256}},
        indexer: {fetch_block: true, fetch_traces: true, fetch_deltas: true, process_deltas: false, disable_indexing: false, live_reader: true},
        features: {contract_console: false, failed_trx: false, streaming: {traces: true, deltas: false}},
        scaling: {ds_pool_size: 1, ds_queues: 1, routing_mode: 'round_robin', indexing_queues: 1, ad_idx_queues: 2},
        whitelists: {root_only: false, actions: [], deltas: []}, blacklists: {actions: [], deltas: []},
        api: {tx_cache_mode: 'batch', disable_tx_cache: false}, plugins: {}};
    mkdirSync(join(directory, 'config'));
    writeFileSync(join(directory, 'chain.json'), JSON.stringify(config));
    writeFileSync(join(directory, 'config/connections.json'), JSON.stringify({chains: {[chain]: {chain_id: chainId}}}));
    process.chdir(directory); process.env.CONFIG_JSON = join(directory, 'chain.json'); process.env.live_mode = 'true'; process.env.worker_role = 'continuous_reader';
    const [{default: Reader}, {default: Main}, {default: Pool}, {default: Parser}, {HyperionModuleLoader}, {loadChainProtocol},
        {ProtocolAbiCoordinator}, {ProtocolAbiCoordinatorRpc}, {ProtocolSourceBindingStore, protocolSourceSelectionHeader},
        {ProtocolAbiObservationStore}, {ProtocolAbiFrontierStore}, {ActionSourceAdmissionStore, actionSourceIngressHeader, actionSourceAdmissionHeader},
        {deriveActionSourceInventory, ActionSourceInventoryError}, {actionHistoryImmutableJson, fingerprintActionHistoryEffect}, {currentActionPolicy, currentActionConfiguration},
        {publishAdmittedActionWithEvidence}] = await Promise.all([
        import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/workers/state-reader.js"), import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/workers/deserializer.js"),
        import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/workers/ds-pool.js"), import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/modules/parsers/3.2-parser.js"),
        import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/modules/loader.js"), import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/protocol/selection.js"),
        import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/protocol/abi-coordinator.js"), import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/protocol/abi-coordinator-rpc.js"),
        import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/protocol/source-bindings.js"), import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/protocol/abi-observation-store.js"),
        import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/protocol/abi-frontier-store.js"), import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/history/action-source-admission.js"),
        import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/history/action-source-inventory.js"), import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/history/action-history-manifest.js"),
        import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/history/action-producer-epoch.js"), import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/build/indexer/history/action-confirmed-publication.js")]);
    const installed = await loadChainProtocol(config.settings.protocol);
    assert.ok(installed.provider.nativeActions, 'select the installed native provider normally');
    assert(installed.components.every(component => component.sourceRevision === '7167659e9c043cb3351074fcacb40200cc57f3a3'));
    const selected = installed;
    const wire = await import("file:///C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration/node_modules/%40eosrio/hyperion-wire-plugin/dist/index.js");
    const codec = wire.createWireValueCodec(fixture.handshake, wire.resolveCodecProfile(profileId));
    const template = codec.decode('result', Buffer.from(fixture.frameHex, 'hex'));
    const memory = frontierMemoryClient(), bindings = new ProtocolSourceBindingStore(memory.client, chain);
    let readStage = 'source-setup'; const measuredReads = [];
    const actualGet = memory.client.get.bind(memory.client);
    memory.client.get = async (request, options) => {
        const measured = {stage: readStage, index: request.index, id: request.id, family: request.id.split(':')[0],
            returnedJsonBytes: 0, errorMetaJsonBytes: 0, succeeded: false};
        measuredReads.push(measured);
        try {const returned = await actualGet(request, options); measured.returnedJsonBytes = Buffer.byteLength(JSON.stringify(returned));
            measured.succeeded = true; return returned;}
        catch (error) {measured.errorMetaJsonBytes = Buffer.byteLength(JSON.stringify(error?.meta ?? null)); throw error;}
    };
    const observations = new ProtocolAbiObservationStore(memory.client, chain), frontier = new ProtocolAbiFrontierStore(memory.client, chain);
    const admissionStore = new ActionSourceAdmissionStore(memory.client, chain), targetName = `${chain}-action-v1-000001`;
    memory.settings.set(targetName, {'index.uuid': 'owned-wire-admission-target'});
    memory.client.indices.exists = async ({index}) => memory.settings.has(index);
    const filters = {action_blacklist: new Set(), action_whitelist: new Set(), delta_blacklist: new Set(), delta_whitelist: new Set()};
    const cm = {config, filters}, parser = new Parser(cm), loader = Object.create(HyperionModuleLoader.prototype);
    Object.assign(loader, {handledActions: new Map(), handledDeltas: new Map(), parser, plugins: []});
    const readerConsumer = new ControlledConsumer(), mainConsumer = new ControlledConsumer(), poolConsumer = new ControlledConsumer();
    const readerPublisher = new ControlledPublisher(), mainPublisher = new ControlledPublisher(), poolPublisher = new ControlledPublisher();
    const worker = (prototype, consumer, publisher) => {
        const value = Object.create(prototype);
        Object.assign(value, {chain, chainId, conf: config, configModule: cm, filters, mLoader: loader,
            protocol: selected.provider, protocolId: selected.id, protocolComponents: selected.components,
            protocolReady: Promise.resolve(), abieos: selected.decoder, client: memory.client,
            ch: consumer, cch: publisher, ch_ready: true, cch_ready: true, profiler: {start: () => () => {}},
            actionAdmissionOwners: new WeakMap(), actionAdmissionStore: admissionStore});
        Object.defineProperty(value, 'actionSourceAdmissionEnabled', {value: true});
        return value;
    };
    reader = worker(Reader.prototype, readerConsumer, readerPublisher);
    const main = worker(Main.prototype, mainConsumer, mainPublisher), pool = worker(Pool.prototype, poolConsumer, poolPublisher);
    Object.assign(reader, {baseRequest: {}, shipRev: 0, socketGeneration: 0, activeIngressGeneration: 0,
        isLiveReader: true, local_block_num: 0, local_lib: 0, receivedFirstBlock: true,
        reversibleBlockMap: new Map(), forkedBlocks: new Map(), publications: new Map(),
        protocolSourceBindingStore: bindings, send() {}, handleStatusResult() {}});
    reader.stageOneDistQueue = {push: async payload => {
        sourceFrames.push(payload); return new Promise(resolve => reader.distribute([payload], resolve));
    }};
    Object.assign(main, {local_block_count: 0, lastSelectedWorker: 0, dsPoolMap: {}, ds_pool_counters: {}, block_emit_idx: 1,
        protocolDeliveryOwners: new WeakMap(), protocolSourceBindingStore: bindings, protocolAbiObservationStore: observations,
        preIndexingQueue: {push: async payload => blockWrites.push(payload)}});
    Object.assign(pool, {protocolDeliveryOwners: new WeakMap(), poolAbiCache: new Map(), poolTypeCache: new Map(),
        protocolCacheViews: new Set(), temp_ds_counter: 0, actionDsCounter: 0, act_emit_idx: 1, txCacheExpiration: 3600,
        allowStreaming: true, common: {attachActionExtras: Pool.prototype.attachActionExtras},
        pushToActionsQueue() {assert.fail('Wire admitted output bypassed its confirmed publisher');},
        ioRedisClient: {pipeline() {
            const writes = [];
            return {hset(key, values) {writes.push({key, values: new Map([...values].map(([key, value]) => [key, Buffer.from(value)]))}); return this;},
                expire() {return this;}, async exec() {cache.push(...writes); return [];}};
        }}});
    const profile = {id: selected.id, profileId, components: selected.components};
    coordinator = new ProtocolAbiCoordinator({chainId, profile, ownerId: 'native-worker-original-owner', bindings, observations, store: frontier,
        verifyNativeGenesis: selected.provider.verifyNativeGenesis.bind(selected.provider), nativeActionInterfaceVersion: 1});
    await coordinator.start();
    reader.coordinatorRpc = new ProtocolAbiCoordinatorRpc((request, callback) => {
        const input = request.data;
        void (input.operation === 'open' ? coordinator.openSource(input.contextId, input.readerSessionId) : coordinator.admit(input.selectionId, input.generation))
            .then(result => reader.onIpcMessage({event: 'protocol_abi_coordinator_reply', mId: request.mId, data: {ok: true, result}}))
            .catch(error => reader.onIpcMessage({event: 'protocol_abi_coordinator_reply', mId: request.mId,
                data: {ok: false, error: {code: 'controlled_coordinator', message: error.message}}}));
        callback(null);
    });
    await reader.onMessage(Buffer.from(schemaJson));
    await reader.onMessage(Buffer.from(codec.encode('result', ['get_status_result_v0', {head: template[1].head,
        last_irreversible: {block_num: 0, block_id: blockId(0)}, trace_begin_block: 1, trace_end_block: 2401,
        chain_state_begin_block: 1, chain_state_end_block: 2401, chain_id: chainId}])));
    const prepare = async bytes => {
        const before = readerPublisher.sent.length, mainBefore = mainPublisher.sent.length;
        assert.equal(await reader.onMessage(bytes), 'block'); await ticks();
        assert.equal(readerPublisher.sent.length, before + 1);
        const raw = readerPublisher.sent.at(-1), delivery = message(raw);
        assert.equal(raw.options.mandatory, true); assert.equal(raw.options.persistent, true);
        assert.ok(raw.payload.equals(bytes)); assert.ok(raw.options.headers[actionSourceIngressHeader]);
        const retainedIngress = await admissionStore.resolveIngress(raw.options.headers[actionSourceIngressHeader]);
        assert.equal(retainedIngress.frameHex, bytes.toString('hex'));
        main.captureActionAdmissionDelivery(delivery, mainConsumer); main.captureProtocolSourceDelivery(delivery, mainConsumer);
        await parser.parseMessage(main, [delivery]); await draining;
        assert.equal(mainConsumer.acked.at(-1), delivery);
        const messages = mainPublisher.sent.slice(mainBefore).map(sent => {
            const delivery = message(sent); pool.captureActionAdmissionDelivery(delivery, poolConsumer);
            pool.captureProtocolActionDelivery(delivery, poolConsumer); return delivery;
        });
        const admissionId = messages[0]?.properties.headers[actionSourceAdmissionHeader];
        // Empty-block links contain no source body; resolve the bounded set by actual retained source association.
        let admission;
        for (const id of admissionId ? [admissionId] : ids(memory, 'h45actionadmission1:')) {
            const value = await admissionStore.resolve(id);
            if (value.source.inventoryInput.source.blockNum === numberFrom(bytes)) {admission = value; break;}
        }
        assert.ok(admission, 'source admission is discoverable after prepare');
        const sourceSelectionId = raw.options.headers[protocolSourceSelectionHeader];
        const link = await bindings.readObservationLink(sourceSelectionId), observation = await observations.read(link.observationId);
        assert.equal(observation.observation.status, numberFrom(bytes) === 1 ? 'native-genesis' : 'observed', JSON.stringify(observation.observation));
        if (numberFrom(bytes) === 1) {
            // Original genesis omits traces. Retain that missing-input boundary, never manufacture an empty vector.
            assert.ok(admission.incomplete); assert.equal(messages.length, 0);
            assert.equal(ids(memory, 'h45actionhandoff1:').length, 0, 'missing original genesis traces cannot be a successful handoff');
            await assert.rejects(pool.getProtocolNativeReader().waitForOpen({chainId, blockNum: 1,
                blockId: admission.source.inventoryInput.source.blockId}, sourceSelectionId), {code: 'native_source_incomplete'});
            return {admission, messages, sourceSelectionId};
        }
        const originalTraces = codec.decode('transaction_trace[]', Buffer.from(codec.decode('result', bytes)[1].traces, 'hex'));
        const expected = deriveActionSourceInventory({profileId, source: admission.source.inventoryInput.source,
            policy: currentActionPolicy(main), traces: originalTraces, wireActionInputs: observation.observation.facts.actionInputs, sourceSelectionId});
        assert.deepEqual(admission.inventory, expected);
        for (const delivery of messages) {
            const transaction = expected.transactions[delivery.properties.headers.action_trace_ordinal];
            assert.equal(delivery.content.toString(), transaction.dispatch.canonicalJson);
        }
        return {admission, messages, sourceSelectionId};
    };
    const numberFrom = bytes => Number(codec.decode('result', bytes)[1].this_block.block_num);
    let original36;
    for (let height = 1; height <= 36; height++) {
        const bytes = readFileSync(join(sourceDir, 'block-' + String(height).padStart(6, '0') + '.bin'));
        assert.equal(hash(bytes), frameIndex.get(height).sha256);
        const prepared = await prepare(bytes); if (height === 36) original36 = prepared;
    }
    const transaction = original36.admission.inventory.transactions[1];
    assert.equal(transaction.transactionId, '140abb3d398f206518e117c02ccf1f1604b37b9fb55f7abed2034cf2fb374c66');
    assert.equal(transaction.groups.length, 2);
    const original = original36.messages.find(value => value.properties.headers.action_trace_ordinal === 1);
    assert.ok(original); assert.equal(original.content.toString(), transaction.dispatch.canonicalJson);
    const deliveries = [101, 102].map(deliveryTag => ({content: Buffer.from(original.content),
        properties: structuredClone(original.properties), fields: {deliveryTag}}));
    assert.notEqual(deliveries[0], deliveries[1]); assert.notEqual(deliveries[0].content, deliveries[1].content);
    for (const delivery of deliveries) {
        pool.captureActionAdmissionDelivery(delivery, poolConsumer); pool.captureProtocolActionDelivery(delivery, poolConsumer);
    }
    const outputsBefore = poolPublisher.sent.length, ackBefore = poolConsumer.acked.length;
    readStage = 'ds-same-cargo';
    await pool.processMessages(deliveries);
    readStage = 'post-ds-audit';
    assert.equal(poolConsumer.acked.length - ackBefore, 2);
    assert.deepEqual(poolConsumer.acked.slice(ackBefore), deliveries);
    const outputs = poolPublisher.sent.slice(outputsBefore).map(sent => ({payloadSha256: hash(sent.payload),
        queue: sent.queue, action: JSON.parse(sent.payload)}));
    assert.equal(outputs.length, 4); assert.deepEqual(outputs.map(row => row.action.act.name), ['setcode','setabi','setcode','setabi']);
    assert(outputs.every(row => row.action.protocol.schemaVersion === 1 && row.action.protocol.status === undefined));
    assert.equal(outputs[0].payloadSha256, outputs[2].payloadSha256); assert.equal(outputs[1].payloadSha256, outputs[3].payloadSha256);
    const summary = new Map();
    for (const row of measuredReads) {
        const key = JSON.stringify([row.stage,row.index,row.family]);
        const value = summary.get(key) ?? {stage: row.stage,index: row.index,family: row.family,getCalls: 0,
            successfulReturnedJsonBytes: 0,failedErrorMetaJsonBytes: 0,failedCalls: 0};
        value.getCalls++; value.successfulReturnedJsonBytes += row.returnedJsonBytes;
        value.failedErrorMetaJsonBytes += row.errorMetaJsonBytes; if (!row.succeeded) value.failedCalls++;
        summary.set(key,value);
    }
    assert.equal(nativeAddonResolutions, 0);
    console.log(JSON.stringify({passed: true,kind: 'controlled-memory-cache-read-count',sourceRevision: 'f80ab829ac987e369a51a07575869ad99afecea3',
        native: process.version, originalArchiveSha256: extracted.archiveSha256,
        original36FrameSha256: hash(readFileSync(join(sourceDir,'block-000036.bin'))), transactionId: transaction.transactionId,
        traceOrdinal: 1, dispatchPayloadSha256: hash(original.content), dispatchHeaders: original.properties.headers,
        deliveryTags: deliveries.map(value => value.fields.deliveryTag), independentPhysicalReceipts: true,
        sameCargo: true, outputNames: outputs.map(row => row.action.act.name),outputPayloadSha256: outputs.map(row => row.payloadSha256),acknowledgments: 2,
        byteDefinition: 'UTF8 JSON.stringify actual successful memory-client.get return object; thrown meta measured separately; excludes network framing',
        summary: [...summary.values()],reads: measuredReads, controlledBrokerStorage: true,networkOrThroughputClaim: false,fullWorkerQualification: false}));
} finally {
    reader?.coordinatorRpc?.cancel(); reader?.shipSession?.close?.();
    process.send = previousSend; process.chdir(previousDirectory); hooks.deregister();
    const ownedDirectory = resolve(directory); assert.equal(dirname(ownedDirectory), resolve(tmpdir()));
    assert.match(basename(ownedDirectory), /^hyperion-attempt-worker-original-/); rmSync(ownedDirectory, {recursive: true, force: true});
}
