from pathlib import Path
import subprocess,sys,json,hashlib,time
root=Path(r'C:/Users/igorl/AppData/Local/Temp/hapi-settlement-277-6vj2lav7');repo=root/'qualification';name,module,mode,runtime=sys.argv[1:5]
out=root/'qualification-evidence'/name;out.mkdir(exist_ok=False);sha=lambda data:hashlib.sha256(data).hexdigest()
node=Path(r'P:/eosrio/hyperion-tools/out/sequence-coverage/runtimes/node-v22.23.3-win-x64/node.exe') if runtime=='22' else Path(r'C:/Users/igorl/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
tests=['tests/unit/worker-attempt-quiescence.test.ts','tests/unit/worker-attempt-quiescence-worker.mjs','tests/unit/worker-attempt-ipc.mjs','tests/unit/worker-attempt-ipc-child.mjs'];files=[]
for rel in tests:
    data=(repo/rel).read_bytes();saved=out/rel;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(data);files.append({'path':rel,'sha256':sha(data),'bytes':len(data)})
names=subprocess.check_output(['git','ls-files','src','packages','tests/unit/action-attempt-disposition-worker.mjs','tests/unit/protocol-frontier-memory.mjs','package-lock.json'],cwd=repo,text=True).splitlines()
before={rel:sha((repo/rel).read_bytes()) for rel in names if (repo/rel).is_file()};head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();cmd=[str(node),str(repo/'tests/unit'/module),mode];started=time.monotonic()
p=subprocess.run(cmd,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=50);after={rel:sha((repo/rel).read_bytes()) for rel in before};assert before==after
(out/'stdout.log').write_bytes(p.stdout);(out/'stderr.log').write_bytes(p.stderr)
packet={'createdBy':'windows:codex:hyperion-tools','head':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip(),'command':cmd,'runtimeVersion':subprocess.check_output([str(node),'--version'],text=True).strip(),'runtimeSha256':sha(node.read_bytes()),'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-started,'stdoutSha256':sha(p.stdout),'stderrSha256':sha(p.stderr),'tests':files,'sourceBefore':before,'sourceAfter':after}
if p.returncode==0:
    data=json.loads(p.stdout.decode().splitlines()[-1]);assert data['passed'];(out/'observed.json').write_bytes((json.dumps(data,indent=2)+'\n').encode())
    packet['observedSha256']=sha((out/'observed.json').read_bytes());packet['caseIds']=[row['id'] for row in data.get('cases',[])]
(out/'packet.json').write_bytes((json.dumps(packet,indent=2)+'\n').encode());print(json.dumps({'packet':str(out/'packet.json'),'sha256':sha((out/'packet.json').read_bytes()),'exitCode':p.returncode,'cases':packet.get('caseIds')}))
if p.returncode:print(p.stderr.decode(errors='replace')[-5000:]);print(p.stdout.decode(errors='replace')[-1000:])
sys.exit(p.returncode)
