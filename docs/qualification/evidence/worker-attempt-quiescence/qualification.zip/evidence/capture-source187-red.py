from pathlib import Path
import subprocess,json,hashlib,shutil
root=Path(r'C:/Users/igorl/AppData/Local/Temp/hapi-settlement-277-6vj2lav7');repo=root/'qualification';out=root/'qualification-evidence/source187-independent-red';out.mkdir(exist_ok=False);sha=lambda data:hashlib.sha256(data).hexdigest()
modules=['indexer/workers/deserializer','indexer/workers/hyperionWorker','indexer/protocol/proof-consumer-scope','indexer/protocol/worker-attempt-client','indexer/protocol/worker-attempt-supervisor','indexer/protocol/source-bindings','indexer/protocol/abi-observation-store','indexer/protocol/native-observation-store']
emitted=json.loads((root/'qualification-evidence/final-0e1ecac2/native24-build-emitted.json').read_text())['modules'];files=[]
for module in modules:
    rel='src/'+module+'.ts';js='build/'+module+'.js';data=(repo/rel).read_bytes();canonical=subprocess.check_output(['git','show','HEAD:'+rel],cwd=repo);build=(repo/js).read_bytes();assert sha(build)==emitted[js]
    for name,content in [(rel,data),(js,build)]:
        target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
    files.append({'source':rel,'canonicalSha256':sha(canonical),'rawSha256':sha(data),'emitted':js,'emittedSha256':sha(build)})
runs=[];observed=[]
for name in ['main-source-continuations18722','main-source-continuations18724','shutdown18722','shutdown18724']:
    target=out/name;shutil.copytree(root/'qualification-evidence'/name,target);packet=json.loads((target/'packet.json').read_text());runs.append({'directory':name,'packetSha256':sha((target/'packet.json').read_bytes()),'exitCode':packet['exitCode']})
    if name.startswith('main-source'):
        assert packet['exitCode']==1;data=json.loads((target/'stdout.log').read_text().splitlines()[-1])['sourceContinuationSchedules'];assert len(data)==12
        observed.append({'runtime':packet['runtimeVersion'],'schedules':data})
    else:assert packet['exitCode']==0
packet={'createdBy':'windows:codex:hyperion-tools','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'qualifiedProductBase':'0e1ecac29aca4d5e179301d29f51adc8e4213187','productAuthor':'187ee0329a259b0d63ac79c88d64789c79264e89','sources':files,'runs':runs,'literalObserved':observed,'scope':'Actual MainDS+real retained stores; constructed host codec+actual-method return gates provide no canonical grant. Seven post-fence RED schedules,3original core-return rejection controls and2unfenced quarantine/ACK controls, each22/24. Native real supervisor.stop while finalizer held GREEN22/24. No fullsuite/services/capacity/source completeness.'}
(out/'packet.json').write_bytes((json.dumps(packet,indent=2)+'\n').encode());print(json.dumps({'packet':str(out/'packet.json'),'sha256':sha((out/'packet.json').read_bytes())}))
paths=['tests/unit/worker-attempt-quiescence.test.ts','tests/unit/worker-attempt-quiescence-worker.mjs','tests/unit/worker-attempt-ipc.mjs','tests/unit/worker-attempt-ipc-child.mjs'];boundary={'head':packet['head'],'files':{rel:sha((repo/rel).read_bytes()) for rel in paths},'idle':True};(root/'qualification-evidence/source187-safe-boundary.json').write_bytes((json.dumps(boundary,indent=2)+'\n').encode());print(json.dumps(boundary))
