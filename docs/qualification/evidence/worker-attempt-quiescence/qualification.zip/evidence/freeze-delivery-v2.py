from pathlib import Path
import base64, hashlib, json, subprocess, sys, zipfile

root = Path(r'C:/Users/igorl/AppData/Local/Temp/hapi-settlement-277-6vj2lav7')
repo = root / 'qualification'
evidence = root / 'qualification-evidence'
base, expected_head = sys.argv[1:3]
out = evidence / 'delivery-v2'
sha = lambda value: hashlib.sha256(value).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
head = git('rev-parse', 'HEAD').decode().strip()
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
assert head == expected_head and git('rev-parse', 'HEAD^').decode().strip() == base
paths = [
    'tests/unit/worker-attempt-ipc-child.mjs',
    'tests/unit/worker-attempt-ipc.mjs',
    'tests/unit/worker-attempt-quiescence-worker.mjs',
    'tests/unit/worker-attempt-quiescence.test.ts',
]
assert sorted(git('diff', '--name-only', base, head).decode().splitlines()) == sorted(paths)
assert not git('status', '--porcelain').strip()
final = evidence / ('final-' + base[:8])
packet = json.loads((final / 'packet.json').read_text())
assert packet['productHead'] == base
matrix = json.loads((final / 'case-matrix.json').read_text())
comparison = json.loads((final / 'cache-comparison.json').read_text())
assert len(matrix) == 46 and sum(len(row['cases']) for row in matrix) == 130
for runtime in ('v22.23.3', 'v24.19.0'):
    assert len([row for row in matrix if row['runtime'] == runtime]) == 23
    assert sum(len(row['cases']) for row in matrix if row['runtime'] == runtime) == 65
tests = []
for rel in paths:
    raw = (repo / rel).read_bytes()
    canonical = git('show', head + ':' + rel)
    assert sha(raw) == next(row['sha256'] for row in packet['tests'] if row['path'] == rel)
    tests.append({'path': rel, 'rawSha256': sha(raw), 'canonicalSha256': sha(canonical),
                  'rawBytes': len(raw), 'canonicalBytes': len(canonical)})
patch = git('diff', '--binary', '--full-index', base, head, '--', *paths)
members = {}
for folder in (final.name, 'source187-independent-red', 'cache-baseline-f80'):
    for path in sorted((evidence / folder).rglob('*')):
        if not path.is_file():
            continue
        assert not path.is_symlink()
        name = 'evidence/' + path.relative_to(evidence).as_posix()
        assert ':' not in name and '..' not in Path(name).parts
        members[name] = path.read_bytes()
for name in ('run-final-qualified-v2.py', 'run-owned-case.py', 'capture-source187-red.py',
             'freeze-delivery-v2.py', 'source187-safe-boundary.json'):
    members['evidence/' + name] = (evidence / name).read_bytes()
members['root-supplied/main-source-await-red.mjs'] = (root / 'main-source-await-red.mjs').read_bytes()
for path in sorted((root / 'main-source-await-red-root-v2').rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        members['root-supplied/main-source-await-red-root-v2/' + path.relative_to(root / 'main-source-await-red-root-v2').as_posix()] = path.read_bytes()
baseline = Path(r'C:/Users/igorl/AppData/Local/Temp/hapi-outcomes-282-klhwypgb/terminal-integration')
baseline_provenance = json.loads((evidence / 'cache-baseline-f80/source-provenance.json').read_text())
baseline_git = lambda *args: subprocess.check_output(['git', *args], cwd=baseline)
assert baseline_git('rev-parse', 'HEAD').decode().strip() == baseline_provenance['sourceHead']
assert not baseline_git('status', '--porcelain').strip()
final_curated = []
final_emitted_manifests = [json.loads((final / (label + '-build-emitted.json')).read_text())['modules'] for label in ('native22', 'native24')]
for row in baseline_provenance['modules']:
    canonical = baseline_git('show', baseline_provenance['sourceHead'] + ':' + row['source'])
    raw, emitted = (baseline / row['source']).read_bytes(), (baseline / row['emitted']).read_bytes()
    assert sha(canonical) == row['canonicalSourceSha256']
    assert sha(raw) == row['rawSourceSha256'] and sha(emitted) == row['emittedSha256']
    members['evidence/f80-curated/canonical/' + row['source']] = canonical
    members['evidence/f80-curated/raw/' + row['source']] = raw
    members['evidence/f80-curated/' + row['emitted']] = emitted
    current_raw = (repo / row['source']).read_bytes()
    current_canonical = git('show', base + ':' + row['source'])
    assert sha(current_raw) == packet['commands'][0]['sourceBefore'][row['source']]
    assert sha(current_raw) == packet['commands'][-1]['sourceAfter'][row['source']]
    current_emitted = (repo / row['emitted']).read_bytes()
    assert all(manifest[row['emitted']] == sha(current_emitted) for manifest in final_emitted_manifests)
    members['evidence/final-curated/canonical/' + row['source']] = current_canonical
    members['evidence/final-curated/raw/' + row['source']] = current_raw
    members['evidence/final-curated/shared-native22-native24/' + row['emitted']] = current_emitted
    final_curated.append({'source': row['source'], 'canonicalSha256': sha(current_canonical),
                          'rawSha256': sha(current_raw), 'emitted': row['emitted'],
                          'emittedSha256': sha(current_emitted),
                          'emittedBytesMatchBothSavedNormalBuildManifests': True})
for row in baseline_provenance['fixtureAndArchiveHashes']:
    data = (baseline / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
    members['evidence/f80-curated/' + row['path']] = data
supplemental_final = []
for rel in ('package.json', 'package-lock.json', 'tsconfig.json', 'packages/backend-mongodb/package.json',
            'packages/backend-mongodb/tsconfig.json', 'tests/unit/worker-attempt-fixture.mjs',
            'tests/unit/action-attempt-disposition-worker.mjs', 'tests/unit/protocol-frontier-memory.mjs'):
    raw, canonical = (repo / rel).read_bytes(), git('show', base + ':' + rel)
    if rel in packet['commands'][0]['sourceBefore']:
        assert sha(raw) == packet['commands'][0]['sourceBefore'][rel]
        assert sha(raw) == packet['commands'][-1]['sourceAfter'][rel]
    members['evidence/final-curated/raw/' + rel] = raw
    members['evidence/final-curated/canonical/' + rel] = canonical
    supplemental_final.append({'path': rel, 'rawSha256': sha(raw), 'canonicalSha256': sha(canonical),
                               'captureTiming': 'after commands at unchanged source; tracked source matches qualified base'})
totals = []
for run in comparison:
    rows = [row for row in run['families'] if row['stage'] == 'ds-same-cargo']
    totals.append({
        'runtime': run['runtime'],
        'baselineGET': sum(row['baseline'].get('getCalls', 0) for row in rows),
        'finalGET': sum(row['final'].get('getCalls', 0) for row in rows),
        'finalSuccessfulReturnedJsonBytes': sum(row['final'].get('successfulReturnedJsonBytes', 0) for row in rows),
        'familyCount': len(rows),
        'allStagesAndFamiliesCountByteDeltaZero': all(row['deltaGET'] == 0 and row['deltaSuccessfulReturnedJsonBytes'] == 0 for row in run['families']),
    })
index = {
    'schemaVersion': 2, 'createdBy': 'windows:codex:hyperion-tools',
    'task': 'evt_20261022T231426_5ff9d864e4ff', 'correlation': 'task_hapi286_qualification',
    'topic': 'hapi286-qualification', 'branch': 'test/worker-attempt-quiescence',
    'initialProductBase': '65c3b46d3161257b00ceac21a27e98ed600e1c16',
    'patchBase': base, 'head': head, 'tree': tree,
    'patchSha256': sha(patch), 'patchBytes': len(patch), 'tests': tests,
    'qualifiedCompositeHead': base, 'qualifiedCompositeTree': packet['productTree'],
    'qualifiedProductAuthor': '8e203582fc7d4c0b566d1cf46258f562e1911f71',
    'qualifiedProductAuthorTree': 'f2b07baf8b911250bbd38fcfd1004df6eb4f3ff6',
    'qualificationPacket': 'evidence/' + final.name + '/packet.json',
    'qualificationPacketSha256': sha((final / 'packet.json').read_bytes()),
    'caseMatrix': 'evidence/' + final.name + '/case-matrix.json',
    'observedSchedules': 130, 'observedSchedulesPerRuntime': 65, 'wrappersPerRuntime': 23,
    'runtimeVersions': ['v22.23.3', 'v24.19.0'], 'bunVersion': '1.4.4',
    'cacheComparison': totals,
    'curatedBaseline': {'sourceHead': baseline_provenance['sourceHead'], 'sourceTree': baseline_provenance['tree'],
                        'modules': len(baseline_provenance['modules']), 'canonicalRawAndEmittedFilesIncluded': True,
                        'fixtureArchiveIncluded': True,
                        'fixtureArchiveScope': 'Original immutable archive is included for independent inspection. The measured workload consumes only its prefix1..36; inclusion grants no full1480 replay qualification.'},
    'curatedFinalModules': final_curated,
    'supplementalFinalFiles': supplemental_final,
    'qualificationCommitTiming': 'Commands ran at the qualified composite base with exactly recorded modified four test files; this later test-only commit contains identical recorded test bytes. No claim that commands ran at the later test commit.',
    'newRedToGreen': {
        'redPacket': 'evidence/source187-independent-red/packet.json',
        'redPacketSha256': sha((evidence / 'source187-independent-red/packet.json').read_bytes()),
        'redProductAuthor': '187ee0329a259b0d63ac79c88d64789c79264e89',
        'redRuntimeVersions': ['v22.23.3', 'v24.19.0'],
        'greenMode': 'source-continuations', 'schedulesPerRuntime': 12,
        'sevenFailingBoundaries': ['protocolReady', 'readSelection rejected return', 'readSelection resolved return', 'ABI PREPARE resolved return', 'observation link resolved return', 'native PREPARE resolved return', 'synchronous codec failure after self-fence'],
        'controls': ['Three held original core-return rejections remain no new work/no ACK', 'Two unfenced classification failures still quarantine once and attempt original ACK once'],
        'fixtureScope': 'Actual MainDS and real retained stores with constructed host codec and actual-method return gates; no canonical grant or live Wire claim',
    },
    'nativeShutdown': {
        'mode': 'shutdown', 'schedulesPerRuntime': 1,
        'oracle': 'Real exact physical native child, supervisor.stop while original finalizer held: retained callback and new root refused, no end before finalizer, one genuine drained end after release, then exact observed exit and pipe close; kill requests never used as end evidence',
    },
    'previousAuthenticatedDelivery': {
        'patchReadyEvent': 'evt_20261023T011217_da42fa8fbdec',
        'appliedAck': 'evt_20261023T011654_d0433e722bf7',
        'testHead': '3f47d1ec6e36abb14bb13006d436bba01c665354',
        'indexArtifact': 'art_20261023T011106_e8e337dfa9d8',
        'indexSha256': 'abf9d2c70fbcecbc5206c6628f097d2d2f3a58af6bcf4a08eb49169a43c6944a',
        'rawArtifact': 'art_20261023T011118_826c6721a8c2',
        'rawSha256': '572b2f1417df4c2ae7869a37f2f490d46c1c82af3f04edaa4100e431215106df',
        'zipSha256': '1f581267cecdd0218bd828d28e9902697f58cf6605f59ed8eb4049bcc5a4107e',
        'scope': 'Historical original104 schedules and earlier RED drivers/source/emission provenance; preserved separately and not overwritten',
    },
    'measuredScope': 'Controlled in-memory transport actual GET calls and successful UTF8 JSON.stringify returned object bytes by stage/record family. Original36 repeated in one cargo with fresh separate receipts/tags101/102; within-run duplicate outputs and original ACK/source associations exact. Cross-run source/admission/output metadata varies; no cross-run raw output byte equality, network, throughput or production speed claim.',
    'explicitSeparations': [
        'Actual native parent-accepted physical custody/end evidence is separate from explicitly controlled-local Wire/projection fixtures',
        'Synthetic projection source/adapter scheduling and constructed host protocol ancestry/fork fixtures grant no canonical Wire/Mongo evidence',
        'Authenticated local end grants no successful effects, durable original ACK, source completeness, reader credit or capacity release',
        'Public API new-open ancestry remains allowed256/denied257; active internal root does not pin it',
        'Original historical root/operation, caller snapshot, end identity, publication, projection, initialization and target RED-to-GREEN controls rerun in this coherent final focused set; original RED evidence is in the prior authenticated archive',
    ],
    'remainingReleaseGates': [
        'Root fullsuite once, independent Standards/Spec review, PR and CI',
        'No reader-capacity activation or prospective count/byte accounting including already granted and queued work',
        'No original-selection restart/retention reconciliation or projection demand between frames',
        'No unchanged original1..1480 native Linux Wire/Mongo qualification or full source-completeness claim',
        'No services, deployment or fullsuite performed by qualification lane',
    ],
    'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())],
}
out.mkdir(exist_ok=False)
(out / 'tests.patch').write_bytes(patch)
(out / 'index.json').write_bytes((json.dumps(index, indent=2) + '\n').encode())
members['index.json'] = (out / 'index.json').read_bytes()
members['tests.patch'] = patch
archive = out / 'qualification-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted(members.items()):
        assert ':' not in name and '..' not in Path(name).parts and not name.startswith('/')
        bundle.writestr(name, data)
envelope = {'schemaVersion': 1, 'encoding': 'base64-zip', 'archiveSha256': sha(archive.read_bytes()),
            'archiveBytes': archive.stat().st_size, 'indexSha256': sha((out / 'index.json').read_bytes()),
            'members': len(members), 'base64': base64.b64encode(archive.read_bytes()).decode()}
(out / 'archive-envelope.json').write_bytes(json.dumps(envelope, separators=(',', ':')).encode())
summary = {'base': base, 'head': head, 'tree': tree, 'patchSha256': sha(patch), 'patchBytes': len(patch),
           'indexSha256': sha((out / 'index.json').read_bytes()), 'archiveSha256': envelope['archiveSha256'],
           'archiveBytes': envelope['archiveBytes'], 'members': len(members),
           'envelopeSha256': sha((out / 'archive-envelope.json').read_bytes()),
           'envelopeBytes': (out / 'archive-envelope.json').stat().st_size,
           'finalPacketSha256': index['qualificationPacketSha256']}
(out / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps(summary))
