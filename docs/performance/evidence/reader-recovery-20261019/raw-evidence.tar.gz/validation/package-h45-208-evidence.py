from pathlib import Path, PurePosixPath
import datetime, gzip, hashlib, io, json, subprocess, tarfile

ROOT = Path('/var/snap/docker/common/hyperion-qualification/run-20261019-195-208')
DEST = ROOT / 'evidence/recovery208-packaged-v1'
REPO = ROOT / 'recovery'
BASE = '37e3ee6bb897a3647b88d272e55d43240ecf7dc6'
RUNTIME = 'f42172860e833c348db9bce4fbc47311af6dcfde'
HARNESS = 'f81cabf3fc2304e2106c10f5e3b746a89e10107a'
RUN = '468124d02cf3'
assert ROOT.is_dir() and REPO.is_dir() and not DEST.exists()
members = {}
def sha(data): return hashlib.sha256(data).hexdigest()
def encode(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
def load(path): return json.loads(path.read_bytes())
def put(name, data, role):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and name not in members
    members[name] = {'data': data, 'role': role}
def add(path, name, role):
    assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(ROOT.resolve()), str(path)
    put(name, path.read_bytes(), role)
def tree(path, prefix, role):
    for file in sorted(path.rglob('*')):
        assert not file.is_symlink(), str(file)
        if file.is_file(): add(file, prefix + '/' + file.relative_to(path).as_posix(), role)

fixed = load(ROOT / 'recovery208-final/report.json')
baseline = load(ROOT / 'recovery208-baseline2/report.json')
postflight = load(ROOT / 'evidence/recovery208-postflight.json')
cleanup = load(ROOT / 'fixture208.json.cleanup.json')
core_cleanup = load(ROOT / 'fixture208.json.core.json.cleanup.json')
fixture = load(ROOT / 'fixture208.json')
assert fixed['status'] == 'passed' and len(fixed['cases']) == 7
assert baseline['status'] == 'defects-reproduced' and len(baseline['cases']) == 3
assert fixed['run'] == baseline['run'] == postflight['run'] == cleanup['run'] == core_cleanup['run'] == RUN
assert baseline['base'] == BASE
assert all(case['status'] == 'passed' for case in fixed['cases'])
assert all(case['status'] == 'defect-reproduced' for case in baseline['cases'])
assert fixed['cleanup']['childProcessesRemaining'] == baseline['cleanup']['childProcessesRemaining'] == 0
assert not fixed['cleanup']['errors'] and not baseline['cleanup']['errors'] and not fixed['amqpErrors']
assert postflight['status'] == 'passed' and postflight['consecutiveIdleSamples'] == len(postflight['samples']) == 3
assert postflight['fixtureManifestSha256'] == sha((ROOT / 'fixture208.json').read_bytes())
for sample in postflight['samples']:
    assert not sample['observedPidsAlive']
    assert sample['brokerQueues'] == sample['brokerConnections'] == sample['activeSearchWrites'] == 0
for key in ['remainingContainers', 'remainingVolumes', 'remainingNetworks']:
    assert core_cleanup[key] == cleanup['coreCleanup'][key] == 0
assert cleanup['coreCleanup'] == core_cleanup
assert len(core_cleanup['containers']) == len(core_cleanup['volumes']) == 4
assert len(cleanup['extraContainers']) == len(cleanup['extraVolumes']) == 3

tree(ROOT / 'recovery208-final', 'accepted/fixed', 'accepted-fixed')
tree(ROOT / 'recovery208-baseline2', 'accepted/baseline', 'accepted-baseline-counterexample')
for directory in ['recovery208-case1', 'recovery208-case2', 'recovery208-case3', 'recovery208-baseline']:
    tree(ROOT / directory, 'excluded-pilots/' + directory, 'excluded-pilot')
for name in ['fixture208.json', 'fixture208.json.core.json', 'fixture208.json.cleanup.json', 'fixture208.json.core.json.cleanup.json']:
    add(ROOT / name, 'fixture/' + name, 'owned-fixture-and-cleanup')
for path in sorted((ROOT / 'evidence').glob('*')):
    name = path.name
    if path.is_file() and (name.startswith('recovery208-') or name.startswith('build208-') or name.startswith('fixture208-') or name == 'observer208-linux.log'
                          or name in ['preparation.json', 'node-native-imports.log', 'bun-native-imports.log', 'bun-native-imports-result.json', 'npm-ci.log', 'typecheck-base.log', 'build-recovery-base.log']):
        add(path, 'validation/' + name, 'validation-and-provenance')
for name in ['recovery-initial.patch', 'recovery-v3.patch', 'recovery-v4.patch', 'observer.patch']:
    add(ROOT / name, 'provenance/' + name, 'implementation-pilot-provenance')

source_matches = []
for label, report in [('fixed', fixed), ('baseline', baseline)]:
    for relative, expected in report['sources'].items():
        assert not PurePosixPath(relative).is_absolute() and '..' not in PurePosixPath(relative).parts
        path = REPO / relative
        data = path.read_bytes()
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], f'{label} source mismatch {relative}: {sha(data)} != {expected}'
        name = 'sources/' + label + '/' + relative
        add(path, name, 'measured-source-snapshot')
        source_matches.append({'report': label, 'path': relative, 'archiveMember': name, **expected})
for relative, stored in [('src/indexer/workers/state-reader.ts', 'state-reader.baseline.ts'), ('src/indexer/modules/master.ts', 'master.baseline.ts')]:
    original = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=REPO)
    assert original == (ROOT / 'recovery208-baseline2' / stored).read_bytes()

node = ROOT / 'tools/node-v24.19.0-linux-x64/bin/node'
node_hash = sha(node.read_bytes())
assert fixed['runtime'] == baseline['runtime'] == 'v24.19.0'
assert node_hash == fixed['runtimeBinarySha256'] == baseline['runtimeBinarySha256']

fixed_pids = {child['pid'] for child in fixed['children']}
for case in fixed['cases']:
    for launch in case.get('launches', []): fixed_pids.add(launch['pid'])
baseline_pids = {child['pid'] for child in baseline['children']}
assert fixed_pids | baseline_pids == set(postflight['observedPids'])
assert len(fixed_pids) == 13 and len(baseline_pids) == 4
for case in fixed['cases']:
    if 'assignment-replay' in case['mode']:
        assert case['logicalInputs'] == case['physicalMessages'] == 6
        assert case['intentionalReplayDuplicates'] == 0
        assert case['exits'][0]['code'] is None and case['exits'][0]['signal'] == 'SIGKILL'
        assert case['exits'][1]['code'] == 0 and case['exits'][1]['signal'] is None
        assert any(msg.get('sourceHeld') is True for msg in case['messages'])
    else:
        assert case['outcome'] == {'code': 0 if case['mode'] == 'normal' else 1, 'signal': None}
        assert case['logicalInputs'] == 3
        assert case['physicalMessages'] == (3 if case['mode'] == 'normal' else 6)
for case in baseline['cases']:
    if case['mode'] in ['nack', 'lost']:
        assert case['unsupportedCompletion'] and case['successfulReadReports'] == 0
    else:
        assert case['missing'] == [13, 14, 15] and case['unsupportedSchedulerFinished']
        assert [[item['first'], item['end']] for item in case['launches']] == [[10, 13], [10, 13]]

add(Path(__file__), 'validation/package-h45-208-evidence.py', 'packaging-verifier')
summary = {
    'schema': 1, 'status': 'passed', 'date': '2026-10-19', 'host': 'Hyperion-1', 'run': RUN,
    'runtime': {'node': fixed['runtime'], 'binarySha256': node_hash},
    'implementation': {'baselineCommit': BASE, 'runtimeCommit': RUNTIME, 'harnessCommit': HARNESS,
                       'sourceMatches': len(source_matches), 'sourceBytesVerifiedAgainstMeasuredReports': True},
    'fixed': {'status': fixed['status'], 'cases': [{key: case[key] for key in ['mode', 'logicalInputs', 'physicalMessages', 'intentionalReplayDuplicates']} for case in fixed['cases']], 'observedProcessCount': len(fixed_pids)},
    'baseline': {'status': baseline['status'], 'cases': [{'mode': case['mode'], 'status': case['status'], 'unsupportedCompletion': case.get('unsupportedCompletion'), 'missingInputs': case.get('missing', [])} for case in baseline['cases']], 'observedProcessCount': len(baseline_pids), 'compiler': baseline['baselineCompiler']},
    'postflight': {'status': postflight['status'], 'observedProcessCount': len(postflight['observedPids']), 'consecutiveIdleSamples': 3, 'observedProcessesGone': True, 'brokerQueues': 0, 'brokerConnections': 0, 'activeSearchWrites': 0},
    'cleanup': {'ownedContainersRemoved': 7, 'ownedVolumesRemoved': 7, 'ownedNetworksRemoved': 1, 'remainingOwnedResources': 0, 'completedAt': cleanup['completedAt']},
    'limits': ['Shared host; correctness qualification only, no capacity or throughput conclusion.', 'Synthetic numeric source payloads; SHIP decoding, ABI transition, Elasticsearch durability and full master construction are not covered.', 'Live fork/restart and broker-delivered late old-generation callbacks remain open acceptance in #208.', 'Master/host/power-loss durability is not established.', 'Baseline --noCheck emission preserves original sources for semantic counterexamples; it is not a baseline typecheck claim.'],
    'excludedPilots': ['case1/case2: proxy-upstream self-loop prevented AMQP startup; no broker acceptance claim.', 'case3: successful pilot without a held later source; excluded from replay-gap acceptance.', 'baseline: duplicate-class nominal type conflicts stopped baseline preparation before broker execution.']
}

DEST.mkdir()
archive_path = DEST / 'raw-evidence.tar.gz'
with archive_path.open('xb') as output:
    with gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, member in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(member['data']); info.mtime = 0; info.uid = info.gid = 0; info.mode = 0o644
                archive.addfile(info, io.BytesIO(member['data']))
with tarfile.open(archive_path, 'r:gz') as archive:
    observed = {}
    for member in archive.getmembers():
        assert member.isfile() and not member.issym() and not member.islnk()
        data = archive.extractfile(member).read()
        assert data == members[member.name]['data']
        observed[member.name] = {'bytes': len(data), 'sha256': sha(data), 'role': members[member.name]['role']}
    assert set(observed) == set(members)
manifest = {'schema': 1, 'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'archive': {'path': archive_path.name, 'bytes': archive_path.stat().st_size, 'sha256': sha(archive_path.read_bytes()),
                'regularMembers': len(observed), 'uncompressedBytes': sum(member['bytes'] for member in observed.values())},
    'sourceMatches': source_matches, 'members': observed}
(DEST / 'summary.json').write_bytes(encode(summary))
(DEST / 'manifest.json').write_bytes(encode(manifest))
(DEST / '.gitattributes').write_bytes(b'raw-evidence.tar.gz binary\nmanifest.json -text\nsummary.json -text\nSHA256SUMS -text\n.gitattributes -text\n')
names = ['raw-evidence.tar.gz', 'manifest.json', 'summary.json', '.gitattributes']
(DEST / 'SHA256SUMS').write_bytes(''.join(sha((DEST / name).read_bytes()) + '  ' + name + '\n' for name in names).encode())
print(json.dumps({'status': 'passed', 'destination': str(DEST), 'members': len(observed), 'sourceMatches': len(source_matches), 'archive': manifest['archive']}))
