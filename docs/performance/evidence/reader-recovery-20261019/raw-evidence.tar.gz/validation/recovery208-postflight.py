import pathlib,json,urllib.request,base64,os,time,datetime,hashlib
root=pathlib.Path('/var/snap/docker/common/hyperion-qualification/run-20261019-195-208')
state_path=root/'fixture208.json';state=json.loads(state_path.read_text())
fixed=json.loads((root/'recovery208-final/report.json').read_text());baseline=json.loads((root/'recovery208-baseline2/report.json').read_text())
assert fixed['status']=='passed' and len(fixed['cases'])==7
assert baseline['status']=='defects-reproduced' and len(baseline['cases'])==3
assert fixed['run']==baseline['run']==state['run']
pids=set()
def visit(value):
 if isinstance(value,dict):
  if isinstance(value.get('pid'),int):pids.add(value['pid'])
  for child in value.values():visit(child)
 elif isinstance(value,list):
  for child in value:visit(child)
visit(fixed['children']);visit(baseline['children'])
for row in fixed['cases']+baseline['cases']:
 visit(row.get('launches',[]));visit(row.get('exits',[]))
def get(url,auth=False):
 headers={}
 if auth:headers['Authorization']='Basic '+base64.b64encode(b'qualifier:qualifier-test-only').decode()
 with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=10) as response:return json.load(response)
samples=[]
for number in range(3):
 alive=[pid for pid in sorted(pids) if pathlib.Path('/proc',str(pid)).exists()]
 queues=get(state['core']['broker']['managementUrl']+'/api/queues/%2F',True)
 connections=get(state['core']['broker']['managementUrl']+'/api/connections',True)
 tasks=get(state['core']['nodes'][0]['url']+'/_tasks?detailed=true')
 work=[task for node in tasks['nodes'].values() for task in node.get('tasks',{}).values() if any(term in task.get('action','') for term in ['indices:data/write','indices:data/read/search'])]
 assert not alive and not queues and not connections and not work,(alive,queues,connections,work)
 samples.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observedPidsAlive':alive,'brokerQueues':len(queues),'brokerConnections':len(connections),'activeSearchWrites':len(work)})
 if number<2:time.sleep(1)
result={'status':'passed','run':state['run'],'fixtureManifestSha256':hashlib.sha256(state_path.read_bytes()).hexdigest(),'observedPids':sorted(pids),'consecutiveIdleSamples':3,'samples':samples,'scope':'Fixed and baseline owned worker PIDs, zero broker queues/connections and no active ES search/write tasks before exact fixture cleanup.'}
(root/'evidence/recovery208-postflight.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'pids':len(pids),'samples':3}))
