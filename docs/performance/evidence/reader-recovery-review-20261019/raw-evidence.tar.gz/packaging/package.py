"""Package completed PR210 review follow-up; read-only inputs, regular members."""
import pathlib,runpy,json,hashlib,uuid,os
from datetime import datetime,timezone
repo=pathlib.Path(r'C:/Users/igorl/.codex/worktrees/hyperion45-reader-recovery/hyperion-history-api')
scratch=pathlib.Path(r'C:/Users/igorl/.codex/scratch'); raw=scratch/'h45-210-review5574356339-evidence/raw'
helper=scratch/'es198-workers-package.py';h=runpy.run_path(str(helper));require=h['require'];read=h['read_json'];sha=h['file_sha'];enc=h['encoded']
source='94c89bcd499e7ef888f6acff8fae4a664ca83188'
name='recovery208-review5574356339';out=raw/name;ops=raw/'evidence'/name
report=read(out/'report.json');post=read(ops/'postflight.json');prep=read(ops/'preparation.json');final=read(ops/'final-run.json')
state=read(raw/'fixture208-review5574356339.json');cleanup=read(raw/'fixture208-review5574356339.json.cleanup.json')
require(report['status']=='passed' and post['status']=='passed' and final['status']=='passed','Final qualification/postflight incomplete')
require(post['sourceCommit']==final['sourceCommit']==prep['sourceCommit']==source,'Wrong frozen runtime')
require(report['run']==post['run']==final['run']==state['run']==cleanup['run'],'Fixture identity mismatch')
require(report['runtime']==prep['nodeVersion']=='v24.19.0' and prep['bunVersion']=='1.4.3','Wrong runtime')
require(report['runtimeBinarySha256']==prep['nodeBinarySha256']=='bc17c508ffeed0ec622934f9b7fa72f8e78da65350e63c3eceb56fa688aa5e12','Measured Node binary mismatch')
require(post['reportSha256']==sha(out/'report.json') and post['fixtureManifestSha256']==sha(raw/'fixture208-review5574356339.json'),'Postflight byte identity mismatch')
require(report['amqpErrors']==[] and report['cleanup']['errors']==[] and report['cleanup']['childProcessesRemaining']==0,'Final harness cleanup failed')
require(all(row['exitCode']==0 for row in final['commands']) and len(final['commands'])==3,'Final driver commands failed')
require(all(row.get('exitCode')==0 for row in prep['commands'] if row['name']!='qualification'),'Preparation/build/unit failure')
require({row['name'] for row in prep['commands']} >= {'clone','fetch','checkout','typecheck','build','qualification-typecheck','unit','fixture-create'},'Preparation provenance missing')
require(prep['sourceStatusBeforeBuild']=='?? node_modules\n','Unexpected checkout changes before build')
modes=['normal','nack','lost','channel','replace','historical-later-assignment-replay','repair-assignment-replay']
require([case['mode'] for case in report['cases']]==modes and all(case['status']=='passed' for case in report['cases']),'Seven broker cases missing')
pids={row['pid'] for row in report['children']};require(len(pids)==9,'Simple reader process evidence differs')
logical=physical=duplicates=0
for case in report['cases']:
 logical+=case['logicalInputs'];physical+=case['physicalMessages'];duplicates+=case['intentionalReplayDuplicates']
 if 'launches' in case:
  require(len(case['launches'])==len(case['exits'])==2,'Supervised replacement evidence missing')
  require(case['launches'][0]['assignment']!=case['launches'][1]['assignment'],'Assignment replacement not fenced')
  require(case['logicalInputs']==case['physicalMessages']==6 and case['intentionalReplayDuplicates']==0,'Scheduled replay coverage differs')
  require([{'code':r['code'],'signal':r['signal']} for r in case['exits']]==[{'code':None,'signal':'SIGKILL'},{'code':0,'signal':None}],'Unexpected scheduled child outcome')
  pids.update(row['pid'] for row in case['launches'])
 else:
  normal=case['mode']=='normal';require(case['outcome']=={'code':0 if normal else 1,'signal':None},'Unexpected simple worker outcome')
  require(case['logicalInputs']==3 and case['physicalMessages']==(3 if normal else 6),'Simple replay coverage differs')
  require(sum(row.get('event')=='completed' for row in case['messages'])==(1 if normal else 0),'Unsupported reader completion')
require(len(pids)==13 and sorted(pids)==post['observedPids'],'Postflight process coverage differs')
require(post['consecutiveIdleSamples']==len(post['samples'])==3,'Idle samples missing')
for sample in post['samples']:
 require(sample['observedPidsAlive']==[] and all(sample[key]==0 for key in ['brokerQueues','brokerMessages','brokerUnacked','brokerConsumers','brokerConnections','activeSearchWrites']),'Owned process/services not idle')
require(post['verifiedSourceSnapshots']==len(report['sources'])==8,'Measured snapshots missing')
for relative,entry in report['sources'].items():
 p=ops/'sources'/relative;require(p.stat().st_size==entry['bytes'] and sha(p)==entry['sha256'],'Measured source digest mismatch: '+relative)
for relative,entry in post['supportingSources'].items():
 p=ops/'supporting-sources'/relative;require(p.stat().st_size==entry['bytes'] and sha(p)==entry['sha256'],'Supporting source/native digest mismatch: '+relative)
core=cleanup['coreCleanup'];expected_core=state['core']['nodes']+[state['core']['broker']];extras=[state['redis'],state['mongo'],state['spring']]
require(set(cleanup['extraContainers'])=={x['containerId'] for x in extras} and set(cleanup['extraVolumes'])=={x['volume'] for x in extras},'Extra resource cleanup differs')
require(set(core['containers'])=={x['containerId'] for x in expected_core} and set(core['volumes'])=={x['volume'] for x in expected_core} and core['network']==state['network'],'Core resource cleanup differs')
require(all(core[key]==0 for key in ['remainingContainers','remainingVolumes','remainingNetworks']),'Owned fixture resources remain')
pilot=raw/(name+'-pilot-auth');pilot_report=read(pilot/'report.json')
require(pilot_report['status']=='failed' and pilot_report['cases']==pilot_report['children']==[] and pilot_report['cleanup']['errors']==[],'Excluded orchestration pilot scope differs')
require(sha(pilot/'report.json')==final['excludedPilot']['reportSha256'],'Excluded pilot report changed')
unit=(ops/'unit.log').read_text();require('247 pass' in unit and '0 fail' in unit and '1949 expect() calls' in unit,'Full Linux unit acceptance missing')
bundle=scratch/'h45-210-review5574356339.bundle';require(sha(bundle)==prep['bundleSha256'],'Transferred source bundle differs')
archive=h['Archive'](repo,scratch)
archive.tree('run/final',out,'Native Linux broker/worker review-fix smoke; seven cases, no baseline rerun',status='passed',run=state['run'])
archive.tree('operations',ops,'Exact setup/check/source/native bytes, independent postflight and guarded cleanup logs',status='passed',run=state['run'])
archive.tree('pilots/excluded-auth',pilot,'Excluded orchestration credential-duplication attempt; no cases, workers or queues',status='excluded-failed',run=state['run'])
for p in sorted(raw.glob('fixture208-review5574356339.json*')):archive.add('fixture/'+p.name,path=p,role='Exact owned fixture identities and cleanup receipts',run=state['run'])
archive.add('operations/preparation-driver.py',path=raw/'evidence/h45-210-review5574356339-run.py',role='Initial preparation driver; its URL construction failed before the excluded pilot did work')
archive.add('source/review.bundle',path=bundle,role='Exact frozen review-fix commit bundle; requires base37e3ee6')
windows=['h45-pr210-runtime-red.log','h45-pr210-review-full-unit.log','h45-210-cli-review-red.log','h45-210-cli-review-green.log']
for name in windows:archive.add('validation/windows/'+name,path=scratch/name,role='Root-supplied Windows review red/green/full-suite evidence using explicit Node24 native probes')
archive.add('packaging/package.py',path=pathlib.Path(__file__),role='Evidence packager; not measured runtime')
archive.add('packaging/regular-archive-writer.py',path=helper,role='Bounded regular-file archive writer with complete member readback')
original=read(repo/'docs/performance/evidence/reader-recovery-20261019/manifest.json')
limits=['This is a review-fix correctness follow-up using numeric source inputs and real native Node worker/broker processes; baseline counterexamples were not rerun.',
 'The new timeout/channel/finish bounds and CLI failure exits have focused regressions; the seven native broker cases are the existing integration smoke, not elapsed-time boundary fault injection.',
 'The load-hook CLI regressions stub only the expensive workload in isolated child-process copies; their original cleanup/report/CLI status tails execute. They do not qualify a real broker.',
 'Thirteen observed child workers include expected exit1 recoveries and two deliberate SIGKILL crashes; final replacements exit0 and no processes remain.',
 'No full-chain SHIP decoding, live-fork recovery, Elasticsearch durability, master restart, host power loss, throughput or runtime capacity claim.',
 'Dependencies were reused through a documented symlink to the existing pinned npm tree without reinstall or mutation. Source/build/native snapshots and the lock are retained.',
 'The credential-duplication orchestration pilot is preserved and excluded; it failed before any cases, workers or queues. Existing qualification and baseline evidence remain unchanged.',
 'Fixture credentials and producer key are public test-only data for the isolated disposable services.']
summary={'schemaVersion':1,'status':'passed','review':'https://github.com/eosrio/hyperion-history-api/pull/210#pullrequestreview-5574356339','sourceCommit':source,
 'fixtureRun':state['run'],'host':prep['host'],'runtime':{'node':report['runtime'],'nodeBinarySha256':report['runtimeBinarySha256'],'bun':prep['bunVersion']},
 'cases':[{'mode':c['mode'],'status':c['status'],'logicalInputs':c['logicalInputs'],'physicalMessages':c['physicalMessages'],'intentionalReplayDuplicates':c['intentionalReplayDuplicates']} for c in report['cases']],
 'caseCount':7,'observedWorkerProcesses':13,'logicalCaseInputs':logical,'physicalMessages':physical,'intentionalReplayDuplicates':duplicates,
 'measuredSourceSnapshots':len(report['sources']),'supportingSourceNativeSnapshots':len(post['supportingSources']),
 'validation':{'linuxUnitCases':247,'linuxAssertions':1949,'applicationTypecheck':'passed','build':'passed','qualifierTypecheck':'passed','windowsLogs':windows},
 'postflight':{'status':post['status'],'consecutiveIdleSamples':3,'observedPidsAlive':[],'brokerQueues':0,'brokerConnections':0,'activeSearchWrites':0},
 'fixtureCleanup':{'containers':7,'volumes':7,'networks':1,'remaining':0},'excludedPilot':final['excludedPilot'],
 'originalEvidenceArchiveSha256':original['archive']['sha256'],'limits':limits}
archive.add('README.json',data=enc({'scope':'Review5574356339 native Linux follow-up at frozen94c89; original qualification unchanged','limits':limits}),role='Evidence interpretation')
candidate=scratch/('h45-210-review-candidate-'+uuid.uuid4().hex+'.tar.gz');archive.write_and_verify(candidate)
dest=repo/'docs/performance/evidence/reader-recovery-review-20261019';require(not dest.exists(),'Evidence destination already exists');dest.mkdir()
manifest={'schemaVersion':1,'createdAt':datetime.now(timezone.utc).isoformat(),'sourceCommit':source,'archive':'raw-evidence.tar.gz','archiveSha256':sha(candidate),'memberCount':len(archive.members),'members':[archive.members[k][0] for k in sorted(archive.members)],
 'sourceProvenance':'Measured source/build snapshots are exact report-hashed bytes; supporting native/source bytes are independently hashed in postflight. Local review tests, excluded pilot and packaging support have distinct roles.'}
files={'raw-evidence.tar.gz':candidate.read_bytes(),'summary.json':enc(summary),'manifest.json':enc(manifest),'.gitattributes':b'raw-evidence.tar.gz binary\nsummary.json -text\nmanifest.json -text\nSHA256SUMS -text\n.gitattributes -text\n'}
for name,data in files.items():
 with (dest/name).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
checks=''.join(sha(dest/name)+'  '+name+'\n' for name in files).encode()
with (dest/'SHA256SUMS').open('xb') as f:f.write(checks);f.flush();os.fsync(f.fileno())
for line in checks.decode().splitlines():
 digest,name=line.split('  ');require(sha(dest/name)==digest,'Outer checksum readback mismatch')
print(json.dumps({'status':'packaged','destination':str(dest),'archiveSha256':manifest['archiveSha256'],'archiveBytes':(dest/'raw-evidence.tar.gz').stat().st_size,'members':len(archive.members),'rawBytes':archive.total,'summary':summary}))
