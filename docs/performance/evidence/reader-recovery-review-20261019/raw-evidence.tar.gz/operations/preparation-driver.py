import pathlib,subprocess,os,json,hashlib,datetime,socket,urllib.parse
root=pathlib.Path('/var/snap/docker/common/hyperion-qualification/run-20261019-195-208')
checkout=root/'recovery-review5574356339'; evidence=root/'evidence'/'recovery208-review5574356339'
fixture=root/'fixture208-review5574356339.json'; output=root/'recovery208-review5574356339'
source='94c89bcd499e7ef888f6acff8fae4a664ca83188'
assert socket.gethostname()=='x570-hyperion-1'
assert not checkout.exists() and not evidence.exists() and not fixture.exists() and not output.exists()
evidence.mkdir()
env=os.environ.copy();node=root/'tools/node-v24.19.0-linux-x64/bin/node'
env['PATH']=str(node.parent)+':'+str(root/'tools/pwsh')+':'+str(root/'tools/bun-linux-x64')+':'+env['PATH']
env['READER_RECOVERY_NODE']=str(node)
metadata={'schemaVersion':1,'status':'running','sourceCommit':source,'host':socket.gethostname(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save():
 (evidence/'preparation.json').write_text(json.dumps(metadata,indent=2)+'\n')
def run(name,args,cwd=root,timeout=240):
 print(name,flush=True);row={'name':name,'args':[str(a) for a in args],'cwd':str(cwd),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};metadata['commands'].append(row);save()
 with (evidence/(name+'.log')).open('xb') as log:
  result=subprocess.run([str(a) for a in args],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 row['exitCode']=result.returncode;row['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 assert result.returncode==0,(name,result.returncode)
try:
 assert subprocess.check_output(['docker','ps','-a','--format','{{.ID}}']).strip()==b'', 'Unexpected existing Docker containers'
 metadata['nodeVersion']=subprocess.check_output([str(node),'--version']).decode().strip();assert metadata['nodeVersion']=='v24.19.0'
 metadata['nodeBinarySha256']=hashlib.sha256(node.read_bytes()).hexdigest()
 metadata['bunVersion']=subprocess.check_output(['bun','--version'],env=env).decode().strip();assert metadata['bunVersion']=='1.4.3'
 metadata['bundleSha256']=hashlib.sha256((root/'evidence/h45-210-review5574356339.bundle').read_bytes()).hexdigest()
 run('clone',['git','clone','--no-hardlinks',root/'recovery',checkout])
 run('fetch',['git','fetch',root/'evidence/h45-210-review5574356339.bundle','HEAD'],checkout)
 run('checkout',['git','checkout','--detach',source],checkout)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout).decode().strip()==source
 (checkout/'node_modules').symlink_to(root/'replay/node_modules',target_is_directory=True)
 metadata['dependencyBoundary']='Existing pinned replay/node_modules symlink, used without dependency installation or mutation.'
 metadata['lockSha256']=hashlib.sha256((checkout/'package-lock.json').read_bytes()).hexdigest()
 metadata['sourceStatusBeforeBuild']=subprocess.check_output(['git','status','--porcelain'],cwd=checkout).decode()
 run('typecheck',['npm','run','typecheck'],checkout)
 run('build',['npm','run','build'],checkout)
 run('qualification-typecheck',['bun','check','-p','scripts/qualification/tsconfig.json'],checkout)
 run('unit',['bun','test','tests/unit'],checkout)
 run('fixture-create',['pwsh','-NoProfile','-File','scripts/qualification/es955-worker-fixture.ps1','-Action','create','-StateFile',fixture],checkout,360)
 state=json.loads(fixture.read_bytes());metadata['fixtureRun']=state['run'];metadata['fixtureManifestSha256']=hashlib.sha256(fixture.read_bytes()).hexdigest();save()
 broker=urllib.parse.urlsplit(state['core']['broker']['url'])
 env['READER_RECOVERY_AMQP_URL']=urllib.parse.urlunsplit((broker.scheme,'qualifier:qualifier-test-only@'+broker.netloc,broker.path,broker.query,broker.fragment))
 env['READER_RECOVERY_RUN']=state['run']
 run('qualification',[node,'scripts/qualification/reader-recovery.mjs',output],checkout,180)
 report=json.loads((output/'report.json').read_bytes());assert report['status']=='passed' and len(report['cases'])==7
 metadata['status']='qualification-passed-awaiting-independent-postflight';save()
 print(json.dumps({'status':metadata['status'],'run':state['run'],'output':str(output)}),flush=True)
except Exception as error:
 metadata['status']='failed';metadata['error']=str(error);save();raise
