import pathlib,json,subprocess,os,datetime,urllib.parse,hashlib,urllib.request,base64
root=pathlib.Path('/var/snap/docker/common/hyperion-qualification/run-20261019-195-208')
checkout=root/'recovery-review5574356339';evidence=root/'evidence/recovery208-review5574356339'
fixture=root/'fixture208-review5574356339.json';state=json.loads(fixture.read_bytes())
output=root/'recovery208-review5574356339';pilot=root/'recovery208-review5574356339-pilot-auth'
old=json.loads((output/'report.json').read_bytes())
assert old['status']=='failed' and old['cases']==[] and old['children']==[] and old['cleanup']['errors']==[] and old['cleanup']['childProcessesRemaining']==0
request=urllib.request.Request(state['core']['broker']['managementUrl']+'/api/queues/%2F',headers={'Authorization':'Basic '+base64.b64encode(b'qualifier:qualifier-test-only').decode()})
with urllib.request.urlopen(request,timeout=10) as response:assert json.load(response)==[]
assert output.resolve().parent==root and pilot.resolve().parent==root and not pilot.exists()
output.rename(pilot)
env=os.environ.copy();node=root/'tools/node-v24.19.0-linux-x64/bin/node'
env['PATH']=str(node.parent)+':'+str(root/'tools/pwsh')+':'+str(root/'tools/bun-linux-x64')+':'+env['PATH']
url=state['core']['broker']['url'];parsed=urllib.parse.urlsplit(url)
assert parsed.username=='qualifier' and parsed.password=='qualifier-test-only' and parsed.hostname=='127.0.0.1'
env['READER_RECOVERY_AMQP_URL']=url;env['READER_RECOVERY_RUN']=state['run'];env['READER_RECOVERY_NODE']=str(node)
metadata={'schemaVersion':1,'status':'running','sourceCommit':'94c89bcd499e7ef888f6acff8fae4a664ca83188','run':state['run'],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'excludedPilot':{'directory':pilot.name,'reportSha256':hashlib.sha256((pilot/'report.json').read_bytes()).hexdigest(),'reason':'Orchestration duplicated existing test credentials in URL; rejected before cases/workers/queues. Frozen runtime unchanged.'},'commands':[]}
def save():(evidence/'final-run.json').write_text(json.dumps(metadata,indent=2)+'\n')
def run(name,args,timeout=180):
 print(name,flush=True);row={'name':name,'args':[str(a) for a in args],'cwd':str(checkout),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};metadata['commands'].append(row);save()
 with (evidence/(name+'.log')).open('xb') as log:r=subprocess.run([str(a) for a in args],cwd=checkout,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 row['exitCode']=r.returncode;row['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();assert r.returncode==0,(name,r.returncode)
try:
 run('qualification-final',[node,'scripts/qualification/reader-recovery.mjs',output])
 report=json.loads((output/'report.json').read_bytes());assert report['status']=='passed' and len(report['cases'])==7
 run('postflight',['python3',evidence/'postflight.py'])
 run('fixture-cleanup',['pwsh','-NoProfile','-File','scripts/qualification/es955-worker-fixture.ps1','-Action','cleanup','-StateFile',fixture])
 cleanup=json.loads(pathlib.Path(str(fixture)+'.cleanup.json').read_bytes());assert cleanup['run']==state['run']
 assert len(cleanup['extraContainers'])==len(cleanup['extraVolumes'])==3
 assert len(cleanup['coreCleanup']['containers'])==len(cleanup['coreCleanup']['volumes'])==4
 assert all(cleanup['coreCleanup'][k]==0 for k in ['remainingContainers','remainingVolumes','remainingNetworks'])
 metadata['status']='passed';metadata['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(metadata),flush=True)
except Exception as error:
 metadata['status']='failed';metadata['error']=str(error);save();raise
