import pathlib,json,hashlib,datetime,urllib.request,base64,time,subprocess,os
root=pathlib.Path('/var/snap/docker/common/hyperion-qualification/run-20261019-195-208')
checkout=root/'recovery-review5574356339'; evidence=root/'evidence/recovery208-review5574356339'
state_path=root/'fixture208-review5574356339.json'; state=json.loads(state_path.read_bytes())
out=root/'recovery208-review5574356339'; report=json.loads((out/'report.json').read_bytes())
source='94c89bcd499e7ef888f6acff8fae4a664ca83188'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout).decode().strip()==source
assert report['status']=='passed' and report['run']==state['run'] and len(report['cases'])==7
assert all(case['status']=='passed' for case in report['cases'])
assert report['amqpErrors']==[] and report['cleanup']['errors']==[] and report['cleanup']['childProcessesRemaining']==0
for relative,entry in report['sources'].items():
 data=(checkout/relative).read_bytes();assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],relative
 target=evidence/'sources'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
pids=set()
for child in report['children']:
 pids.add(child['pid']);assert child['outcome']['signal'] is None and child['outcome']['code'] in [0,1]
for case in report['cases']:
 if case['mode'] in ['historical-later-assignment-replay','repair-assignment-replay']:
  assert len(case['launches'])==len(case['exits'])==2
  assert case['launches'][0]['assignment']!=case['launches'][1]['assignment']
  assert case['logicalInputs']==case['physicalMessages']==6 and case['intentionalReplayDuplicates']==0
  assert [{'code':row['code'],'signal':row['signal']} for row in case['exits']]==[{'code':None,'signal':'SIGKILL'},{'code':0,'signal':None}]
  pids.update(row['pid'] for row in case['launches'])
 else:
  healthy=case['mode']=='normal';assert case['outcome']=={'code':0 if healthy else 1,'signal':None}
  assert case['logicalInputs']==3 and case['physicalMessages']==(3 if healthy else 6)
assert len(pids)==13
auth='Basic '+base64.b64encode(b'qualifier:qualifier-test-only').decode()
def get(url,broker=False):
 request=urllib.request.Request(url,headers={'Authorization':auth} if broker else {})
 with urllib.request.urlopen(request,timeout=10) as response:return json.load(response)
samples=[]
for number in range(3):
 alive=[pid for pid in sorted(pids) if pathlib.Path('/proc',str(pid)).exists()]
 queues=get(state['core']['broker']['managementUrl']+'/api/queues/%2F',True)
 connections=get(state['core']['broker']['managementUrl']+'/api/connections',True)
 tasks=get(state['core']['nodes'][0]['url']+'/_tasks?detailed=true')
 work=[task for node in tasks['nodes'].values() for task in node.get('tasks',{}).values() if any(term in task.get('action','') for term in ['indices:data/write','indices:data/read/search'])]
 sample={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observedPidsAlive':alive,'brokerQueues':len(queues),'brokerMessages':sum(q['messages'] for q in queues),'brokerUnacked':sum(q['messages_unacknowledged'] for q in queues),'brokerConsumers':sum(q['consumers'] for q in queues),'brokerConnections':len(connections),'activeSearchWrites':len(work)}
 assert not alive and all(sample[key]==0 for key in ['brokerQueues','brokerMessages','brokerUnacked','brokerConsumers','brokerConnections','activeSearchWrites']),sample
 samples.append(sample)
 if number<2:time.sleep(1)
native={}
for relative in ['package.json','.bun-version','scripts/qualification/reader-recovery-baseline.mjs','src/indexer/helpers/reader-progress.ts','src/indexer/workers/state-reader.ts','src/indexer/modules/master.ts','tests/unit/state-reader-backpressure.test.ts','tests/unit/reader-recovery-cli.test.ts','node_modules/@eosrio/node-abieos/package.json','node_modules/@eosrio/node-abieos/dist/abieos-linux-x64.node','node_modules/uWebSockets.js/package.json','node_modules/uWebSockets.js/uws_linux_x64_137.node']:
 data=(checkout/relative).read_bytes();target=evidence/'supporting-sources'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 native[relative]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
result={'schemaVersion':1,'status':'passed','run':state['run'],'sourceCommit':source,'fixtureManifestSha256':hashlib.sha256(state_path.read_bytes()).hexdigest(),'reportSha256':hashlib.sha256((out/'report.json').read_bytes()).hexdigest(),'verifiedSourceSnapshots':len(report['sources']),'observedPids':sorted(pids),'consecutiveIdleSamples':3,'samples':samples,'supportingSources':native,'scope':'Read-only verification of review-fix methods, native broker cases, source bytes and owned PID/broker/ES idle state before cleanup. Baseline counterexamples were not rerun. No full-chain, live-fork, master/host failure or performance claim.'}
(evidence/'postflight.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
