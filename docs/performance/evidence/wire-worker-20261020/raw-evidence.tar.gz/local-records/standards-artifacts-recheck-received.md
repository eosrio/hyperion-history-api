Standards recheck: Wire artifact retention at 3071e0d

Compared immutable Git objects 09eee5286c6e5b2ee88b36328c4180d4913d85db...3071e0dfccc2531f600dc053af89592e364c9ba7. Both refs resolve; the nonempty comparison is one commit and four files (104 additions, seven removals). Only the committed artifact-retention changes were reviewed. Dirty output-checker files in the source-proof lane were excluded. No code edits, services or tests were started by this reviewer.

Result: the prior P2 extension-identity retention finding is closed. No new actionable documented-standard or smell findings in this correction.

Evidence:
- scripts/qualification/wire-replay-fixture.ts:219-225 preserves a detached, frozen copy of the selected Node/Rust components in lineage, including their manifest identities.
- scripts/qualification/wire-worker-replay.ts:177-207 reads package/profile/provider descriptors plus both component manifests, checks manifest hashes against the audited selected components, validates source revision and schema, and verifies every declared member digest. Members must use relative ordinary path components; dot/dot-dot, rooted paths and backslashes fail validation. Existing ordinary-file checks reject symlink parents/files. Each file is bounded to 16 MiB, each manifest to 512 members, and verified member bytes to 32 MiB.
- wire-worker-replay.ts:210-219 includes those bytes in the copied source snapshot and its 64 MiB total budget. Lines 274-279 save the starting hashes, copied sources, lineage and component identities before worker launch. Line 344 rereads and verifies the same selected artifacts and compares the complete hash map before setting passed.
- check-wire-replay-fixture.mjs:9,47 exposes the verified member count and selected identities in native-check output.
- tests/unit/wire-worker-replay.test.ts:35-64 covers executable drift with unchanged package metadata, manifest replacement, and traversal refusal.

The four-file correction satisfies the artifact-identity portion of Tools docs/performance/hyperion-4.5-profiling.md:252-255. This is a static Standards recheck; source-proof validity and full-worker/release qualification remain outside its scope.
