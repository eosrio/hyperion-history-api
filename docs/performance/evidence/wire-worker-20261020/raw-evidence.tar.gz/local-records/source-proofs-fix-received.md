# Wire replay oracle corrections

Task `task_wire_worker_source_proof_fix_20261020`; request `evt_20261020T111913_5abc37105ed7`; base `09eee5286c6e5b2ee88b36328c4180d4913d85db`. Lane `/root/action_coverage_flow`, shared identity `windows:codex:hyperion-tools`.

Only `scripts/qualification/wire-replay-outputs.ts` and its focused unit test changed. Both files are frozen. No production, dependency, service, commit or push changes occurred.

The read-only frontier oracle now configures one replica, matching the owned two-node fixture. Source-binding and observation records load through `ImmutableProtocolBundleStore` with `readOnly:true`, including initialization. The normal replica/mapping/retention compatibility guards stay active; no public store constructor can provision from this read path.

Every commit now resolves its immutable selection, source context, stable observation link and observation bundle. Exported production ID/fact validators check the stored records. Independent expectations verify original frame SHA, exact schema text, raw block/traces/deltas sections, source/head/LIB tuples, exact selected component set, full action-input membership, native ABI deployments and physical final account observations. Selected action and KV ABI account states must cite the corresponding retained native-effect or block-end facts. Presence of an arbitrary observation ID/digest grants nothing.

The output report retains all 119 source-proof identities and frame/capture/schema/section/facts hashes, plus their aggregate hash and the selected components. A separate `assertWireReplaySourceProofs` export checks retained content after shutdown; its return has no readiness/success certificate. The main assertion still requires the active source context/session, `following` phase and exact settled certificate.

The oracle now explicitly qualifies `sequenceStorageMode: legacy`, matching `ElasticRoutes`' default `engineering.exactActionSequenceStorage=false` and this fixture's disabled admission/engineering gates. It requires exact decimal strings in the existing root/receipt fields and rejects any `h45_sequences_v1` field in documents or publication bodies. It does not enable the gate or accept either representation opportunistically. Full-range/gated sequence indexing remains open under #225.

Validation: `bun test tests/unit/wire-replay-outputs.test.ts` on Bun 1.4.3 passed **64 tests, 0 failures, 103 assertions**, in 843 ms. Regressions cover the review's fabricated links on all 119 commits, missing/corrupt physical bundles, changed source/schema/components/ABI facts/provenance, unexpected gated sequence fields, and replica incompatibility. Actual production store envelopes are exercised against a simulated ES transport; oracle reads perform zero provisioning/writes and carry physical-node preference through every GET. These are resource-free component checks, not native acceptance.

Saved-pilot diagnostic: all eight postflight file hashes and source preparation/manifest/frame hashes were checked before reading. Independent component expectations came from `out/wire-full-worker/native-source-artifacts-node24.log`, not the frontier under test. Read-only production bundle/frontier readers plus the new source-content assertion validated all **119** source graphs, covering **16 actions, 15 history deltas and 38 selected-account ABI references**. Aggregate source-proof SHA-256: `17ecd8c29495d7eb879a0760dcc9f34128f6b5c7ec461b19f9332be56f0cfd93`. The offline adapter synthesized GET tokens and mapping responses around the saved bytes, so this result is explicitly **diagnostic only, acceptance:false**. Physical final-state order was retained; it is not account-name order.

The failed pilot completion result remains unchanged: its saved post-shutdown control is `awaiting-source`, generation `1f66a8cc-5e5f-40ec-b0f7-71cc8170acc9`. The real retained certificates, including block 120, belong to active generation `bb703a6e-68c5-470c-90cb-c5fe5c6781ef`. The full oracle refused the unavailable matching certificate; no certificate/control/exit was fabricated or normalized. Root owns fresh Linux acceptance runs and the separate shutdown investigation.

Remaining gates retain their prior scope: materialized dynamic-state deletion, actual ES deletes, secondary update/deletion, initial ABI frontier, full-width source sequences, fork/reconnect, selected testnet, full codec parity, public admission/sink/PIT readiness and runtime/performance qualification.

Patch `out/sequence-coverage/wire-replay-source-proofs-20261020.patch`: 64,119 bytes; SHA-256 `49ca68e27cb09c540677c62dffff63c74bec1a820566e21b3d4fd2bb98bd727b`.

Frozen module SHA-256 `d99d2f7dc33199b8e9deb0e3ea9a1c5a90a54dbdd0944d280b17ae7e942e0e44`; test SHA-256 `07bbeba30cc23e19ae59bc0e9f92bab077c22aaa362c15ca65b0004c4c5503d6`.
