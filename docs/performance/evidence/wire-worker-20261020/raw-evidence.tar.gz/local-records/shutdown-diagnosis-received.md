# Windows Wire pilot shutdown diagnosis

**The Windows pilot remains excluded from acceptance. No causal code fix is established or authorized by this evidence.**

The saved Node24 pilot has eleven child `shutdown.success:true` and JS `exit(0)` records at 11:11:45.619–.623 UTC. The master observed no child termination before its five-second deadline, then observed all eleven exits with `code:null, signal:SIGKILL`. Its own exit was1. [The original observer evidence](P:/eosrio/hyperion-tools/out/wire-full-worker/node24-pilot1-20261020-run/observer) is preserved.

This is a process-termination acceptance failure. A child JavaScript exit hook runs before the operating system has completed process teardown; that record cannot replace the parent's exit event. [The observer](P:/eosrio/hyperion-tools/out/wire-full-worker/hyperion-history-api/scripts/qualification/es955-worker-observer.mjs:162) correctly requires actual parent-observed outcomes. The separate replicas0/1 output-oracle error does not explain this shutdown result.

I ran21 bounded, owned cluster/observer probes under pinned Node22.23.3 and Node24.19.0, using byte-verified observer SHA256 `7d24d1035f714b9496484328b32ece03ddb44e3bc515f8661fb88e26c9e8b812`. All succeeded without forced children; ready-to-master-exit ranged52–475ms:

- Plain cluster; uWebSockets and node-abieos imports.
- Eleven children with pipe/file stdout and stderr.
- Process titles, uWS.App initialization, Abieos singleton initialization, common-worker import.
- Active owned loopback TCP, repeated fetch and Elasticsearch transport sockets.

These positives rule out those isolated conditions as sufficient explanations. They do not reproduce the full worker interaction or identify the post-JS teardown cause. Setup-path/observer-relocation failures are retained separately and excluded from the21 successful runs.

No timeout increase, relaxed exit validation, or core change is justified. Run the same corrected harness on Linux independently. A later Windows investigation needs a fresh owned actual run with exit-listener/resource and OS wait/native-stack evidence during the five-second gap.

[Probe receipts and per-file/pilot evidence hashes](P:/eosrio/hyperion-tools/out/sequence-coverage/wire-shutdown-probe-20261020/receipts.json): SHA256 `4753e5cd364e9f262bcba5295346958498b260f1d46a142da60ebe9820df711a`.

Only new out-directory probes/receipts were written. No source/driver edits, Docker writes, external service calls, unknown-PID kills, commits or pushes.
