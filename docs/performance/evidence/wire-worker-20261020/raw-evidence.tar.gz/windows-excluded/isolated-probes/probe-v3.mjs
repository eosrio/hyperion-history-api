import assert from 'node:assert/strict';
import cluster from 'node:cluster';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {join} from 'node:path';
const here = fileURLToPath(import.meta.url);
if (process.env.WIRE_SHUTDOWN_CHILD === '1') {
  if (cluster.isPrimary) {
    const worker = cluster.fork({worker_role:'probe_worker'});
    worker.on('message', message => {if(message.event === 'probe_ready') process.send?.(message);});
  } else {
    const target = process.env.WIRE_SHUTDOWN_MODULE;
    const require=createRequire(process.env.WIRE_SHUTDOWN_REPO+'/package.json');
    if(target==='title')process.title='hyp-hyp-wire-012345abcdef-ingestor:1';
    else if(target==='uws-app'){const m=await import(pathToFileURL(require.resolve('uWebSockets.js')).href);m.default.App();}
    else if(target==='abieos-context'){const m=await import(pathToFileURL(require.resolve('@eosrio/node-abieos')).href);m.Abieos.getInstance();}
    else if(target==='core-import')await import(pathToFileURL(process.env.WIRE_SHUTDOWN_REPO+'/build/indexer/workers/hyperionWorker.js').href);
    process.send?.({event:'probe_ready',module:target,childPid:process.pid,exitListeners:process.listeners('exit').map(fn=>fn.name||String(fn).slice(0,80))});
  }
} else {
  const [node, observer, repo, output] = process.argv.slice(2);
  assert(node && observer && repo && output);
  const results=[];
  for(const target of ['title','uws-app','abieos-context','core-import']) {
    const directory=join(output,target.replace(/[^a-zA-Z0-9]/g,'_')); await mkdir(directory);
    const env={...process.env, NODE_OPTIONS:'', ES198_OBSERVER_DIR:directory, ES198_CPU_PROFILE:'0',WIRE_SHUTDOWN_CHILD:'1',WIRE_SHUTDOWN_MODULE:target,WIRE_SHUTDOWN_REPO:repo};
    delete env.worker_role; delete env.ES198_ACTION_CRASH_CONTROL;
    const child=spawn(node,['--import',pathToFileURL(observer).href,here],{env,stdio:['ignore','pipe','pipe','ipc']});
    const record={target,node,pid:child.pid,startedAt:Date.now(),stdout:'',stderr:'',ready:null,exit:null};
    child.stdout.on('data',b=>{record.stdout+=(b.toString()).slice(0,64000-record.stdout.length);});
    child.stderr.on('data',b=>{record.stderr+=(b.toString()).slice(0,64000-record.stderr.length);});
    let timer; const exited=new Promise(resolve=>{child.once('exit',(code,signal)=>{record.exit={code,signal,at:Date.now()};clearTimeout(timer);resolve();});});
    child.on('message',message=>{if(message.event==='probe_ready' && !record.ready){record.ready={...message,at:Date.now()};child.send({event:'qualifier_shutdown',requestId:'wire-shutdown-probe-'+target});}});
    timer=setTimeout(()=>{record.deadline=true;child.kill('SIGKILL');},12000);
    await exited;
    results.push(record); await writeFile(join(directory,'controller.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
    console.log(JSON.stringify(record));
  }
  await writeFile(join(output,'summary.json'),JSON.stringify(results,null,2)+'\n',{flag:'wx'});
  process.exitCode=results.some(row=>row.exit.code!==0)?1:0;
}