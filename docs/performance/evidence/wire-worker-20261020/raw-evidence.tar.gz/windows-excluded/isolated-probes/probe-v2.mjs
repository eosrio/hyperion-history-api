import assert from 'node:assert/strict';
import cluster from 'node:cluster';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {mkdir, readFile, writeFile, open} from 'node:fs/promises';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {join} from 'node:path';
const here = fileURLToPath(import.meta.url);
if (process.env.WIRE_SHUTDOWN_CHILD === '1') {
  if (cluster.isPrimary) {
    let ready=0; const pids=[];
    for(let n=0;n<11;n++){const worker=cluster.fork({worker_role:'probe_worker'});pids.push(worker.process.pid);worker.on('message',message=>{if(message.event==='probe_ready' && ++ready===11)process.send?.({event:'probe_ready',count:ready,pids});});}
  } else {
    const target = process.env.WIRE_SHUTDOWN_MODULE;
    if (target !== 'none') {
      const require = createRequire(process.env.WIRE_SHUTDOWN_REPO + '/package.json');
      await import(pathToFileURL(require.resolve(target)).href);
    }
    process.send?.({event:'probe_ready',module:target,childPid:process.pid});
  }
} else {
  const [node, observer, repo, output] = process.argv.slice(2);
  assert(node && observer && repo && output);
  const results=[];
  for(const mode of ['pipe','file']) { const target='none';
    const directory=join(output,mode); await mkdir(directory);
    const env={...process.env, NODE_OPTIONS:'', ES198_OBSERVER_DIR:directory, ES198_CPU_PROFILE:'0',WIRE_SHUTDOWN_CHILD:'1',WIRE_SHUTDOWN_MODULE:target,WIRE_SHUTDOWN_REPO:repo};
    delete env.worker_role; delete env.ES198_ACTION_CRASH_CONTROL;
    const stdout=mode==='file'?await open(join(directory,'master.stdout'),'wx'):undefined;const stderr=mode==='file'?await open(join(directory,'master.stderr'),'wx'):undefined;
    const child=spawn(node,['--import',pathToFileURL(observer).href,here],{env,stdio:['ignore',stdout?.fd??'pipe',stderr?.fd??'pipe','ipc']});
    await stdout?.close();await stderr?.close();
    const record={target,mode,node,pid:child.pid,startedAt:Date.now(),stdout:'',stderr:'',ready:null,exit:null};
    child.stdout?.on('data',b=>{record.stdout+=(b.toString()).slice(0,64000-record.stdout.length);});
    child.stderr?.on('data',b=>{record.stderr+=(b.toString()).slice(0,64000-record.stderr.length);});
    let timer; const exited=new Promise(resolve=>{child.once('exit',(code,signal)=>{record.exit={code,signal,at:Date.now()};clearTimeout(timer);resolve();});});
    child.on('message',message=>{if(message.event==='probe_ready' && !record.ready){record.ready={...message,at:Date.now()};child.send({event:'qualifier_shutdown',requestId:'wire-shutdown-probe-'+target});}});
    timer=setTimeout(()=>{record.deadline=true;child.kill('SIGKILL');},12000);
    await exited;
    results.push(record); await writeFile(join(directory,'controller.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
    console.log(JSON.stringify(record));
  }
  await writeFile(join(output,'summary.json'),JSON.stringify(results,null,2)+'\n',{flag:'wx'});
  process.exitCode=results.some(row=>row.exit.code!==0)?1:0;
}