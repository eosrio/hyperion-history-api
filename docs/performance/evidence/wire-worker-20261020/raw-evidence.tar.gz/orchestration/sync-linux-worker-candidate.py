import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/var/snap/docker/common/hyperion-qualification/run-20261020-wire-workers')
repo = root / 'repo'
candidate = '5da54fb77699ce0a92d52f59c7569cb8d3e81ba7'
base = '5289dfa25b1ea47a1679f0a5eef6174f5226c47b'
patch = root / 'package-pin-8b7.patch'
assert not root.is_symlink() and not repo.is_symlink()
assert hashlib.sha256(patch.read_bytes()).hexdigest() == '58d4082d435d50bec987b95c776fd30697f3e931c768f665c7d313c2d822a410'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == base
changes = subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).splitlines()
assert set(changes) == {' M package-lock.json', ' M package.json'}, repr(changes)
subprocess.run(['git', 'apply', '--reverse', '--check', str(patch)], cwd=repo, check=True)
# Reverse only the previously hashed, owned two-file preparation patch.
subprocess.run(['git', 'apply', '--reverse', str(patch)], cwd=repo, check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
subprocess.run(['git', 'fetch', 'origin', 'codex/wire-full-worker-replay'], cwd=repo, check=True, timeout=90)
assert subprocess.check_output(['git', 'rev-parse', 'FETCH_HEAD'], cwd=repo, text=True).strip() == candidate
subprocess.run(['git', 'checkout', '-b', 'qualification/wire-full-worker-replay', candidate], cwd=repo, check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
preparation = json.loads((root / 'preparation.json').read_text())
env = os.environ.copy()
for name, record in preparation['runtimes'].items():
    assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['sha256']
node = Path(preparation['runtimes']['node24']['path'])
bun = Path(preparation['runtimes']['bun']['path'])
env['PATH'] = os.pathsep.join([str(node.parent), str(bun.parent), env['PATH']])
steps = [('typecheck-app', [bun, 'check', '-p', 'tsconfig.json']),
         ('typecheck-qualification', [bun, 'check', '-p', 'scripts/qualification/tsconfig.json']),
         ('build', [node, repo / 'node_modules/typescript/bin/tsc']),
         ('source-node24', [node, '--experimental-strip-types', 'scripts/qualification/check-wire-replay-fixture.mjs']),
         ('source-node22', [preparation['runtimes']['node22']['path'], '--experimental-strip-types', 'scripts/qualification/check-wire-replay-fixture.mjs'])]
receipt = {'schemaVersion': 1, 'sourceCommit': candidate, 'steps': []}
for name, args in steps:
    log_file = root / 'evidence' / (name + '.log')
    with log_file.open('xb') as log:
        result = subprocess.run([str(arg) for arg in args], cwd=repo, env=env, stdout=log,
                                stderr=subprocess.STDOUT, timeout=180)
    receipt['steps'].append({'name': name, 'exitCode': result.returncode,
                             'sha256': hashlib.sha256(log_file.read_bytes()).hexdigest()})
    if result.returncode != 0:
        receipt['status'] = 'failed'
        (root / 'evidence/candidate-checks.json').write_text(json.dumps(receipt, indent=2) + '\n')
        raise RuntimeError(name + ' failed; see retained log')
receipt['status'] = 'passed'
(root / 'evidence/candidate-checks.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
