import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import urllib.request

base = Path('/var/snap/docker/common/hyperion-qualification')
target = base / 'run-20261020-wire-workers'
old_tools = base / 'run-20261019-195-208/tools'
assert base.is_dir() and not base.is_symlink()
assert not target.exists() and not target.is_symlink(), 'refusing an existing run directory'
node24 = old_tools / 'node-v24.19.0-linux-x64/bin/node'
assert hashlib.sha256(node24.read_bytes()).hexdigest() == 'bc17c508ffeed0ec622934f9b7fa72f8e78da65350e63c3eceb56fa688aa5e12'
runtime_tools = {'node24': node24, 'bun': old_tools / 'bun-linux-x64/bun', 'pwsh': old_tools / 'pwsh/pwsh'}
versions = {}
for name, path in runtime_tools.items():
    result = subprocess.run([str(path), '--version'], check=True, capture_output=True, text=True, timeout=15)
    versions[name] = {'path': str(path), 'version': result.stdout.strip(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
assert versions['node24']['version'] == 'v24.19.0'
assert versions['bun']['version'] == '1.4.3'
target.mkdir()
(target / 'tools').mkdir()
(target / 'evidence').mkdir()
subprocess.run(['git', 'clone', '--depth', '1', '--branch', 'release/4.5',
                'https://github.com/eosrio/hyperion-history-api.git', str(target / 'repo')], check=True, timeout=180)
revision = subprocess.run(['git', '-C', str(target / 'repo'), 'rev-parse', 'HEAD'],
                          check=True, capture_output=True, text=True, timeout=10).stdout.strip()
assert revision == '5289dfa25b1ea47a1679f0a5eef6174f5226c47b', 'release changed; preserve clone for inspection'
version = 'v22.23.3'
bundle_name = f'node-{version}-linux-x64'
archive_name = bundle_name + '.tar.xz'
url = 'https://nodejs.org/dist/' + version + '/'
with urllib.request.urlopen(url + 'SHASUMS256.txt', timeout=30) as response:
    sums = response.read(256 * 1024)
assert len(sums) < 256 * 1024
matches = [line.split()[0] for line in sums.decode().splitlines() if line.split()[-1] == archive_name]
assert len(matches) == 1
archive = target / 'tools' / archive_name
with urllib.request.urlopen(url + archive_name, timeout=30) as response, archive.open('xb') as output:
    total = 0
    while True:
        chunk = response.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        assert total <= 64 * 1024 * 1024
        output.write(chunk)
    output.flush()
    os.fsync(output.fileno())
assert hashlib.sha256(archive.read_bytes()).hexdigest() == matches[0]
(target / 'tools/node22-SHASUMS256.txt').write_bytes(sums)
with tarfile.open(archive) as bundle:
    members = bundle.getmembers()
    assert len(members) <= 10000 and sum(member.size for member in members) <= 256 * 1024 * 1024
    for member in members:
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and path.parts[0] == bundle_name and '..' not in path.parts
        assert member.isfile() or member.isdir() or member.issym() or member.islnk()
    bundle.extractall(target / 'tools', filter='data')
node22 = target / 'tools' / bundle_name / 'bin/node'
result = subprocess.run([str(node22), '--version'], check=True, capture_output=True, text=True, timeout=10)
assert result.stdout.strip() == version
versions['node22'] = {'path': str(node22), 'version': version, 'sha256': hashlib.sha256(node22.read_bytes()).hexdigest(),
                      'archiveSha256': matches[0], 'officialChecksumsUrl': url + 'SHASUMS256.txt'}
receipt = {'schemaVersion': 1, 'status': 'source-and-runtimes-prepared', 'directory': str(target),
           'sourceRevision': revision, 'runtimes': versions, 'servicesCreated': False}
with (target / 'preparation.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt))
