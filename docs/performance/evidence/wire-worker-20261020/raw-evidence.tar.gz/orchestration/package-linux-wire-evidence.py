import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

root=Path('/var/snap/docker/common/hyperion-qualification/run-20261020-wire-workers')
assert root.is_dir() and not root.is_symlink()
candidate='5da54fb77699ce0a92d52f59c7569cb8d3e81ba7'
entries=[root/'preparation.json', *sorted((root/'evidence').rglob('*'))]
files=[]
links=[]
for path in entries:
    if path.is_symlink():
        target=path.readlink()
        assert path.name == 'deserialization_errors.log' and len(target.parts)==1 and not target.is_absolute()
        resolved=path.parent/target
        assert resolved.is_file() and not resolved.is_symlink()
        links.append({'path':path.relative_to(root).as_posix(),'target':str(target),
                      'targetSha256':hashlib.sha256(resolved.read_bytes()).hexdigest(),
                      'archiveTreatment':'metadata-only; original ordinary target retained'})
        continue
    if path.is_dir():
        continue
    assert path.is_file() and path.stat().st_size <= 128*1024*1024
    relative=path.relative_to(root).as_posix()
    assert not PurePosixPath(relative).is_absolute() and '..' not in PurePosixPath(relative).parts
    content=path.read_bytes()
    files.append({'path':relative,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
assert len(files) <= 10000 and sum(row['bytes'] for row in files) <= 512*1024*1024
for case in ('node24-linux-1','node22-linux-1'):
    receipt=json.loads((root/'evidence'/case/'case.json').read_text())
    assert receipt['status']=='passed' and receipt['sourceCommit']==candidate and receipt['resourceInventoryRestored']
    report=json.loads((root/'evidence'/case/'run/report.json').read_text())
    assert report['status']=='passed' and report['sourceCommit']==candidate
    assert all(row['ok'] for row in report['cleanup']) and report['shutdown']['success']
    assert report['shutdown']['exited']==report['shutdown']['children']==11
    assert report['masterExit']=={'code':0,'signal':None}
manifest={'schemaVersion':1,'sourceCommit':candidate,'files':files,'links':links,'bytes':sum(row['bytes'] for row in files)}
manifest_path=root/'linux-evidence-manifest.json'
with manifest_path.open('x') as out:
    json.dump(manifest,out,indent=2)
    out.write('\n')
archive=root/'linux-worker-evidence.tar.gz'
with tarfile.open(archive,'x:gz') as out:
    for row in files:
        path=root/row['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'], 'evidence changed during packaging'
        out.add(path,arcname=row['path'],recursive=False)
    out.add(manifest_path,arcname=manifest_path.name,recursive=False)
print(json.dumps({'path':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'bytes':archive.stat().st_size,'manifestSha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
                  'files':len(files),'sourceBytes':manifest['bytes']}))
