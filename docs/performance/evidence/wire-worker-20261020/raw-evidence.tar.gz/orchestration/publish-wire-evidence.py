import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile

base=Path(__file__).resolve().parents[2]
work=base/'out/wire-full-worker'
candidate='5da54fb77699ce0a92d52f59c7569cb8d3e81ba7'
destination=work/'hyperion-history-api/docs/performance/evidence/wire-worker-20261020'
staging=work/'publication-staging-v2'
assert not staging.exists()
assert not destination.exists() or (destination.is_dir() and not any(destination.iterdir()))
destination.mkdir(parents=True,exist_ok=True)
staging.mkdir()
linux_archive=work/'linux-received/linux-worker-evidence.tar.gz'
linux_manifest=work/'linux-received/linux-evidence-manifest.json'
sha=lambda data:hashlib.sha256(data).hexdigest()
assert sha(linux_archive.read_bytes())=='a660f46452e63c5d8c7285d836a5364166fa62244b84a666dbdf1aaddf88c500'
assert sha(linux_manifest.read_bytes())=='12794d51eb412232ba0c25376d6d07d374559fd194e4ead8b6f546bb84c4c0d8'
lm=json.loads(linux_manifest.read_text())
expected={row['path']:row for row in lm['files']}
with tarfile.open(linux_archive) as archive:
    members=archive.getmembers()
    assert len(members)==len(expected)+1 and len(members)<=10000
    for member in members:
        path=PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        data=archive.extractfile(member).read()
        if member.name=='linux-evidence-manifest.json':
            assert data==linux_manifest.read_bytes()
        else:
            row=expected.pop(member.name)
            assert len(data)==row['bytes'] and sha(data)==row['sha256']
        target=staging/'linux'/member.name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
assert not expected


def copy_file(source,target):
    assert source.is_file() and not source.is_symlink() and not source.is_junction()
    assert source.stat().st_size<=128*1024*1024
    target.parent.mkdir(parents=True,exist_ok=True)
    assert not target.exists()
    data=source.read_bytes()
    target.write_bytes(data)
    assert sha(target.read_bytes())==sha(data)


def copy_tree(source,target):
    aliases=[]
    for path in sorted(source.rglob('*')):
        assert not path.is_junction()
        if path.is_symlink():
            link=path.readlink()
            assert path.name=='deserialization_errors.log' and len(link.parts)==1 and not link.is_absolute()
            aliases.append({'path':path.relative_to(source).as_posix(),'target':str(link),
                            'archiveTreatment':'metadata-only; original ordinary target retained'})
        elif path.is_file():
            copy_file(path,target/path.relative_to(source))
        else:
            assert path.is_dir()
    return aliases


aliases=copy_tree(work/'node24-pilot1-20261020-run',staging/'windows-excluded/pilot')
for name in ('node24-pilot1-20261020-state.json','node24-pilot1-20261020-state.json.core.json',
             'node24-pilot1-20261020-state.json.cleanup.json','node24-pilot1-20261020-state.json.core.json.cleanup.json',
             'node24-pilot1-20261020-driver.log','node24-pilot1-20261020-prepare.log',
             'shutdown-diagnosis-received.md','shutdown-probe-receipts-received.json',
             'source-proofs-fix-received.md','standards-artifacts-recheck-received.md','spec-recheck-5da54fb-final.md',
             'ci-candidate.json','typecheck-app-final.log','typecheck-qualification-final.log','unit-final.log',
             'build-final.log','outputs-fix-root.log','native-source-artifacts-node22.log','native-source-artifacts-node24.log'):
    copy_file(work/name,staging/'local-records'/name)
copy_tree(base/'out/sequence-coverage/wire-shutdown-probe-20261020',staging/'windows-excluded/isolated-probes')
for name in ('prepare-linux-worker-run.py','sync-linux-worker-candidate.py','run-linux-wire-case.py','package-linux-wire-evidence.py','publish-wire-evidence.py'):
    copy_file(work/name,staging/'orchestration'/name)

results=[]
for case in ('node22-linux-1','node24-linux-1'):
    case_path=staging/'linux/evidence'/case
    report=json.loads((case_path/'run/report.json').read_text())
    receipt=json.loads((case_path/'case.json').read_text())
    assert report['status']==receipt['status']=='passed' and report['sourceCommit']==candidate
    assert report['readerConfirmations']['blocks']==119
    assert report['replayMetrics']['totalSentBlocks']==report['replayMetrics']['totalAcknowledgedBlocks']==119
    assert report['shutdown']['success'] and report['shutdown']['exited']==report['shutdown']['children']==11
    assert report['masterExit']=={'code':0,'signal':None}
    assert not report['shutdown']['forced'] and not report['shutdown']['unresolved']
    assert all(row['ok'] for row in report['cleanup']) and receipt['resourceInventoryRestored']
    assert len(report['durableCopies'])==2
    for copy in report['durableCopies']:
        for field in ('sourceProofsSha256','expectationsSha256','actions','blocks','historyDeltas','abiReferences','coordinatorCommits'):
            assert copy['evidence'][field]==report['outputs'][field]
    results.append({'case':case,'status':'passed','report':'linux/evidence/'+case+'/run/report.json',
                    'reportSha256':sha((case_path/'run/report.json').read_bytes()),'sourceCommit':candidate,
                    'runtime':report['runtime'],'serverVersion':report['server']['version']['number'],
                    'outputs':{key:value for key,value in report['outputs'].items() if key not in ('sourceProofs','gaps')},
                    'readerConfirmations':report['readerConfirmations'],'bulkAccounting':report['bulkAccounting'],
                    'publicationEvidence':report['publicationEvidence'],'shutdown':report['shutdown'],
                    'masterExit':report['masterExit'],'physicalCopies':[{'nodeId':copy['nodeId'],
                      'documentsSha256':copy['evidence']['documentsSha256'],
                      'sourceProofsSha256':copy['evidence']['sourceProofsSha256']} for copy in report['durableCopies']],
                    'physicalReadComparison':{'independentExpectedFieldAssertionsPassed':True,
                       'sourceProofHashesEqual':True,
                       'wholeDocumentDigestEqualityClaim':False,
                       'reason':'documentsSha256 hashes unsorted search result structures; no normalized cross-copy comparison was performed.'},
                    'cleanup':{'remainingContainers':0,'remainingVolumes':0,'remainingNetworks':0,
                               'resourceInventoryRestored':True},
                    'lastIndexedBeforeShutdown':report['lastIndexedBeforeShutdown']})
pilot=json.loads((staging/'windows-excluded/pilot/report.json').read_text())
assert pilot['status']=='failed' and pilot['masterExit']['code']==1
ci=json.loads((staging/'local-records/ci-candidate.json').read_text())
assert ci['headSha']==candidate and ci['status']=='completed' and ci['conclusion']=='success'
summary={'schemaVersion':1,'sourceCommit':candidate,'pullRequest':'https://github.com/eosrio/hyperion-history-api/pull/236',
         'scope':'bounded original Wire 7d application corpus through native Linux workers; correctness only',
         'host':{'name':'x570-hyperion-1','os':'Ubuntu 24.04.4','kernel':'6.8.0-136-generic','arch':'x86_64',
                 'hardware':'AMD Ryzen 9 5950X; 128 GiB RAM; bare metal'},
         'runs':results,'ci':ci,'unitTests':{'passed':957,'skipped':1,'failed':0,'expectations':6574},
         'excludedWindowsPilot':{'status':'failed','acceptance':False,'report':'windows-excluded/pilot/report.json',
                  'reportSha256':sha((staging/'windows-excluded/pilot/report.json').read_bytes()),
                  'reason':'Initial replica oracle mismatch and parent-observed forced child exits; no causal teardown fix established.',
                  'followUp':'https://github.com/eosrio/hyperion-history-api/issues/237'},
         'isolatedWindowsProbes':{'successfulRuns':21,'fullWorkerAcceptance':False},
         'limits':['Engineering corpus and package pins; selected testnet launch pins remain pending.',
                   'Unknown initial ancestry/ABI state; no current/head ABI fallback or seeded frontier.',
                   'Primary deletion is a history tombstone; contract_state is disabled and actual state deletion remains unqualified.',
                   'No observed secondary update/deletion, fork/reconnect, full-width source sequence, Rust/offline or Bun runtime qualification.',
                   'Legacy decimal sequence fields only; no gated full-range storage, public admission/sink/PIT activation or retained-history upgrade claim.',
                   'Three startup bulk items report one acknowledged copy in each run; later physical-copy equality does not establish universal two-copy acknowledgments.',
                   'Each physical read independently passes the same logical/source assertions. Whole-document digests include unsorted result structures and differ for one Node22 copy; no normalized byte-equality claim is made.',
                   'Qualifier-supervised clean process exits do not establish production graceful checkpoint/restart or power-loss recovery.',
                   'Observer, repeated source graph reads and bulk ledger add overhead; durations are not throughput measurements.']}
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
files=[]
for path in sorted(staging.rglob('*')):
    if path.is_file():
        data=path.read_bytes()
        files.append({'path':path.relative_to(staging).as_posix(),'bytes':len(data),'sha256':sha(data)})
assert len(files)<10000 and sum(row['bytes'] for row in files)<512*1024*1024
manifest={'schemaVersion':1,'sourceCommit':candidate,'files':files,'localLogAliases':aliases,
          'linuxLogAliases':'linux/linux-evidence-manifest.json contains the two metadata-only aliases'}
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
with tarfile.open(destination/'raw-evidence.tar.gz','x:gz') as archive:
    for row in files:
        path=staging/row['path']
        assert sha(path.read_bytes())==row['sha256']
        archive.add(path,arcname=row['path'],recursive=False)
print(json.dumps({'directory':str(destination),'files':len(files),'rawBytes':sum(row['bytes'] for row in files),
                  'archiveBytes':(destination/'raw-evidence.tar.gz').stat().st_size,
                  'archiveSha256':sha((destination/'raw-evidence.tar.gz').read_bytes())}))
