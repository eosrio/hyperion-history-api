param([Parameter(Mandatory)][string]$StateFile)
$ErrorActionPreference='Stop'
$state=Get-Content -LiteralPath $StateFile -Raw | ConvertFrom-Json
$url='http://'+(docker port $state.nodes[0].containerId 9200/tcp).Trim()
$info=Invoke-RestMethod $url -TimeoutSec 5
if ($info.cluster_uuid -ne $state.clusterUuid) { throw 'Cluster identity changed' }
$indices=ConvertFrom-Json -InputObject (Invoke-WebRequest "$url/_cat/indices/hyp-es955-*?format=json&expand_wildcards=all" -TimeoutSec 5).Content -NoEnumerate
if ($indices.Count -ne 0) { throw 'Qualification indices remain' }
$tasks=Invoke-RestMethod "$url/_tasks?actions=indices:data/write/bulk*,indices:data/read/search*&group_by=none" -TimeoutSec 5
if ($null -eq $tasks.tasks) { throw 'Complete ungrouped task list missing' }
$taskCount=@($tasks.tasks | Where-Object { $_ }).Count
if ($taskCount -or $tasks.node_failures -or $tasks.task_failures) { throw 'Tasks or incomplete task listing remain' }
$stats=Invoke-RestMethod "$url/_nodes/stats/indexing_pressure,thread_pool,breaker,indices,jvm" -TimeoutSec 5
if ($stats._nodes.total -ne 3 -or $stats._nodes.failed -ne 0 -or $stats._nodes.successful -ne 3) { throw 'Incomplete postflight node statistics' }
foreach ($property in $stats.nodes.psobject.Properties) {
    $n=$property.Value
    if ($n.indexing_pressure.memory.current.all_in_bytes -ne 0 -or $n.indices.search.open_contexts -ne 0 -or
        $n.indices.search.query_current -ne 0 -or $n.indices.search.fetch_current -ne 0 -or
        $n.thread_pool.write.active -ne 0 -or $n.thread_pool.write.queue -ne 0 -or
        $n.thread_pool.write_coordination.active -ne 0 -or $n.thread_pool.write_coordination.queue -ne 0) { throw 'Postflight work/accounting retained' }
}
$queueText=docker exec $state.broker.containerId rabbitmqctl -q list_queues --formatter json name messages messages_ready messages_unacknowledged
if ($LASTEXITCODE -ne 0) { throw 'Broker queue inspection failed' }
$queues=ConvertFrom-Json -InputObject ($queueText -join "`n") -NoEnumerate
if ($queues.Count -ne 0) { throw 'Owned broker queues remain' }
$connectionsText=docker exec $state.broker.containerId rabbitmqctl -q list_connections --formatter json user channels
if ($LASTEXITCODE -ne 0) { throw 'Broker connection inspection failed' }
$connections=ConvertFrom-Json -InputObject ($connectionsText -join "`n") -NoEnumerate
if ($connections.Count -ne 0) { throw 'Broker connections remain' }
$inspects=@()
foreach ($resource in @($state.nodes)+@($state.broker)) {
    $entry=@(docker inspect $resource.containerId | ConvertFrom-Json)[0]
    if ($entry.Config.Labels.'io.eosrio.run' -ne $state.run -or $entry.Config.Labels.'io.eosrio.qualifier' -ne 'es198-replicas') { throw 'Container ownership mismatch' }
    $inspects+=@($entry)
}
$report=[ordered]@{schemaVersion=1;status='passed';at=[DateTime]::UtcNow.ToString('o');cluster=$info;
    remainingIndices=$indices.Count;remainingTasks=$taskCount;remainingQueues=$queues.Count;
    remainingBrokerConnections=$connections.Count;tasks=$tasks;stats=$stats;brokerQueues=$queues;brokerConnections=$connections;
    containers=$inspects;network=@(docker network inspect $state.network | ConvertFrom-Json)[0]}
[IO.File]::WriteAllText('C:\Users\igorl\.codex\scratch\es198-replicas-postflight.json',($report|ConvertTo-Json -Depth 50)+"`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Postflight: zero probe indices, search/bulk tasks, broker queues/connections and active pressure/search/write work'
