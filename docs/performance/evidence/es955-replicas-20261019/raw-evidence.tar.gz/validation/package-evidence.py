"""Freeze the ES198 replica evidence only after the owner supplies cleanup receipts."""
import argparse
import datetime
import gzip
import hashlib
import io
import json
import pathlib
import re
import shutil
import subprocess
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


parser = argparse.ArgumentParser()
parser.add_argument('--root', required=True, type=pathlib.Path)
parser.add_argument('--scratch', required=True, type=pathlib.Path)
parser.add_argument('--postflight', required=True, type=pathlib.Path)
parser.add_argument('--cleanup', required=True, type=pathlib.Path)
parser.add_argument('--extra', action='append', default=[], type=pathlib.Path)
parser.add_argument('--control', action='append', default=[], type=pathlib.Path)
parser.add_argument('--runtime-commit', required=True)
parser.add_argument('--state', required=True, type=pathlib.Path)
parser.add_argument('--creation', required=True, type=pathlib.Path)
parser.add_argument('--backup-bundle', required=True, type=pathlib.Path)
args = parser.parse_args()
root = args.root.resolve()
scratch = args.scratch.resolve()
destination = (root / 'docs/performance/evidence/es955-replicas-20261019').resolve()
assert destination.is_relative_to(root / 'docs/performance/evidence')
backup_bundle = args.backup_bundle.resolve()
assert backup_bundle.is_relative_to(scratch), 'prior evidence backup must remain in this task scratch directory'
if (destination / 'raw-evidence.tar.gz').exists():
    for name in ['manifest.json', 'summary.json', 'raw-evidence.tar.gz', 'SHA256SUMS', '.gitattributes']:
        assert (destination / name).read_bytes() == (backup_bundle / name).read_bytes(), 'prior public bundle changed after verified backup'
members = {}
roles = {}


def add(name, data, role):
    path = pathlib.PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and name not in members
    members[name] = data
    roles[name] = role


def add_file(name, path, role):
    data = path.read_bytes()
    assert data, f'empty evidence input: {path}'
    add(name, data, role)
    return data


def physical_copies(rows, documents, index):
    assert len(rows) == 2, 'both physical data-node copies must be observed'
    expected = {document['id']: document['source'] for document in documents}
    assert len(expected) == len(documents)
    nodes = []
    for row in rows:
        assert row['index'] == index and row['count'] == len(expected) and row['exactSources'] is True
        assert row['preference'].startswith('_only_nodes:')
        node = row['preference'].removeprefix('_only_nodes:')
        assert node and ',' not in node
        response = row['response']
        assert response['timed_out'] is False
        assert response['_shards']['total'] == response['_shards']['successful'] == 1 and response['_shards']['failed'] == 0
        assert response['hits']['total'] == {'value': len(expected), 'relation': 'eq'}
        hits = response['hits']['hits']
        assert len(hits) == len(expected)
        assert {hit['_id']: hit['_source'] for hit in hits} == expected
        assert all(hit['_index'] == index for hit in hits)
        nodes.append(node)
    assert len(set(nodes)) == 2, 'physical copy observations must target different nodes'
    return sorted(nodes)


active_state_bytes = add_file('fixture/active-state.json', args.state, 'final physical-copy fixture manifest')
active_state = json.loads(active_state_bytes)
assert active_state['status'] == 'ready' and len(active_state['nodes']) == 3
add_file('fixture/active-creation.ps1', args.creation, 'hardened helper used to create the final physical-copy fixture')
for name in ['manifest.json', 'summary.json', 'raw-evidence.tar.gz', 'SHA256SUMS']:
    add_file(f'reports/development/prior-bundle/{name}', backup_bundle / name, 'superseded pre-physical-copy bundle; excluded from final aggregate')


finals = []
for mode in ['node-http', 'node-default', 'bun-default']:
    data = add_file(f'reports/final/{mode}.json', scratch / f'es198-replicas-{mode}-final.json', 'final measured run')
    report = json.loads(data)
    assert report['status'] == 'passed'
    assert report['fixtureManifestSha256'] == sha(active_state_bytes)
    assert report['state']['run'] == active_state['run'] and report['state']['clusterUuid'] == active_state['clusterUuid']
    assert len(report['cleanup']) == 4 and all(row['ok'] for row in report['cleanup'])
    assert report['pressureVerification']['count'] == 640
    assert report['brokerVerification']['count'] == 642
    assert report['replicaSurvival']['count'] == 120
    assert report['translogRecovery']['verification']['count'] == 120
    assert len(report['afterRecovery']['copyVerifications']) == 2
    assert all(row['count'] == 121 and row['exactSources'] for row in report['afterRecovery']['copyVerifications'])
    assert len(report['broker']['queueCleanup']) == 3 and all(row['deleted'] for row in report['broker']['queueCleanup'])
    assert report['blockedAllCopies']['absent'] is True
    physical_node_sets = []
    for dataset, expected_count in [('pressure', 640), ('broker', 642)]:
        documents = report[dataset]['expectedDocs']
        assert len(documents) == expected_count
        index = report[dataset + 'Verification']['index']
        for phase in ['BeforeCrash', 'AfterRecovery']:
            physical_node_sets.append(physical_copies(report[dataset + 'Copies' + phase], documents, index))
    assert all(nodes == physical_node_sets[0] for nodes in physical_node_sets), 'physical data-node identity changed across datasets or recovery'
    finals.append((mode, report))
    add_file(f'logs/final/{mode}.log', scratch / f'es198-replicas-{mode}-final.log', 'final runner console output')
    preaudit = scratch / f'es198-replicas-{mode}-preaudit.json'
    old = json.loads(add_file(f'reports/development/{mode}-preaudit.json', preaudit, 'passed before cleanup-oracle audit; excluded from final totals'))
    assert old['status'] == 'passed'

for number in [1, 2]:
    name = f'es198-replicas-node-http-draft{number}.json'
    add_file(f'reports/development/node-http-draft{number}.json', scratch / name,
             'failed single-sample queue oracle' if number == 1 else 'passed pilot before ephemeral-port correction; excluded from final totals')
for control in args.control:
    add_file(f'reports/development/{control.name}', control, 'additional development/control run; excluded from final totals')

for source in ['es198-replicas-state.json', 'es198-replicas-state2.json']:
    add_file(f'fixture/{source}', scratch / source, 'original fixture intent/manifest')
add_file('fixture/original-creation.ps1', scratch / 'es198-replicas-fixture-creation.ps1', 'original creation helper snapshot from qualification commit 1a122d8')
postflight_bytes = add_file('fixture/postflight.json', args.postflight, 'owner postflight observation before fixture removal')
postflight = json.loads(postflight_bytes)
assert postflight['status'] == 'passed'
for field in ['remainingIndices', 'remainingTasks', 'remainingQueues', 'remainingBrokerConnections']:
    assert postflight[field] == 0, f'postflight residue: {field}'
cleanup_bytes = add_file('fixture/cleanup.json', args.cleanup, 'owner exact-resource cleanup receipt')
cleanup = json.loads(cleanup_bytes)
assert cleanup['run'] == active_state['run']
assert postflight['cluster']['cluster_uuid'] == active_state['clusterUuid']
for field in ['remainingContainers', 'remainingVolumes', 'remainingNetworks']:
    assert cleanup[field] == 0, f'owned fixture cleanup incomplete: {field}'
assert cleanup['completedAt']
unit_log = add_file('validation/unit-final.log', scratch / 'es198-replicas-unit-final.log', 'whole branch unit test output').decode(errors='replace')
unit_pass = re.findall(r'\b(\d+) pass\b', unit_log)
unit_fail = re.findall(r'\b(\d+) fail\b', unit_log)
unit_assertions = re.findall(r'\b(\d+) expect\(\) calls', unit_log)
assert unit_pass and unit_fail and unit_assertions and int(unit_fail[-1]) == 0
for extra in args.extra:
    add_file(f'validation/{extra.name}', extra, 'additional owner-supplied review/validation evidence')
add_file('validation/package-evidence.py', pathlib.Path(__file__), 'archive construction and full member read-back verifier')

source_hashes = finals[0][1]['sourceHashes']
assert all(report['sourceHashes'] == source_hashes for _, report in finals), 'final runs used different measured source bytes'
for name, expected_hash in source_hashes.items():
    data = add_file(f'sources/measured/{name}', root / name, 'exact source/build bytes independently hashed by all final runs')
    assert sha(data) == expected_hash, f'measured source changed after final run: {name}'

supporting = ['scripts/qualification/es955.ts', 'scripts/qualification/es955-replica-fixture.ps1',
              'scripts/qualification/check-replica-cleanup.ps1',
              'scripts/qualification/tsconfig.json', 'src/indexer/helpers/es-connection.ts',
              'src/indexer/workers/indexer.ts',
              'src/indexer/helpers/common_functions.ts', 'build/indexer/helpers/common_functions.js',
              'build/api/helpers/functions.js', 'tests/unit/elastic-bulk-ack.test.ts',
              'tests/unit/elastic-settlement-recovery.test.ts',
              'tests/unit/es955-pressure.test.ts', 'tests/unit/es955-replicas.test.ts',
              'package.json', 'tsconfig.json']
for name in supporting:
    if name in source_hashes:
        continue
    add_file(f'sources/supporting/{name}', root / name, 'supporting source/test/config snapshot at archive freeze')
add_file('sources/supporting/node_modules/@elastic/elasticsearch/lib/client.js', root / 'node_modules/@elastic/elasticsearch/lib/client.js',
         'installed client connection-default implementation')
add_file('sources/supporting/node_modules/@elastic/transport/package.json', root / 'node_modules/@elastic/transport/package.json',
         'installed transport package metadata')
add_file('sources/supporting/node_modules/amqplib/package.json', root / 'node_modules/amqplib/package.json',
         'installed AMQP client package metadata')

commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip()
dirty = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root).decode()
add('validation/git-state.txt', ('HEAD ' + commit + '\n' + dirty).encode(), 'archive-freeze provenance; not a byte-equivalence claim')


def rejection_delta(before, after):
    assert set(before['nodes']) == set(after['nodes'])
    result = {}
    for stage in ['coordinating', 'primary', 'replica']:
        field = stage + '_rejections'
        result[stage] = sum(after['nodes'][node]['indexing_pressure']['memory']['total'][field] -
                            before['nodes'][node]['indexing_pressure']['memory']['total'][field] for node in before['nodes'])
        assert result[stage] >= 0
    return result


rows = []
for mode, report in finals:
    pressure = report['pressure']
    broker = report['broker']
    recovery = next(iter(report['translogRecovery']['recovery'].values()))['shards'][0]
    pre_retry = broker['settlementObservations'][2]['preRetryPresence']
    row = {
        'mode': mode, 'status': report['status'], 'runtime': report['runtime'],
        'startedAt': report['startedAt'], 'completedAt': report['completedAt'],
        'finalReport': f'reports/final/{mode}.json',
        'pressureDocuments': report['pressureVerification']['count'],
        'brokerDocuments': report['brokerVerification']['count'],
        'replicatedSeeds': report['replicaSurvival']['count'],
        'degradedSingleCopyWrites': 1,
        'soloReplayedDocuments': report['translogRecovery']['verification']['count'],
        'persistedDocuments': 640 + 642 + 120 + 1 + 120,
        'pressure': {'bulkRequests': len(pressure['receipts']), 'submittedNdjsonBytes': pressure['totalRequestBytes'],
                     'initialStatus': pressure['receipts'][0]['statusCode'], 'nativeStages': pressure['observedStages'],
                     'counterDelta': rejection_delta(pressure['before'], pressure['afterPressure']),
                     'recoverySampleCount': len(pressure['recoverySamples']),
                     'recoveryGateMs': pressure['recoverySamples'][-1]['elapsedMs']},
        'broker': {'bulkRequests': len(broker['receipts']), 'submittedNdjsonBytes': broker['totalRequestBytes'],
                   'publisherConfirmedMessages': sum(item['totalConfirmed'] for item in broker['publisherConfirms']),
                   'queuesDeleted': sum(item['deleted'] for item in broker['queueCleanup']),
                   'failedMessagesDiscardedOnlyDuringFixtureCleanup': sum(item['deletedMessageCount'] for item in broker['queueCleanup']),
                   'preRetryPressureDocumentsObservedPresent': sum(item['found'] for item in pre_retry),
                   'channelErrors': broker['channelErrors']},
        'translog': {'before': {key: value for key, value in report['translogBefore'].items() if key != 'raw'},
                    'recoveryType': recovery['type'], 'stage': recovery['stage'],
                    'recoveredOperations': recovery['translog']['recovered']},
        'indicesRemoved': len(report['cleanup'])
    }
    row['physicalCopies'] = {
        dataset: {phase: [{'preference': check['preference'], 'count': check['count'], 'exactSources': check['exactSources']}
                          for check in report[dataset + 'Copies' + phase]] for phase in ['BeforeCrash', 'AfterRecovery']}
        for dataset in ['pressure', 'broker']
    }
    assert row['broker']['publisherConfirmedMessages'] == 646
    assert row['broker']['failedMessagesDiscardedOnlyDuringFixtureCleanup'] == 1
    assert row['translog']['recoveredOperations'] == 120 and row['translog']['recoveryType'] == 'EXISTING_STORE'
    rows.append(row)

summary = {'schemaVersion': 1, 'measuredDate': '2026-10-19', 'issue': 'https://github.com/eosrio/hyperion-history-api/issues/198',
           'server': finals[0][1]['server']['version'], 'clientVersion': finals[0][1]['clientVersion'],
           'transportVersion': finals[0][1]['transportVersion'], 'runs': rows,
           'unitValidation': {'passed': int(unit_pass[-1]), 'failed': int(unit_fail[-1]), 'assertions': int(unit_assertions[-1])},
           'totals': {'finalRuns': len(rows), 'persistedDocuments': sum(row['persistedDocuments'] for row in rows),
                      'pressureDocuments': sum(row['pressureDocuments'] for row in rows),
                      'brokerDocuments': sum(row['brokerDocuments'] for row in rows),
                      'translogReplayedOperations': sum(row['translog']['recoveredOperations'] for row in rows)},
           'excludedDevelopmentRuns': ['node-http-draft1 failed', 'node-http-draft2 pilot passed',
                                       'node-http preaudit passed', 'node-default preaudit passed', 'bun-default preaudit passed']
                                      + [path.name for path in args.control],
           'sourceHashes': source_hashes,
           'sourceProvenance': 'Final raw reports independently hash exact archived measured bytes. Git checkout HEAD is context only; normalized Git blobs may have different line endings. Precommit draft1/draft2 main-runner byte snapshots were not saved; their original reports retain hashes but exact runner bytes are unavailable. No reconstruction is represented as measured source.',
           'cleanup': cleanup,
           'limits': ['Static one-MiB pressure budget is an admission/recovery fixture, not production capacity or throughput.',
                      'Process SIGKILL is not host power loss, OS crash, hardware failure or broker-restart durability.',
                      'Built ElasticRoutes and actual AMQP settlement do not qualify full worker/master/reader backpressure.',
                      'Synthetic mappings do not qualify retained-history upgrade, full APIs or plugin schemas.',
                      'Coordinating admission rejection does not directly qualify translated-update expansion rejection inside the primary item loop (Elastic158235).',
                      'Bun process.version is a compatibility value; this does not qualify the entire runtime.']}
add('README.json', encoded({'schemaVersion': 1, 'description': 'Raw ES198 replica, native pressure and broker settlement evidence.',
                          'finalReports': [row['finalReport'] for row in rows],
                          'developmentReportsExcludedFromFinalTotals': True,
                          'sourceProvenance': summary['sourceProvenance']}), 'archive interpretation')
records = [{'path': name, 'sha256': sha(data), 'sizeBytes': len(data), 'role': roles[name]}
           for name, data in sorted(members.items())]
manifest = {'schemaVersion': 1, 'createdAt': datetime.datetime.now(datetime.UTC).isoformat(),
            'archive': 'raw-evidence.tar.gz', 'qualificationPreparationCommit': '1a122d84a8b3bc1f05f5450ab940bbd117d9d228',
            'initialRuntimeCorrectionCommit': '3bd95443e56fe2056938561b534e7e52bbc0baa4',
            'finalRuntimeCorrectionCommit': args.runtime_commit, 'archiveFreezeHead': commit,
            'sourceProvenance': summary['sourceProvenance'], 'finalSourceHashes': source_hashes,
            'fixtureManifestSha256': finals[0][1]['fixtureManifestSha256'],
            'members': records}
destination.mkdir(parents=True, exist_ok=True)
archive_path = scratch / 'es198-replicas-physical-copy-candidate.tar.gz'
with archive_path.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
            for record in records:
                data = members[record['path']]
                info = tarfile.TarInfo(record['path'])
                info.size = len(data); info.mtime = 0; info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))

# Extraction/read-back in memory avoids filesystem traversal while checking every member's actual bytes.
with tarfile.open(archive_path, 'r:gz') as archive:
    assert len(archive.getmembers()) == len(records)
    for record in records:
        member = archive.getmember(record['path'])
        assert member.isfile() and member.size == record['sizeBytes']
        data = archive.extractfile(member).read()
        assert sha(data) == record['sha256'] and data == members[record['path']]
manifest['archiveReadbackVerifiedMembers'] = len(records)
manifest['archiveSha256'] = sha(archive_path.read_bytes())
manifest['archiveSizeBytes'] = archive_path.stat().st_size
shutil.copyfile(archive_path, destination / 'raw-evidence.tar.gz')
(destination / 'summary.json').write_bytes(encoded(summary))
(destination / 'manifest.json').write_bytes(encoded(manifest))
(destination / 'SHA256SUMS').write_text(''.join(f'{sha((destination / name).read_bytes())}  {name}\n'
                                            for name in ['manifest.json', 'summary.json', 'raw-evidence.tar.gz']), encoding='utf-8', newline='\n')
(destination / '.gitattributes').write_text('*.json text eol=lf\nSHA256SUMS text eol=lf\n*.tar.gz binary\n', encoding='utf-8', newline='\n')
print(json.dumps({'archiveMembers': len(records), 'archiveBytes': archive_path.stat().st_size,
                  'archiveSha256': manifest['archiveSha256'], 'totals': summary['totals'],
                  'files': {name: sha((destination / name).read_bytes()) for name in ['manifest.json', 'summary.json', 'raw-evidence.tar.gz']}}))
