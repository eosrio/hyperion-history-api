from pathlib import Path
import tarfile,json,hashlib,re,datetime
base=Path(r'C:\Users\igorl\.codex\worktrees\hyperion45-es955\hyperion-history-api\docs\performance\evidence\es955-workers-20261019')
out=Path(r'C:\Users\igorl\.codex\scratch\es198-pr207-original-evidence-audit.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((base/'manifest.json').read_bytes());summary=json.loads((base/'summary.json').read_bytes())
archive=base/'raw-evidence.tar.gz';assert sha(archive.read_bytes())==manifest['archiveSha256']=='c848bcb53563b6cd3292e293f212e8d4a4ca357bb57f4bd6ba914cca63c659fe'
result={'schemaVersion':1,'auditedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archiveSha256':sha(archive.read_bytes()),'summarySha256':sha((base/'summary.json').read_bytes()),'manifestSha256':sha((base/'manifest.json').read_bytes()),'runs':[],'notes':[]}
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==manifest['memberCount']==410
 actual={m.name:m for m in members};assert len(actual)==len(members)
 for item in manifest['members']:
  m=actual[item['path']];assert m.isfile();b=t.extractfile(m).read();assert len(b)==item['sizeBytes'] and sha(b)==item['sha256']
 result['verifiedArchiveMembers']=len(members)
 for mode in ['control','profile']:
  prefix='runs/final/'+mode+'/'
  report=json.loads(t.extractfile(prefix+'report.json').read())
  sr=next(r for r in summary['runs'] if r['mode']==mode)
  assert report['status']==sr['status']=='passed';assert report['seconds']==300
  assert report['confirmedDocuments']==sr['publisherConfirmedActions'];assert report['finalCopies']==sr['exactPhysicalCopies']
  paths=[m.name for m in members if m.name.startswith(prefix+'observer/') and m.name.endswith('.jsonl')]
  bypid={};allrows=[]
  for path in paths:
   rows=[json.loads(line) for line in t.extractfile(path).read().decode().splitlines() if line.strip()]
   starts=[r for r in rows if r['kind']=='start'];assert len(starts)==1
   pid=starts[0]['pid'];assert pid not in bypid;bypid[pid]=rows;allrows+=rows
  assert len(bypid)==13
  masterpid=report['masterPid'];masterrows=bypid[masterpid]
  exits=[r for r in masterrows if r['kind']=='worker_exit'];assert len(exits)==12
  assert {r['childPid'] for r in exits}==set(bypid)-{masterpid}
  assert all(r['code']==0 and r['signal'] is None for r in exits)
  run={'mode':mode,'reportSha256':sha(t.extractfile(prefix+'report.json').read()),'status':'passed','nominalSteadySeconds':report['seconds'],'durationSeconds':(datetime.datetime.fromisoformat(report['completedAt'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(report['startedAt'].replace('Z','+00:00'))).total_seconds(),'masterPid':masterpid,'parentObservedChildExitRecords':exits,'masterParentObservedOsExit':None,'masterParentObservedOsExitNote':'Original report has no parent-side master exitCode/signal field. Master own observer exit record plus successful shutdown and postflight disappearance are separate evidence.','pids':[]}
  recovery=report['recoveryObservations'][-1]['at']
  for pid,rows in sorted(bypid.items()):
   start=next(r for r in rows if r['kind']=='start');ownexits=[r for r in rows if r['kind']=='exit'];assert len(ownexits)==1 and ownexits[0]['code']==0
   shutdowns=[r for r in rows if r['kind']=='shutdown'];assert len(shutdowns)==1 and shutdowns[0]['success'] is True and shutdowns[0]['forced']==[] and shutdowns[0]['unresolved']==[]
   flushes=[r for r in rows if r['kind']=='flush'];assert len(flushes)==1 and flushes[0]['success'] is True and flushes[0]['reason']=='qualifier_flush' and flushes[0]['at']>=recovery and flushes[0]['droppedRecords']==0
   assert not any(r['kind']=='observer_error' for r in rows)
   info={'pid':pid,'role':start['role'],'workerId':start['workerId'],'ownExit':ownexits[0],'shutdown':shutdowns[0],'flush':flushes[0],'observerLifetimeMs':ownexits[0]['monotonicMs']-start['monotonicMs'],'parentObservedChildExit':next((r for r in exits if r['childPid']==pid),None)}
   ps=[r for r in rows if r['kind']=='profile_started']
   if mode=='profile':
    assert len(ps)==1 and ps[0]['maximumDurationMs']==900000 and flushes[0]['profileState']=='saved'
    cp=json.loads(t.extractfile(prefix+f'observer/worker-{pid}.cpuprofile').read())
    info.update(profileMaximumMs=ps[0]['maximumDurationMs'],profileStartRecord=ps[0],profileDurationMicros=cp['endTime']-cp['startTime'],profileElapsedThroughFlushMs=flushes[0]['monotonicMs']-ps[0]['monotonicMs'])
    assert 0<info['profileDurationMicros']/1000<900000
   else:
    assert not ps and flushes[0]['profileState']=='disabled'
   run['pids'].append(info)
  run['masterStderrBytes']=len(t.extractfile(prefix+'master.stderr.log').read());assert run['masterStderrBytes']==0
  validation='validation/es198-workers-node-'+mode+'-final.log';run['runnerValidationLog']=t.extractfile(validation).read().decode();assert '"status":"passed"' in run['runnerValidationLog'].replace(' ','')
  run['allOwnExitCodesZero']=True;run['allParentObservedChildExitCodesZeroAndSignalsNull']=True;run['allShutdownsUnforcedSuccessful']=True;run['allFlushesExplicitPostRecovery']=True
  run['maximumObserverLifetimeMs']=max(p['observerLifetimeMs'] for p in run['pids'])
  if mode=='profile':run['maximumProfileDurationMs']=max(p['profileDurationMicros']/1000 for p in run['pids'])
  result['runs'].append(run)
result['notes']=[
'All410original archive members were independently byte/hash verified. Archive and summary remained unchanged.',
'Both final runs contain13own code0exit records and12master-observed child exits code0/signalnull. No published final exercised the nonzero-child falsepass.',
'Original profile run has13caps900000ms, explicit qualifier_flush receipts after recovery,13savedprofiles, and actual duration far below cap. Nominal steady input300s; incompatible900s profile path was not exercised.',
'Readiness-race finding affects observer regression synchronization, not the actual recorded full-worker run outcomes.',
'Unhandled AMQP error listeners were absent in original runner. A passed completed report, passed final validation log and empty masterstderr show no observed fatal path in these finals; this does not establish failure-path coverage.',
'Four confirmed harness defects require corrections and regression coverage, but inspected original outcomes do not demonstrate invalid measurements. Keep originals as historical evidence and distinguish hardening from a rerun.',
'Proposed profile<=600steadysec guard before state read/Docker/output is appropriate to remove deterministic900s incompatibility;300s is headroom, not a guaranteed lifecycle budget because cumulative existing per-stage deadlines can exceed it. Final explicit post-recovery flush/overallcap rejection must remain.'
]
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','archiveMembersVerified':410,'auditPath':str(out),'auditSha256':sha(out.read_bytes()),'runs':[{k:r[k] for k in ['mode','durationSeconds','maximumObserverLifetimeMs','allOwnExitCodesZero','allParentObservedChildExitCodesZeroAndSignalsNull','allShutdownsUnforcedSuccessful','allFlushesExplicitPostRecovery']}|({'maximumProfileDurationMs':r['maximumProfileDurationMs']} if r['mode']=='profile' else {}) for r in result['runs']]},indent=2))
