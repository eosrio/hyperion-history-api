import runpy,json,pathlib,hashlib,subprocess,uuid,os
from datetime import datetime,timezone
repo=pathlib.Path(r'C:\Users\igorl\.codex\worktrees\hyperion45-es955\hyperion-history-api');scratch=pathlib.Path(r'C:\Users\igorl\.codex\scratch')
m=runpy.run_path(str(scratch/'es198-workers-package.py'));h=m['sha'];read=m['read_json'];enc=m['encoded']
run=scratch/'es198-pr207-profile-final';report=read(run/'report.json');assert report['status']=='passed'
assert report['masterExit']=={'code':0,'signal':None}
rows=m['observer_rows'](run);starts=[r for r in rows if r['kind']=='start'];forks=[r for r in rows if r['kind']=='worker_fork'];exits=[r for r in rows if r['kind']=='worker_exit']
assert len(starts)==13 and len(forks)==len(exits)==12
assert all(r['code']==0 and r.get('signal') is None for r in exits)
assert all(any(e['kind']=='exit' and e['pid']==r['pid'] and e['code']==0 for e in rows) for r in starts)
shutdown=next(r for r in rows if r['kind']=='shutdown' and r['pid']==report['masterPid'])
assert shutdown['success'] and shutdown['failedChildren']==shutdown['forced']==shutdown['unresolved']==[]
assert len(shutdown['childExits'])==12 and all(e['code']==0 and e['signal'] is None for e in shutdown['childExits'])
state=read(scratch/'es198-pr207-review-state.json');post=read(scratch/'es198-pr207-review-postflight.json');cleanup=read(scratch/'es198-pr207-review-state.json.cleanup.json')
assert post['status']=='passed' and post['run']==state['run'] and post['consecutiveIdleSamples']>=3 and not post['survivingObservedProcesses']
assert cleanup['run']==state['run'] and len(cleanup['extraContainers'])==len(cleanup['extraVolumes'])==3
assert all(cleanup['coreCleanup'][k]==0 for k in ['remainingContainers','remainingVolumes','remainingNetworks'])
assert len(cleanup['coreCleanup']['containers'])==len(cleanup['coreCleanup']['volumes'])==4
archive=m['Archive'](repo,scratch);prefix='run/profile';archive.tree(prefix,run,'Fresh 60-second steady-phase profile follow-up; separate from original five-minute totals',status='passed',run=state['run']);m['verify_sources'](archive,report,prefix,run)
for p in sorted(scratch.glob('es198-pr207*')):
 if p.is_file() and p.suffix in {'.json','.log','.py','.mjs','.patch'} and 'candidate' not in p.name and p.name!='es198-pr207-package-final.log':
  archive.add('validation/'+p.name,path=p,role='Review reproduction, original-evidence audit, fixture/postflight/cleanup or validation')
for p in sorted(scratch.glob('es198-pr207-review-state.json*')):
 if p.is_file() and p.name not in {x.split('/')[-1] for x in archive.members}:
  archive.add('validation/'+p.name,path=p,role='Exact owned fixture/core cleanup evidence')
for name in ['scripts/qualification/check-worker-observer.mjs','tests/unit/es955-workers.test.ts','AGENTS.md']:
 archive.add('supporting/'+name,path=repo/name,role='Supporting source at correction commit')
assert report['profile'] is True and report['seconds']==60 and report['rate']==200
assert report['runtime']['node']=='v24.19.0' and report['runtime'].get('bun') is None
assert all(x['ok'] is True for x in report['cleanup'])
copies=report['finalCopies'];digest=m['expected_action_digest'](report)
assert len(copies)==2 and copies[0]['node']!=copies[1]['node']
assert all(x['exactSources'] and x['count']==report['confirmedDocuments'] and x['sha256']==digest for x in copies)
assert len(report['faults'])==3
for fault in report['faults']:
 pause,pending,resumed,request=(fault[k] for k in ['paused','pendingRange','resumed','resumedRequest'])
 assert pause['role']==pending['role']==resumed['role']==request['role']=='reader'
 assert pause['at']<pending['at']<fault['releasedAt']<=resumed['at']<=request['at']
 assert fault['liveProgress']>0 and fault['heldRequests']>0
 assert not any(r.get('kind')=='ship_range_request' and r.get('role')=='reader' and pending['at']<=r['at']<fault['releasedAt'] for r in rows)
 planned=pending.get('message',{}).get('range') or pending.get('range')
 assert planned and all(request[k]==planned[k] for k in ['first_block','last_block'])
summary={'schemaVersion':1,'scope':'Bounded review-correction follow-up; not a five-minute sustained qualification',
 'mode':'profile','status':report['status'],'startedAt':report['startedAt'],'completedAt':report['completedAt'],
 'sourceCommit':'d2353930a5037404bbb3e5da9f665546cccb0954','runtime':report['runtime'],'fixtureRun':state['run'],
 'nominalPhaseSecondsTotal':report['seconds'],'targetPublisherActionsPerSecond':report['rate'],
 'publisherConfirmedActions':report['confirmedDocuments'],'exactPhysicalCopies':copies,
 'phases':report['windows'],'queries':len(report['queries']),'bulkResponses':len(report['bulks']),
 'backpressureWaves':report['faults'],'workers':m['summarize_workers'](run,rows,True,report['recoveryObservations'][-1]['at']),
 'serverNodes':m['server_summary'](report),'cleanup':report['cleanup']}
summary['masterOsExit']=report['masterExit'];summary['postflight']={'status':post['status'],'observedPids':post['observedProcessCount'],'idleSamples':post['consecutiveIdleSamples'],'brokerMessages':0,'brokerConnections':0}
summary['fixtureCleanup']={'containers':7,'volumes':7,'networks':1,'remainingContainers':0,'remainingVolumes':0,'remainingNetworks':0}
summary['originalEvidenceAudit']=read(scratch/'es198-pr207-original-evidence-audit.json')
summary['interpretation']='This shorter correction follow-up is excluded from the original two five-minute totals. No abnormal shutdown or early profile cap was found in those original logs. Their parent-observed master OS exit field was absent; the new run captures it. AMQP error probes use installed models and exact acquisition statements without a broker handshake.'
archive.add('README.json',data=enc({'review':'https://github.com/eosrio/hyperion-history-api/pull/207#pullrequestreview-5570640946','baseline':'32bc4f8407e4dac2c9b40750ff9e9eca21b01a8e','correction':'d2353930a5037404bbb3e5da9f665546cccb0954','interpretation':summary['interpretation'],'originalArchiveSha256':'c848bcb53563b6cd3292e293f212e8d4a4ca357bb57f4bd6ba914cca63c659fe'}),role='Evidence scope and original immutable archive identity')
candidate=scratch/('es198-pr207-candidate-'+uuid.uuid4().hex+'.tar.gz');archive.write_and_verify(candidate)
dest=repo/'docs/performance/evidence/es955-worker-review-20261019';dest.mkdir()
manifest={'schemaVersion':1,'createdAt':datetime.now(timezone.utc).isoformat(),'archive':'raw-evidence.tar.gz','archiveSha256':m['file_sha'](candidate),'sourceCommit':'d2353930a5037404bbb3e5da9f665546cccb0954','sourceHashes':report['sourceHashes'],'memberCount':len(archive.members),'members':[archive.members[k][0] for k in sorted(archive.members)],'sourceProvenance':'Run snapshots are byte-exact and hash-checked; original measurements remain untouched. Supporting files are distinguished from measured snapshots.'}
for name,data in {'manifest.json':enc(manifest),'summary.json':enc(summary),'.gitattributes':b'raw-evidence.tar.gz binary\nmanifest.json -text\nsummary.json -text\nSHA256SUMS -text\n.gitattributes -text\n'}.items():
 with (dest/name).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
(dest/'raw-evidence.tar.gz').write_bytes(candidate.read_bytes())
(dest/'SHA256SUMS').write_text(''.join(m['file_sha'](dest/n)+'  '+n+'\n' for n in ['raw-evidence.tar.gz','manifest.json','summary.json','.gitattributes']),encoding='utf-8')
print(json.dumps({'status':'passed','members':len(archive.members),'documents':report['confirmedDocuments'],'profiles':summary['workers']['cpuProfileCount'],'masterExit':report['masterExit'],'archiveSha256':manifest['archiveSha256']}))
