import {readFileSync,writeFileSync,mkdtempSync,rmSync} from 'node:fs';
import {spawnSync,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {tmpdir} from 'node:os';
import assert from 'node:assert/strict';
const repo=process.argv[2];
const old=execFileSync('git',['show','32bc4f8:scripts/qualification/es955-workers.ts'],{cwd:repo,encoding:'utf8'});
const current=readFileSync(join(repo,'scripts/qualification/es955-workers.ts'),'utf8');
const directory=mkdtempSync(join(tmpdir(),'es198-amqp-review-'));
const results=[];
try{
 for(const [version,text] of [['baseline',old],['fixed',current]]){
  const begin=text.indexOf('        const connecting = connect(');
  const end=text.indexOf('        producerTask =',begin);
  assert(begin>=0&&end>begin);const snippet=text.slice(begin,end);
  for(const faultSource of ['connection','publisher']){
   const script=`import assert from 'node:assert/strict';import {EventEmitter} from 'node:events';import {createRequire} from 'node:module';
import {observeAmqpErrors} from ${JSON.stringify(pathToFileURL(join(repo,'scripts/qualification/es955-workers.ts')).href)};
const require=createRequire(${JSON.stringify(pathToFileURL(join(repo,'package.json')).href)});
const {ChannelModel,ConfirmChannel}=require(${JSON.stringify(join(repo,'node_modules/amqplib/lib/channel_model.js'))});
const transport=new EventEmitter();const model=new ChannelModel(transport);const realPublisher=new ConfirmChannel(transport);
model.createConfirmChannel=async()=>realPublisher;realPublisher.checkQueue=async()=>({consumerCount:1});
const connect=async()=>model;const bounded=promise=>promise;const state={core:{broker:{url:'amqp://fixture.invalid'}}};const actionQueue='fixture';
let broker,publisher,producerError;const stopping=false;const report={status:'running',cleanupWritten:false,amqpErrors:[]};
const captureAmqpError=(source,error)=>{report.amqpErrors.push({source,message:error.message});producerError??=error;};
try{${snippet}
 await new Promise(resolve=>setTimeout(()=>{${faultSource==='connection'?'transport':'realPublisher'}.emit('error',new Error('qualifier ${faultSource} fault'));resolve();},5));
 if(producerError)throw producerError;report.status='passed';
}catch(error){report.status='failed';report.error=error.message;}
finally{report.cleanupWritten=true;console.log(JSON.stringify(report));}`;
   const file=join(directory,`${version}-${faultSource}.ts`);writeFileSync(file,script);
   const child=spawnSync(process.execPath,[file],{encoding:'utf8',timeout:5000});
   let report;try{report=JSON.parse(child.stdout.trim());}catch{}
   results.push({version,faultSource,sourceSnippetSha256:createHash('sha256').update(snippet).digest('hex'),exitCode:child.status,signal:child.signal,report:report??null,stderr:child.stderr});
   if(version==='baseline'){assert.notEqual(child.status,0);assert.equal(report,undefined);assert.match(child.stderr,/qualifier .* fault/);}
   else{assert.equal(child.status,0,child.stderr);assert.equal(report.status,'failed');assert.equal(report.cleanupWritten,true);assert.equal(report.amqpErrors[0].source,faultSource);}
  }
 }
 console.log(JSON.stringify({status:'passed',runtime:process.version,pattern:'Exact runner acquisition statements with installed amqplib classes and asynchronous model/channel error events; no broker handshake or real worker cleanup claim',results},null,2));
}finally{rmSync(directory,{recursive:true,force:true});}
