param([Parameter(Mandatory)][string]$Plugin)
$ErrorActionPreference='Stop'
$path='C:\Users\igorl\.codex\scratch\es198-failure-state.json'
$s=Get-Content $path -Raw|ConvertFrom-Json
$ins=@(docker inspect $s.containerId|ConvertFrom-Json)[0]
if($LASTEXITCODE -ne 0 -or $ins.Config.Labels.'io.eosrio.run' -ne $s.run -or $ins.Config.Labels.'io.eosrio.qualifier' -ne 'es198-failures'){throw 'Ownership mismatch'}
$users=@(docker ps -a --no-trunc --filter "volume=$($s.volume)" --format '{{.ID}}')
if($users.Count -ne 1 -or $users[0] -ne $s.containerId){throw 'Unexpected volume consumer'}
$items=Invoke-WebRequest ($s.url+'/_cat/indices/hyp-es955-*?format=json&expand_wildcards=all')
if((ConvertFrom-Json -InputObject $items.Content -NoEnumerate).Count -ne 0){throw 'Index residue'}
docker stop --timeout 20 $s.containerId|Out-Null
if($LASTEXITCODE -ne 0){throw 'Stop failed'}
docker rm $s.containerId|Out-Null
if($LASTEXITCODE -ne 0){throw 'Remove failed'}
$s.dockerArgs=@($s.dockerArgs|ForEach-Object{if($_ -eq "type=bind,src=$($s.pluginDirectory),dst=/usr/share/elasticsearch/plugins/hyperion-qualifier,readonly"){"type=bind,src=$Plugin,dst=/usr/share/elasticsearch/plugins/hyperion-qualifier,readonly"}else{$_}})
$cid=docker @($s.dockerArgs)
if($LASTEXITCODE -ne 0){throw 'Recreate failed'}
$s.containerId=$cid.Trim()
$s.url='http://'+(docker port $cid 9200/tcp).Trim()
$s.pluginDirectory=$Plugin
$s.pluginJarSha256=(Get-FileHash "$Plugin\hyperion-qualifier.jar").Hash.ToLowerInvariant()
$s|ConvertTo-Json -Depth 10|Set-Content $path
for($i=0;$i -lt 90;$i++){
 try{$info=Invoke-RestMethod $s.url -TimeoutSec 2;if($info.cluster_uuid -ne $s.clusterUuid){throw 'Cluster changed'};Write-Output "Ready $Plugin $($s.url)";exit 0}
 catch{Start-Sleep -Milliseconds 500}
}
docker logs --tail 30 $cid
throw 'Not ready'
