# get_actions failure contract, 2026-10-19

Audit base: eosrio/hyperion-history-api b5c9080306c6739d81acb873dc66e32df77e1b82.
Scope: actual Fastify v1 POST and v2 GET get_actions registration, serializers and timedQuery cache path, with controlled ES/Redis/chain API dependencies. This is not full application or real-ES HTTP qualification.

## Reproduced before fix

`bun C:/Users/igorl/.codex/scratch/es198-api-contract-audit.ts` at unmodified source:

- timed_out:true with a hit: HTTP200; diagnostic metadata omitted; one cache write; repeat request makes no new ES call.
- _shards.failed:1 with a hit: same HTTP200/cache behavior.
- actual ES client TimeoutError: HTTP500, no cache.
- actual RequestAbortedError: HTTP500, no cache.
- actual ResponseError503: HTTP503, standard Fastify envelope, no cache.
- real HTTP disconnect while search pending: no signal passed; search continues and its returned result writes cache afterward.

Raw report preserved at `es198-api-contract-audit.json`. Formal route tests then reproduced incorrect statuses before fix: 2 passed/16 failed; two failures were fixture hook registration errors subsequently corrected. Relevant metadata/transport/disconnect failures were actual route defects, not inferred from fixture ES behavior.

## Fastify 5.8.5 cancellation trap

`es198-fastify-signal-control.mjs`, run on Node24.19.0 and Bun1.4.3, registers an ordinary Fastify route and waits30ms after accessing request.signal. GET remains active. A normal complete POST body emits IncomingMessage.close and aborts request.signal while the client remains connected and receives200.

Pinned source: node_modules/fastify/lib/request.js214-225 lazily binds request.signal to raw.close. Handler-timeout setup in route.js528-550 has the same raw.close coupling. The application does not configure handlerTimeout. Thus request.signal cannot safely be forwarded unfiltered for healthy v1 POST at this pin.

## Scoped fix

New `src/api/helpers/action-search.ts`:

- Pass a local AbortController signal to the ES search. Abort on raw.aborted or socket.close, not normal completed-body raw.close.
- Remove those listeners in finally on every success/error outcome.
- Reject timed_out and failed shards with HTTP503 before hit shaping/caching.
- Map transport TimeoutError504 and RequestAbortedError503; preserve ResponseError statuses and ordinary Fastify error envelopes.
- Check actual raw.aborted/socket.destroyed after ES await even if a mock/driver returns a late result despite cancellation.

Both routes use the helper and make the same active check immediately before returning the final shaped response. That catches disconnects during later chain-info/ABI/archive work before timedQuery's cache write. Shared timedQuery remains unchanged.

## Validation

- `bun test tests/unit/get-actions-search-failures.test.ts`:18 pass,74 assertions,~0.56s.
- Actual route registration and successful serializers both versions; incomplete hits not cacheable; healthy retry caches; existing ResponseError429 preserved.
- Real HTTP controls both versions: healthy delayed request (including completed POST body), upstream abort, cancellation-ignoring late result discarded, disconnect during later chain-info work not cached.
- `npm run typecheck`:190 files pass.
- `npm run build`: TypeScript7 emitted build passes.
- Node24.19 built-route audit: metadata503, transport timeout504/abort503, ResponseError503 preserved; disconnect signal observed, late result not cached. `es198-api-contract-audit-node-green.json`.
- Node24.19 real HTTP healthy delayed v1POST/v2GET: HTTP200, signal remains active, normal bodies preserved. `es198-api-node-healthy.json`.

## Limits

The helper cancels the main ES action search. It does not independently cancel later archive HTTP/chain RPC/ABI queries; the final active guard prevents their discarded results becoming cache entries. No new global HTTP deadline or transport retry policy is introduced. This only covers the existing HTTP1 API server. Server-side task and breaker/memory recovery require the separate real-ES fixture experiments.
