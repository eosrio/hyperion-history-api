import {createRequire} from 'node:module';
import {request} from 'node:http';
const require=createRequire('C:/Users/igorl/.codex/worktrees/hyperion45-es955/hyperion-history-api/package.json');
const Fastify=require('fastify');
const app=Fastify({logger:false});
const records=[];
app.route({method:['GET','POST'],url:'/control',handler:async(req)=>{
  const record={method:req.method,initialAborted:req.signal.aborted,initialComplete:req.raw.complete,initialDestroyed:req.raw.destroyed,events:[]};
  records.push(record);
  req.signal.addEventListener('abort',()=>record.events.push('signal.abort'));
  req.raw.on('close',()=>record.events.push('request.close'));
  req.raw.on('end',()=>record.events.push('request.end'));
  await new Promise(resolve=>setTimeout(resolve,30));
  record.finalAborted=req.signal.aborted;
  return record;
}});
const address=await app.listen({port:0,host:'127.0.0.1'});
for(const method of ['GET','POST']) {
 const body=method==='POST'?'{}':undefined;
 const result=await new Promise((resolve,reject)=>{
  const req=request(address+'/control',{method,headers:body?{'content-type':'application/json','content-length':body.length}:{}},res=>{let data='';res.on('data',chunk=>{data+=chunk});res.on('end',()=>resolve({status:res.statusCode,body:JSON.parse(data)}))});
  req.on('error',reject);req.end(body);
 });
 console.log(JSON.stringify({runtime:process.version,result}));
}
await app.close();
