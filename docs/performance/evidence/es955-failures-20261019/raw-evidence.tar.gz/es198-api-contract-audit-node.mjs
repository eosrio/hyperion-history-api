import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";
import { request as httpRequest } from "node:http";
import { writeFileSync } from "node:fs";
const root = "C:/Users/igorl/.codex/worktrees/hyperion45-es955/hyperion-history-api";
const require = createRequire(root + "/package.json");
const Fastify = require("fastify");
const { errors } = require("@elastic/elasticsearch");
const route1 = (await import(pathToFileURL(root + "/build/api/routes/v1-history/get_actions/index.js").href)).default;
const route2 = (await import(pathToFileURL(root + "/build/api/routes/v2-history/get_actions/index.js").href)).default;
const summary = [];
const source = {
  global_sequence: 1,
  block_num: 100,
  "@timestamp": "2026-10-19T01:00:00.000",
  trx_id: "a".repeat(64),
  act: { account: "eosio.token", name: "transfer", data: { from: "alice", to: "bob" }, authorization: [] },
  receipts: [{ receiver: "alice", recv_sequence: 1, global_sequence: 1, auth_sequence: [] }]
};
const result = (extra = {}) => ({ took: 1, timed_out: false, _shards: { total: 2, successful: 2, failed: 0, skipped: 0 }, hits: { total: { value: 1, relation: "eq" }, hits: [{ _source: structuredClone(source) }] }, ...extra });
async function setup(version, search) {
  const app = Fastify({ logger: false });
  const cache = new Map;
  const sets = [];
  app.decorate("manager", { chain: "qualification", readIndexset: () => "qualification-action-*", config: { api: { enable_caching: true, cache_life: 60, limits: { get_actions: 10 }, query_timeout: "10s" } } });
  app.decorate("redis", { get: async (key) => cache.get(key) ?? null, set: async (key, value, ...args) => {
    sets.push({ key, value, args });
    cache.set(key, value);
    return "OK";
  } });
  app.decorate("elastic", { search });
  app.decorate("antelope", { chain: { get_info: async () => ({ last_irreversible_block_num: { toNumber: () => 99 } }) } });
  app.decorate("allowedActionQueryParamSet", new Set);
  app.decorate("archiveRegistry", undefined);
  await app.register(version === 1 ? route1 : route2, { prefix: `/v${version}/history` });
  await app.ready();
  const request = version === 1 ? { method: "POST", url: "/v1/history/get_actions", payload: { account_name: "alice" } } : { method: "GET", url: "/v2/history/get_actions?hydrate=false" };
  return { app, cache, sets, request };
}
for (const version of [1, 2]) {
  for (const [kind, extra] of [
    ["timed_out", { timed_out: true }],
    ["failed_shard", { _shards: { total: 2, successful: 1, failed: 1, skipped: 0, failures: [{ shard: 1, index: "qualification-action-1", reason: { type: "query_shard_exception", reason: "controlled" } }] } }]
  ]) {
    const calls = [];
    const { app, request, sets } = await setup(version, async (...args) => {
      calls.push(args);
      return result(extra);
    });
    const first = await app.inject(request);
    const second = await app.inject(request);
    summary.push({ version, kind, firstStatus: first.statusCode, first: first.json(), secondStatus: second.statusCode, second: second.json(), esCalls: calls.length, esArgs: calls[0], cacheWrites: sets.length });
    await app.close();
  }
  for (const [kind, error] of [
    ["transport_timeout", new errors.TimeoutError("Controlled transport timeout")],
    ["transport_abort", new errors.RequestAbortedError("Controlled request abort")],
    ["server_503", new errors.ResponseError({ statusCode: 503, body: { error: { type: "search_phase_execution_exception", reason: "Controlled all shards failed" }, status: 503 }, headers: {}, meta: {} })]
  ]) {
    const { app, request, sets } = await setup(version, async () => {
      throw error;
    });
    const first = await app.inject(request);
    summary.push({ version, kind, status: first.statusCode, body: first.json(), cacheWrites: sets.length });
    await app.close();
  }
  let release;
  let entered;
  const started = new Promise((resolve) => {
    entered = resolve;
  });
  let completion = false, signalPassed = false, aborted = false;
  const calls = [];
  const { app, sets } = await setup(version, async (...args) => {
    calls.push(args);
    signalPassed = !!args[1]?.signal;
    args[1]?.signal?.addEventListener("abort", () => {
      aborted = true;
    });
    entered();
    await new Promise((resolve) => {
      release = resolve;
    });
    completion = true;
    return result();
  });
  const address = await app.listen({ port: 0, host: "127.0.0.1" });
  const body = version === 1 ? JSON.stringify({ account_name: "alice" }) : undefined;
  const req = httpRequest(address + `/v${version}/history/get_actions?hydrate=false`, { method: version === 1 ? "POST" : "GET", headers: version === 1 ? { "content-type": "application/json", "content-length": Buffer.byteLength(body) } : {} }, () => {});
  req.on("error", () => {});
  req.end(body);
  await Promise.race([started, new Promise((_, reject) => setTimeout(() => reject(new Error("search did not start")), 2000))]);
  req.destroy();
  await new Promise((resolve) => setTimeout(resolve, 50));
  release();
  await new Promise((resolve) => setTimeout(resolve, 50));
  summary.push({ version, kind: "http_client_disconnect", signalPassed, aborted, searchCompletedAfterDisconnect: completion, cacheWritesAfterDisconnect: sets.length, searchArgCount: calls[0]?.length });
  await app.close();
}
writeFileSync("C:/Users/igorl/.codex/scratch/es198-api-contract-audit-node-green.json", JSON.stringify({ sourceCommit: "b5c9080306c6739d81acb873dc66e32df77e1b82 + action-search workingtree fix", runtime: process.versions, summary }, null, 2) + `
`);
console.log(JSON.stringify(summary, null, 2));
