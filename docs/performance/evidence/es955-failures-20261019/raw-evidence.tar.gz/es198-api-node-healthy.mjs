import {createRequire} from 'node:module';
import {request} from 'node:http';
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
const root='C:/Users/igorl/.codex/worktrees/hyperion45-es955/hyperion-history-api';
const require=createRequire(root+'/package.json');
const Fastify=require('fastify');
const records=[];
for(const version of [1,2]) {
 const route=(await import(`file:///${root}/build/api/routes/v${version}-history/get_actions/index.js`)).default;
 const app=Fastify({logger:false});
 let signal;
 app.decorate('manager',{chain:'qualification',readIndexset:()=> 'qualification-action-*',config:{api:{enable_caching:false,limits:{get_actions:10}}}});
 app.decorate('redis',{get:async()=>null});
 app.decorate('antelope',{chain:{get_info:async()=>({last_irreversible_block_num:{toNumber:()=>99}})}});
 app.decorate('allowedActionQueryParamSet',new Set());
 app.decorate('elastic',{search:async(_params,options)=>{
   signal=options.signal;
   await new Promise(resolve=>setTimeout(resolve,30));
   assert.equal(signal.aborted,false);
   return {timed_out:false,_shards:{total:1,successful:1,failed:0,skipped:0},hits:{total:{value:0,relation:'eq'},hits:[]}};
 }});
 await app.register(route,{prefix:`/v${version}/history`});
 const address=await app.listen({port:0,host:'127.0.0.1'});
 const body=version===1?'{}':undefined;
 const result=await new Promise((resolve,reject)=>{
  const req=request(address+`/v${version}/history/get_actions?hydrate=false`,{method:version===1?'POST':'GET',headers:body?{'content-type':'application/json','content-length':body.length}:{}},res=>{let data='';res.on('data',chunk=>{data+=chunk});res.on('end',()=>resolve({version,status:res.statusCode,body:JSON.parse(data),signalAborted:signal.aborted}))});
  req.on('error',reject);req.end(body);
 });
 assert.equal(result.status,200);
 assert.equal(result.signalAborted,false);
 records.push(result);
 await app.close();
}
const report={runtime:process.versions,records};
writeFileSync('C:/Users/igorl/.codex/scratch/es198-api-node-healthy.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
