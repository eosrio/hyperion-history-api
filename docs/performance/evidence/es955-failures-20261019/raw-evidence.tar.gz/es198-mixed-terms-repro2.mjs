import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
const state=JSON.parse(await readFile('C:/Users/igorl/.codex/scratch/es198-failure-state.json','utf8'));
const owner=randomUUID(); const prefix='hyp-es955-'+owner.replaceAll('-','').slice(0,12);
const indices=[prefix+'-kw',prefix+'-long',prefix+'-kw2',prefix+'-long2'];const created=[]; const reports=[];
async function call(path,method='GET',body){const res=await fetch(state.url+path,{method,body:body?JSON.stringify(body):undefined,headers:{'content-type':'application/json'},signal:AbortSignal.timeout(10000)});const raw=await res.text();return {status:res.status,body:JSON.parse(raw),raw};}
async function identity(){const{body}=await call('/');assert.equal(body.cluster_uuid,state.clusterUuid);assert.equal(body.cluster_name,state.clusterName);assert.equal(body.version.number,'9.5.5');}
try {
 await identity();
 for(const [i,index] of indices.entries()){
  const type=i%2?'long':'keyword'; created.push(index);const r=await call('/'+index,'PUT',{settings:{number_of_shards:1,number_of_replicas:0},mappings:{_meta:{owner},properties:{metric:{type},global_sequence:{type:'long'}}}});assert.equal(r.status,200);
  for(let j=0;j<2;j++)assert.equal((await call('/'+index+'/_doc/'+j+'?refresh=true','PUT',{metric:i%2?j:'v'+j,global_sequence:i*2+j})).status,201);
  reports.push({case:'single:'+type,index,...await call('/'+index+'/_search','POST',{size:0,aggs:{mixed:{terms:{field:'metric',size:20}}}})});
 }
 for(const batch of [2,512])for(const sorted of [false,true])reports.push({case:'mixed',batch,sorted,...await call('/'+indices.join(',')+'/_search?batched_reduce_size='+batch+'&max_concurrent_shard_requests=5','POST',{size:sorted?10:0,...(sorted?{sort:{global_sequence:'desc'}}:{}),aggs:{mixed:{terms:{field:'metric',size:20}}}})});
} finally {
 for(const index of created){await identity(); const {body}=await call('/'+index+'/_mapping');assert.equal(body[index].mappings._meta.owner,owner);assert.equal((await call('/'+index,'DELETE')).status,200);}
 await writeFile('C:/Users/igorl/.codex/scratch/es198-mixed-terms-repro2.json',JSON.stringify({state,owner,reports,cleanup:'deleted'},null,2)+'\n',{flag:'wx'});
}
console.log(JSON.stringify(reports.map(r=>({case:r.case,batch:r.batch,sorted:r.sorted,status:r.status,error:r.body.error,aggs:r.body.aggregations})),null,2));
