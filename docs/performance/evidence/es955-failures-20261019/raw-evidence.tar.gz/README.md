# ES9.5.5 failure-slice raw evidence

Final qualification runs are ONLY es198-failures-node-http-final.json, es198-failures-node-default-final.json and es198-failures-bun-default-final.json. The draft1..5 files failed during fixture development; control1 and node-http-preaudit are earlier passing controls excluded from final totals.

es198-failure-source-review.md is the original, byte-preserved, SUPERSEDED investigation draft. Its proposed held-REST response recipe did not establish successful delivery after a closed phase consumer. See source-review-status.json and the public performance record before interpreting it.

internal-late-results.json is an offline production-class check, not a REST integration run. API red/green audits use actual route registration with controlled dependencies, separate from real-ES native fault injection.

Raw report paths identify local ephemeral resources only. The owning runtime lane recorded cleanup.json. No evidence here proves leak freedom, sustained production performance, runtime ranking or complete retained-history upgrade acceptance.
