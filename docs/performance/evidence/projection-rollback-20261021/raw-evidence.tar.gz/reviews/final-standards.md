# Final Standards delta review

Base: 88fe81728af4b73e08a4e6a531e3b3d3fe175e94
Head: 31f22333cba9ec123b9cb03a664d8b29bb169442
Axis: Standards, independent read-only follow-up.

Documented-standard breaches: 0.
Actionable Fowler-smell findings: 0.

The runtime now accepts and inertly captures the complete SDK rollback request, removing its independent abbreviated request shape and duplicated validation. It no longer reconstructs an old operation from the latest revision/checkpoint. Refusal reattaches only the same durable revision, while adapter readiness checks still fence pending or rotated recovery. Tests exercise retired requests, in-flight checkpoint changes and unchanged request identity.

The fixture additions strengthen evidence rather than making arbitrary failures pass. Only an acknowledged, explicitly retryable projection.apply-unavailable error qualifies for retry. Every such failure retains its native child/error trace and receives an independent expected-state check before another attempt. Unexpected errors, killed/timed-out processes and late successes remain failures. Attempts, total rollback calls, per-boundary time, trace records and error expansion are bounded; resource ownership and tracked-child cleanup remain in force. The added before-rollback-commit boundary broadens actual crash coverage without adapter test hooks or server-setting changes.

Documentation explains default transaction expiry, the exact-input retry rule and the distinction between synthetic correctness fixtures and release/live Wire qualification. SDK c0156c7 is pinned in both dependency locks. Installed root and adapter SDK projection emissions independently matched the reviewed SDK emission SHA-256 76d39cef6f02ec029e9d95038226bd4ffd9235a0526dbfb1e6e0ffd0fd295579.

Independent focused checks: Bun 1.4.3 runtime/harness tests, 17 passed and 170 assertions; native Node 24 syntax parsing passed for both pinned fixture scripts. No edits or database/service actions performed. Actual Linux MongoDB acceptance remains root work. The root-reported ordinary-object versus frozen null-prototype checkpoint assertion still needs normalization before claiming that matrix passed; projecting validated expected points to their explicit blockNum/blockId fields preserves identity checks and must retain the separate raw BSON revision assertions.
