# Spec review: SDK PR #15

Immutable range: `414e7c2771d55f730a316310ff0d0ed54492d9e2...1597db16188b510b751a7b95fd33f011e9fb6408`.

**[P2] Reject running rollback targets outside reported coverage** — `src/projection.ts:724-728`.

SDK #14 requires exposing "bounded retained recovery coverage and unavailable older history". The rollback contract states that an "ancestor outside actual coverage durably leaves the affected instance incomplete before throwing" `projection.rollback-unavailable` (`docs/projection-rollback.md:84-86`). The recovery validator checks the running cursor against `from`/`ancestor`, but never compares the running ancestor with `coverage.floor`. It accepts both a running target older than the oldest reachable ancestor and a target with the floor's height but another block ID. Because forward writes/pruning are prohibited during rollback, neither can describe a valid running local rollback. Internally contradictory progress can therefore pass the shared recovery validator used by the runtime.

Focused reproduction on native Node 22.23.3 and 24.19.0: `checkpoint=from=3`, `coverage.floor=2`, `retainedBlocks=1`, `rollback.status='running'`. Both `ancestor=1` and `ancestor={blockNum:2,blockId:'f'.repeat(64)}` return `valid:true`. An exact floor ancestor is the valid control. Probe: `out/projection-rollback/sdk-spec-probe-1597db1.mjs`.

For running state, require the ancestor at/above the floor and exact ID equality when heights match. Preserve acceptance of uncovered **unavailable** targets and **completed** receipts after replacement/pruning.

No other actionable Spec findings. The separate v2 interface preserves v1 validators/capabilities, remains backend-neutral, and correctly leaves real MongoDB/process-crash qualification to the adapter/runtime slice.

Spec: **1 finding**, worst **P2**. No source files edited.
