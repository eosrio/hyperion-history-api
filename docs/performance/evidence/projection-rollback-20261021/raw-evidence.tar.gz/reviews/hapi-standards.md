# Standards review: portable MongoDB rollback

HAPI base: 3a3e1d2a868635386172854c1157c76904547538
HAPI head: 88fe81728af4b73e08a4e6a531e3b3d3fe175e94
SDK follow-up: 1597db16188b510b751a7b95fd33f011e9fb6408..c0156c7bc65bee780b2215ba731ee6e5fe2bb52d
Axis: Standards, independent read-only review.

Documented-standard breaches: 0.
Actionable Fowler-smell findings: 0.

Reviewed against HAPI AGENTS.md, development-build.md, the shared TypeScript policy, accepted architecture, ADR 0048 and ADR 0043. The production diff keeps native storage, logical-query execution, undo layout and transaction checks inside the independently packaged MongoDB adapter. The recovery runtime reuses the existing mapper and ordered queue; its revision bridge earns its interface by fencing queued/in-flight work and read publication. Shared storage extraction serves two actual interfaces without duplicating transaction/query infrastructure. The v1 writer changes add storage guards and inert genesis capture without changing the existing worker/transport path or Elasticsearch history.

The new contract, retention limits, one-way migration, restart behavior and remaining host integration are documented separately from release qualification. Synthetic branch fixtures use independent expected rows and physical metadata checks, bound process time/output, verify owner callbacks and terminate only tracked child handles. No new generated build artifacts, native database logic in SDK/core, automatic dependency updates or live deployment were introduced.

The SDK follow-up uses the existing exact-checkpoint helpers to reject a running ancestor outside retained coverage, with a focused public-validator regression; no additional Standards findings.

Independent checks: immutable HAPI fixture scripts pass native Node 24 syntax parsing; SDK c0156c7 focused rollback tests pass 10/10 on Node 24.19.0. HAPI database/process-crash qualification was not executed by this review and remains the root's separate acceptance work. No source edits, database/service actions, pushes or merges performed. Post-head dependency repinning is excluded from this HAPI logic review.
