# Spec review: History API rollback candidate

Immutable range: `3a3e1d2a868635386172854c1157c76904547538...88fe81728af4b73e08a4e6a531e3b3d3fe175e94`.

**[P2] Preserve the original fence when retrying an older rollback operation** — `src/indexer/projection/recoverable-runtime.ts:200-202`.

HAPI #244 requires fencing stale writers; the SDK contract explicitly says superseded "older requests then fail their revision check" (`docs/projection-rollback.md` in the SDK). The runtime accepts only an operation ID, ancestor and step budget. Once a later operation supersedes its saved receipt, retrying the older ID no longer matches `before.rollback`; these lines substitute the current lane revision and current checkpoint. The adapter therefore receives a newly authorized request and can undo the newer branch instead of rejecting the retired request.

Reproduction on native Node 22.23.3 and 24.19.0 with a revision-checking reference adapter: complete fork-1 from block 4 to 1; apply replacement blocks through 4; complete fork-2 from 4 to 2; apply another replacement through 4; retry fork-1's original runtime input. The original SDK request rejects `projection.stale-revision`, but the runtime rewrites revision 1 to revision 3 and returns `rolled-back` at block 1. Probe: `out/projection-rollback/hapi-spec-retired-operation-probe.mjs`. This probe exercises the public runtime seam; it is not a real-Mongo qualification claim.

Capture and forward the original fenced rollback request unchanged. A stale expected checkpoint may require an explicit replan of a currently unadmitted operation; it must not authorize a retired retry automatically.

No other actionable Spec findings in this frozen range. Native process-crash qualification and checksummed run evidence remain the root's ongoing acceptance work.

SDK follow-up: the original recovery-coverage P2 is resolved in `c0156c7bc65bee780b2215ba731ee6e5fe2bb52d`. Reviewed its 31-line change and independently ran the targeted control test on Node 22/24: invalid running targets rejected; completed/unavailable older targets retained.

Spec: **1 finding**, worst **P2**. No source or database-service changes made.
