# Final Spec delta review

Immutable target: `31f22333cba9ec123b9cb03a664d8b29bb169442`, compared with previously reviewed `88fe81728af4b73e08a4e6a531e3b3d3fe175e94`. Runtime correction `1e34a3c` and SDK correction `c0156c7` were independently verified separately; their original P2 findings remain resolved.

**[P2] Accept a duplicate only when the recorded failed rollback attempt already proved completion** — `scripts/qualification/projection-rollback.mjs:338-339`.

The SDK contract requires that "retrying a lost completion response returns `duplicate`". The new retry path permits acknowledged retryable unavailable attempts whose independent physical oracle reports the ancestor checkpoint and completed rollback (`observeRollbackState`, lines 260-262). The next exact request correctly returns `duplicate`; `resumeRollback` returns that result, but this unconditional `rolled-back` assertion rejects it. Apply retries already distinguish this case using the recorded `failure.physical.completed` evidence.

A pure probe using the frozen retry helper reproduces the false failure on native Node 22.23.3 and 24.19.0: acknowledged `projection.apply-unavailable`, independently observed completed state, exact retry returns `duplicate`, current outer assertion fails. Probe: `out/projection-rollback/fixture-spec-completed-retry-probe-31f2233.mjs`. Require `duplicate` only when a recorded failed attempt proves completion; otherwise retain `rolled-back` and all existing strict physical checks. This is a fixture false negative, not evidence of product-state failure.

The already-owned prototype assertion correction is also required: native BSON checkpoints and SDK null-prototype snapshots need semantic checkpoint comparisons in `physical` and both `observeRollbackState` intent comparisons. Keep exact IDs and native revision/field-shape assertions.

No other new actionable Spec findings. Full plans remain frozen, retired retries preserve original identity, only acknowledged retryable unavailable attempts retry, failures/causes and physical states are retained, and both attempts and elapsed recovery are bounded. Successful end-to-end Node 22/24 qualification and checksummed evidence remain pending the corrected fixture run.

New Spec findings: **1 P2**, plus the known harness assertion correction already assigned. No source or service changes.
