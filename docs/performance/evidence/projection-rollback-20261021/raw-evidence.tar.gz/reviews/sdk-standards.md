# Standards review: SDK PR 15

Base: 414e7c2771d55f730a316310ff0d0ed54492d9e2
Head: 1597db16188b510b751a7b95fd33f011e9fb6408
Axis: Standards, independent read-only review.

Documented-standard breaches: 0.
Actionable Fowler-smell findings: 0.

Reviewed AGENTS.md, CONTRIBUTING.md, README.md, the shared TypeScript toolchain policy, accepted architecture, ADR 0048 and ADR 0043 against the complete immutable diff.

The added interface keeps native database execution outside the SDK, declares capability and version requirements explicitly, and preserves the existing v1 validators and capability baseline. New validators reuse the bounded inert snapshot/checkpoint/binding helpers. Types, documentation and independently packed consumers cover the same opt-in interface. The package stays private and its documentation separates contract checks from runtime/database/release qualification.

The additional validation branches express distinct state invariants; I found no unearned abstraction or duplication that warrants a change in this slice. Package and consumer checks retain native TypeScript emission and Node execution without introducing Bun runtime declarations or native driver types.

Independent focused validation: native Node 24.19.0, tests/projection-rollback.test.mjs, 9 passed, 0 failed. The reviewed SDK worktree remained clean at the pinned head. No source edits, pushes or merges performed. This review does not qualify MongoDB execution, process-crash recovery or live SHiP forks.
