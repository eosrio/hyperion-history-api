# Independent Spec follow-up: fixture oracle corrections

Base: `31f22333cba9ec123b9cb03a664d8b29bb169442`
Head: `781cd19bd30fac42a9d1318b00fb163bc357460e`
Scope: fixture-only commits `7a67b05` and `781cd19`; source read-only, no database/service actions.

Result: **0 remaining findings. Prior fixture P2 resolved.**

The rollback terminal assertion now requires `duplicate` only when this crashed-boundary attempt recorded an independently observed completed physical state; otherwise it requires `rolled-back` (`scripts/qualification/projection-rollback.mjs:339-340`). Completion from an earlier boundary is excluded by `failureStart`. Unsupported terminal statuses and stale-revision errors remain rejected.

Six point normalizations fix SDK null-prototype snapshots versus ordinary native metadata without weakening branch identity. The physical oracle still compares exact block number and ID, verifies the checkpoint's complete native field set, and requires its embedded revision to equal the metadata revision (`:208-212`). Recovery additionally checks exact operation/source revision, from/ancestor identities, rotated revision, pending/gap absence, physical rows and query availability (`:249-263`). Retention, unavailable-target and migration-floor assertions retain exact height/ID comparisons.

Verification: frozen-source pure probe passed on native Node **22.23.3** and **24.19.0**, with 21 reported checks. Negative controls rejected wrong height/ID, missing/extra native fields, revision mismatch/unrotated revision, wrong operation/source/ancestor identities, wrong recovery status, pending/gap conflicts, incorrect rows, unrelated completion evidence and incorrect terminal statuses. The acknowledged-unavailable retry reproduced completion followed by `duplicate` successfully.

Probe: `out/projection-rollback/fixture-oracle-fix-probe-781cd19.mjs`
Probe SHA-256: `034e57487c369e226ad7b42363529a5598004b2d1f8bd723a49d6556f3eb3321`

These probes validate fixture assertions, not MongoDB crash durability. The root agent owns the independent native Linux/MongoDB qualification matrix.
