# Runtime fence correction verification

Immutable correction: `40550a13a58d9e58396dca2f6cd29000fde09efc...1e34a3cf02aaf753b984781652063fbd835904d7`.

**Original Spec P2: resolved.** The runtime now inertly captures the complete original `ProjectionRollbackRequest`, checks its binding before invalidating local work, drains the old queue, and forwards the captured request unchanged. It no longer substitutes a newer revision or checkpoint for a retired operation.

Independently exercised the public runtime seam on native Node 22.23.3 and 24.19.0 using a revision-checking reference adapter. Five checks passed on each runtime:

- Two completed recoveries followed by the first operation's retired retry: rejected with `projection.stale-revision`; the newer checkpoint/revision and queries remain usable; adapter receives the original request unchanged.
- Malformed accessors and foreign bindings: rejected before reaching the adapter or invalidating healthy work.
- In-flight commit changes the planned source: original captured request is refused with `projection.stale-view`; unchanged current revision reattaches; a distinct explicit current plan succeeds.
- Refused requests cannot reopen a running recovery after restart.
- Refused requests cannot reopen an unavailable recovery after restart.

Probe: `out/projection-rollback/hapi-spec-runtime-fix-probe-1e34a3c.mjs`.

The shared build still contained the previous emission. I verified both runtime source files against the immutable target and used TypeScript 7 to emit only those files into the private ignored `build/spec-verify-1e34a3c` directory. Corrected runtime emission SHA-256: `a250e741142f46c881768dc727486aed8804fdafc55cc1cc4072e911ad5a226a`.

No remaining concrete findings in this correction. This verifies runtime request fencing and restoration guards; it does not replace the separate real-Mongo/process-crash qualification or live query-publication work. No source files or database services changed.
