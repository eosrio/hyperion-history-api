// Private evidence capture for the exclusively owned Tools #21 Mongo fixture.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFileSync, writeFileSync} from 'node:fs';
const base='/tmp/hyp45-p21-20261021';
const {MongoClient,BSON}=await import(`${base}/node24-source/node_modules/mongodb/lib/index.js`);
const owner=JSON.parse(readFileSync(`${base}/owner.json`,'utf8'));
const provision=JSON.parse(readFileSync(`${base}/provision.json`,'utf8'));
assert.equal(owner.owner,'windows:codex:hyperion-tools');
assert.equal(owner.issue,'eosrio/hyperion-tools#21');
const pid=execFileSync('systemctl',['show','hyp45-p21-mongo-20261021','--property=MainPID','--value'],{encoding:'utf8'}).trim();
assert.match(pid,/^[1-9][0-9]*$/);
const args=readFileSync(`/proc/${pid}/cmdline`).toString().split('\0');
const binary=`${base}/runtimes/mongodb-linux-x86_64-ubuntu2404-8.0.34/bin/mongod`;
assert.equal(args[0],binary);
assert.equal(createHash('sha256').update(readFileSync(binary)).digest('hex'),provision.artifacts.mongodb.binarySha256);
for(const [flag,value] of [['--dbpath',`${base}/data`],['--bind_ip','127.0.0.1'],['--port','58321'],['--replSet','hyp45p21']])
    assert.equal(args[args.indexOf(flag)+1],value);
const client=new MongoClient('mongodb://127.0.0.1:58321/?replicaSet=hyp45p21&directConnection=true',{
    appName:'hyp45-p21-evidence',maxPoolSize:1,serverSelectionTimeoutMS:5000,connectTimeoutMS:5000,timeoutMS:30000});
const snapshot={schemaVersion:1,createdAt:new Date().toISOString(),owner:owner.owner,issue:owner.issue,
    scope:'Complete owned synthetic application databases; administrative, config and local databases omitted',databases:[]};
let bytes=0,documents=0;
try {
    await client.connect();
    snapshot.parameters=await client.db('admin').command({getParameter:1,transactionLifetimeLimitSeconds:1});
    const names=(await client.db('admin').admin().listDatabases({nameOnly:true})).databases.map(item=>item.name).sort();
    for(const name of names) {
        if(['admin','config','local'].includes(name))continue;
        assert.match(name,/^(hyp_p21_(22|24)_[0-9a-f]{32}|hyp45_p21_adapter_20261021)$/);
        const database={name,collections:[]};
        for(const {name:collection} of await client.db(name).listCollections({},{nameOnly:true}).toArray()) {
            assert.match(collection,/^(h45_rollback|h45_projection|p21_[a-z0-9_]+)_[a-z0-9_]+$/);
            const values=await client.db(name).collection(collection).find({}).sort({_id:1}).limit(2001).toArray();
            assert.ok(values.length<=2000);
            const content=BSON.EJSON.stringify(values,{relaxed:false});bytes+=Buffer.byteLength(content);documents+=values.length;
            assert.ok(bytes<=16*1024*1024);
            database.collections.push({name:collection,documents:values.length,sha256:createHash('sha256').update(content).digest('hex'),ejson:content});
        }
        snapshot.databases.push(database);
    }
    snapshot.applicationBytes=bytes;snapshot.documents=documents;
    snapshot.completedAt=new Date().toISOString();
    writeFileSync(`${base}/application-snapshot.json`,JSON.stringify(snapshot,null,2)+'\n',{flag:'wx'});
    console.log(JSON.stringify({databases:snapshot.databases.length,documents,applicationBytes:bytes,status:'captured'}));
} finally {await client.close();}
