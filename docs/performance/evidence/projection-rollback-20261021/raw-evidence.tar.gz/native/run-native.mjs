// Private H3 orchestration. Public reproduction uses the owned Docker runner in the repository.
import assert from 'node:assert/strict';
import {createHash, randomUUID} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFileSync, writeFileSync} from 'node:fs';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

const base='/tmp/hyp45-p21-20261021';
const [directory,caseName]=process.argv.slice(2);
assert.ok(['node22-source','node24-source'].includes(directory));
assert.match(caseName,/^node(22|24)-[a-z0-9-]{1,48}$/);
const tree=resolve(base,directory);
const owner=JSON.parse(readFileSync(join(base,'owner.json'),'utf8'));
const provision=JSON.parse(readFileSync(join(base,'provision.json'),'utf8'));
const hash=value=>createHash('sha256').update(value).digest('hex');
assert.equal(owner.owner,'windows:codex:hyperion-tools');
assert.equal(owner.issue,'eosrio/hyperion-tools#21');
function assertOwned() {
    const pid=execFileSync('systemctl',['show','hyp45-p21-mongo-20261021','--property=MainPID','--value'],{encoding:'utf8'}).trim();
    assert.match(pid,/^[1-9][0-9]*$/);
    const args=readFileSync(`/proc/${pid}/cmdline`).toString().split('\0');
    const binary=join(base,'runtimes/mongodb-linux-x86_64-ubuntu2404-8.0.34/bin/mongod');
    assert.equal(args[0],binary);
    assert.equal(hash(readFileSync(binary)),provision.artifacts.mongodb.binarySha256);
    for(const [flag,value] of [['--dbpath',join(base,'data')],['--bind_ip','127.0.0.1'],['--port','58321'],['--replSet','hyp45p21']])
        assert.equal(args[args.indexOf(flag)+1],value);
}
assertOwned();
const files=['package.json','package-lock.json','packages/backend-mongodb/package.json','packages/backend-mongodb/package-lock.json',
    'src/indexer/projection/runtime.ts','build/indexer/projection/runtime.js',
    'src/indexer/projection/recoverable-runtime.ts','build/indexer/projection/recoverable-runtime.js',
    ...['index','contract','storage','rollback','rollback-contract'].flatMap(name=>[
        `packages/backend-mongodb/src/${name}.ts`,`packages/backend-mongodb/dist/${name}.js`]),
    'scripts/qualification/projection-rollback.mjs','scripts/qualification/projection-rollback-worker.mjs',
    'node_modules/@eosrio/hyperion-sdk/dist/projection.js'];
const report={schemaVersion:1,createdAt:new Date().toISOString(),caseName,qualification:false,
    scope:'Native Linux Node.js process-crash/rollback correctness on an owned bounded MongoDB fixture; synthetic forks, no live Wire or release qualification',
    node:{version:process.version,binarySha256:hash(readFileSync(process.execPath))},
    source:{head:execFileSync('git',['rev-parse','HEAD'],{cwd:tree,encoding:'utf8'}).trim(),
        status:execFileSync('git',['status','--porcelain'],{cwd:tree,encoding:'utf8'}).trim(),
        artifacts:Object.fromEntries(files.map(path=>[path,hash(readFileSync(join(tree,path)))]))},
    mongodb:{version:'8.0.34',archiveSha256:provision.artifacts.mongodb.sha256,binarySha256:provision.artifacts.mongodb.binarySha256},status:'running'};
assert.equal(report.source.status,'');
let failed=false;
try {
    const {runProjectionRollbackQualification}=await import(pathToFileURL(join(tree,'scripts/qualification/projection-rollback.mjs')));
    const run=randomUUID().replaceAll('-','');
    report.result=await runProjectionRollbackQualification({uri:'mongodb://127.0.0.1:58321/?replicaSet=hyp45p21&directConnection=true',
        databaseName:`hyp_p21_${process.versions.node.split('.')[0]}_${run}`,run,assertOwned});
    report.status='passed';
} catch(error) {
    failed=true;report.status='failed';report.error={message:error.message,stack:error.stack};
    if(error.rollbackReport)report.result=error.rollbackReport;
} finally {
    assertOwned();
    report.completedAt=new Date().toISOString();
    report.parentUsage={resource:process.resourceUsage(),cpu:process.cpuUsage(),memory:process.memoryUsage()};
    const group=readFileSync('/proc/self/cgroup','utf8').trim().split(':').at(-1);
    try {report.fixtureGroup={memoryPeak:readFileSync(join('/sys/fs/cgroup',group,'memory.peak'),'utf8').trim(),
        cpu:readFileSync(join('/sys/fs/cgroup',group,'cpu.stat'),'utf8').trim()};} catch {}
    writeFileSync(join(base,`${caseName}.json`),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
    console.log(JSON.stringify({status:report.status,caseName,head:report.source.head,
        checks:report.result?.checks?.length,processes:report.result?.processes?.length,error:report.error?.message}));
}
process.exitCode=failed?1:0;
