$ErrorActionPreference = 'Stop'
$scratch = 'C:\Users\igorl\.codex\scratch'
$run = ([guid]::NewGuid().ToString('N')).Substring(0,12)
$container = "hyp-es955-review-$run"
$volume = "$container-data"
$cluster = "hyperion-es198-$run"
$plugin = "$scratch\es198-pr203-native-build-20261019"
$image = 'docker.elastic.co/elasticsearch/elasticsearch@sha256:c40a1fb2bc6976821e5625d2329992a1e9c29df576e5955fdcba02421abf0d3c'
$expectedJar = '42d8f960965927ca1a716c900dfe651c2c93412724e320a71e8c72686eac2456'
if ((Get-FileHash "$plugin\hyperion-qualifier.jar").Hash.ToLowerInvariant() -ne $expectedJar) { throw 'Plugin hash mismatch' }
docker volume create --label 'io.eosrio.qualifier=es198-pr203-review' --label "io.eosrio.run=$run" $volume | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Volume creation failed' }
$dockerArgs = @('run','-d','--name',$container,'--label','io.eosrio.qualifier=es198-pr203-review','--label',"io.eosrio.run=$run",
    '--cpus','4','--memory','3g','-p','127.0.0.1::9200','--mount',"type=volume,src=$volume,dst=/usr/share/elasticsearch/data",
    '--mount',"type=bind,src=$plugin,dst=/usr/share/elasticsearch/plugins/hyperion-qualifier,readonly",
    '-e',"cluster.name=$cluster",'-e',"node.name=$container",'-e','discovery.type=single-node',
    '-e','xpack.security.enabled=false','-e','xpack.security.autoconfiguration.enabled=false','-e','xpack.ml.enabled=false',
    '-e','ingest.geoip.downloader.enabled=false','-e','cluster.routing.allocation.disk.watermark.low=20gb',
    '-e','cluster.routing.allocation.disk.watermark.high=10gb','-e','cluster.routing.allocation.disk.watermark.flood_stage=5gb',
    '-e','ES_JAVA_OPTS=-Xms1g -Xmx1g',$image)
$cid = docker @dockerArgs
if ($LASTEXITCODE -ne 0) { throw 'Container creation failed' }
$url = 'http://' + (docker port $cid 9200/tcp).Trim()
$state = [ordered]@{run=$run;container=$container;containerId=$cid.Trim();volume=$volume;clusterName=$cluster;url=$url;
    image=$image;pluginDirectory=$plugin;pluginJarSha256=$expectedJar;dockerArgs=$dockerArgs;createdAt=[DateTime]::UtcNow.ToString('o')}
$state | ConvertTo-Json -Depth 12 | Set-Content "$scratch\es198-pr203-review-state.json" -Encoding utf8
for ($attempt=0;$attempt -lt 90;$attempt++) {
    try {
        $info=Invoke-RestMethod $url -TimeoutSec 2
        if ($info.cluster_name -ne $cluster -or $info.version.number -ne '9.5.5') { throw 'Unexpected server identity' }
        $state.clusterUuid=$info.cluster_uuid
        $state | ConvertTo-Json -Depth 12 | Set-Content "$scratch\es198-pr203-review-state.json" -Encoding utf8
        $probe=Invoke-RestMethod "$url/_hyperion_qualifier/state" -TimeoutSec 2
        if ($probe.fixture_only -ne $true) { throw 'Missing qualifier plugin' }
        Write-Output "Ready $container $url $($info.cluster_uuid)"
        exit 0
    } catch { Start-Sleep -Milliseconds 500 }
}
docker logs --tail 30 $cid
throw 'Fixture failed to start'
