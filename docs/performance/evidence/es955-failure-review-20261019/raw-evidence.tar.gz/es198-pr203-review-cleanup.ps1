$ErrorActionPreference='Stop'
$scratch='C:\Users\igorl\.codex\scratch'
$s=Get-Content "$scratch\es198-pr203-review-state.json" -Raw | ConvertFrom-Json
$ins=@(docker inspect $s.containerId | ConvertFrom-Json)[0]
if ($LASTEXITCODE -ne 0 -or $ins.Config.Labels.'io.eosrio.run' -ne $s.run -or $ins.Config.Labels.'io.eosrio.qualifier' -ne 'es198-pr203-review') { throw 'Container ownership mismatch' }
$vol=@(docker volume inspect $s.volume | ConvertFrom-Json)[0]
if ($LASTEXITCODE -ne 0 -or $vol.Labels.'io.eosrio.run' -ne $s.run -or $vol.Labels.'io.eosrio.qualifier' -ne 'es198-pr203-review') { throw 'Volume ownership mismatch' }
$users=@(docker ps -a --no-trunc --filter "volume=$($s.volume)" --format '{{.ID}}')
if ($users.Count -ne 1 -or $users[0] -ne $s.containerId) { throw 'Unexpected volume consumer' }
$info=Invoke-RestMethod $s.url -TimeoutSec 5
if ($info.cluster_uuid -ne $s.clusterUuid -or $info.cluster_name -ne $s.clusterName) { throw 'Server identity mismatch' }
$indices=ConvertFrom-Json -InputObject (Invoke-WebRequest "$($s.url)/_cat/indices/hyp-es955-*?format=json&expand_wildcards=all" -TimeoutSec 5).Content -NoEnumerate
if ($indices.Count -ne 0) { throw 'Probe indices remain' }
$keys=Invoke-RestMethod "$($s.url)/_hyperion_qualifier/state" -TimeoutSec 5
if (@($keys.probes).Count -ne 0) { throw 'Fixture keys remain' }
$tasks=Invoke-RestMethod "$($s.url)/_tasks?actions=indices:data/read/search*&detailed=true&group_by=none" -TimeoutSec 5
if (@($tasks.tasks).Count -ne 0) { throw 'Search tasks remain' }
$stats=(Invoke-WebRequest "$($s.url)/_nodes/stats/indices,jvm,breaker" -TimeoutSec 5).Content
$stats | Set-Content "$scratch\es198-pr203-review-postflight-stats.json" -Encoding utf8
@{inspect=$ins;volume=$vol;tasks=$tasks;keys=$keys;indices=$indices} | ConvertTo-Json -Depth 40 | Set-Content "$scratch\es198-pr203-review-postflight.json" -Encoding utf8
docker stop --timeout 20 $s.containerId | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Stop failed' }
docker rm $s.containerId | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Container removal failed' }
docker volume rm $s.volume | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Volume removal failed' }
$containerResidue=@(docker ps -a --filter "label=io.eosrio.run=$($s.run)" --format '{{.ID}}')
$volumeResidue=@(docker volume ls --filter "label=io.eosrio.run=$($s.run)" --format '{{.Name}}')
if ($containerResidue.Count -ne 0 -or $volumeResidue.Count -ne 0) { throw 'Owned resource residue' }
$result=@{run=$s.run;container=$s.container;volume=$s.volume;containerRemoved=$true;volumeRemoved=$true;
    remainingIndices=$indices.Count;remainingKeys=@($keys.probes).Count;remainingSearchTasks=@($tasks.tasks).Count;
    remainingOwnedContainers=$containerResidue.Count;remainingOwnedVolumes=$volumeResidue.Count;completedAt=[DateTime]::UtcNow.ToString('o')}
$result | ConvertTo-Json -Depth 10 | Set-Content "$scratch\es198-pr203-review-cleanup.json" -Encoding utf8
$result | ConvertTo-Json -Compress
