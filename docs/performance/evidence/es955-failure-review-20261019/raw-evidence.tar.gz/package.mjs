import assert from 'node:assert/strict';
import {readFile, writeFile, mkdir, copyFile, readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {assertCollectionDeadline, assertServerTaskCancelled, assertRecovered} from '../worktrees/hyperion45-es955/hyperion-history-api/scripts/qualification/es955-failures.ts';

const scratch = 'C:/Users/igorl/.codex/scratch';
const repo = 'C:/Users/igorl/.codex/worktrees/hyperion45-es955/hyperion-history-api';
const dest = repo + '/docs/performance/evidence/es955-failure-review-20261019';
const stage = scratch + '/es198-pr203-review-package';
const digest = b => createHash('sha256').update(b).digest('hex');
const json = async p => JSON.parse(await readFile(p, 'utf8'));
const save = async (p, data) => writeFile(p, JSON.stringify(data, null, 2) + '\n');
await mkdir(stage);
await mkdir(dest);
const state = await json(scratch + '/es198-pr203-review-state.json');
const names = ['node-http', 'node-default', 'bun-default'];
const expected = {'healthy-control': 12, 'precollection-timeout': 20, 'strict-precollection-timeout': 10,
    'collection-deadline': 10, 'partial-shard-failure': 10, 'strict-shard-failure': 10,
    'http-abort': 5, 'task-cancel': 5, 'late-script-after-client-abort': 5};
const summaries = [];
for (const name of names) {
    const filename = `es198-pr203-${name}.json`;
    const r = await json(scratch + '/' + filename);
    assert.equal(r.status, 'passed'); assert.equal(r.trials.length, 87);
    assert.equal(r.acknowledged_documents, 1000); assert.equal(r.cleanup.length, 4);
    assert.ok(r.cleanup.every(c => c.ok)); assert.equal(r.rounds.length, 5);
    assert.equal(r.server.cluster_uuid, state.clusterUuid);
    assert.equal(r.server.version.number, '9.5.5');
    assert.equal(r.server.version.build_hash, '48acba663b09e70b115dd879329141506c377890');
    assert.equal(r.client, '8.19.1'); assert.equal(r.transport, '8.10.1');
    assert.equal(r.runtime.bun, name.startsWith('bun') ? '1.4.3' : null);
    assert.equal(r.runtime.node, name.startsWith('node') ? 'v24.19.0' : r.runtime.node);
    assert.equal(r.runtime.selected_connection, name === 'node-default' ? 'UndiciConnection' : 'HttpConnection');
    const counts = Object.fromEntries(Object.keys(expected).map(k => [k, r.trials.filter(t => t.kind === k).length]));
    assert.deepEqual(counts, expected);
    for (const [file, hash] of Object.entries(r.source_hashes)) assert.equal(digest(await readFile(repo + '/' + file)), hash);
    for (const t of r.trials) {
        if (t.kind === 'collection-deadline') assertCollectionDeadline(t.body, t.plugin);
        if (['http-abort', 'task-cancel'].includes(t.kind)) assertServerTaskCancelled(t.recovered.plugin);
        if (t.recovered) {
            assertRecovered(r.baseline.counters, t.recovered.snapshot.counters);
            assert.equal(t.recovered.snapshot.tasks.length, 0); assert.ok(t.recovered.elapsed_ms < 15000);
            for (const field of ['active', 'active_slow', 'delay_active']) assert.equal(t.recovered.plugin[field], 0);
        }
        const p = t.plugin ?? t.recovered?.plugin;
        if (p) {
            assert.equal(p.entered, p.active + p.completed + p.task_cancelled + p.query_timed_out + p.failed);
            assert.equal(p.slow_entered, p.active_slow + p.slow_completed + p.slow_task_cancelled + p.slow_query_timed_out + p.slow_failed);
            assert.equal(p.delay_started, p.delay_active + p.delay_finished);
        }
    }
    assertRecovered(r.baseline.counters, r.final_recovery.snapshot.counters);
    assert.equal(r.final_recovery.snapshot.tasks.length, 0);
    const recoveries = r.trials.filter(t => t.recovered).map(t => t.recovered.elapsed_ms);
    summaries.push({name, report: filename, status: r.status, trials: r.trials.length, trialKinds: counts,
        acknowledgedDocuments: r.acknowledged_documents, runtime: r.runtime, startedAt: r.started_at, completedAt: r.completed_at,
        verifiedCollectionDeadlines: 10, verifiedHttpTaskCancellations: 5, verifiedExplicitTaskCancellations: 5,
        maxPerCaseRecoveryMs: Math.max(...recoveries), peakSampledRequestBreakerBytes:
            Math.max(...r.snapshots.flatMap(s => Object.values(s.counters).map(n => n.requestBytes))),
        finalCounters: r.final_recovery.snapshot.counters, cleanup: r.cleanup, sourceHashes: r.source_hashes});
    await copyFile(scratch + '/' + filename, stage + '/' + filename);
}
const cleanup = await json(scratch + '/es198-pr203-review-cleanup.json');
assert.equal(cleanup.containerRemoved, true); assert.equal(cleanup.volumeRemoved, true);
for (const field of ['remainingIndices', 'remainingKeys', 'remainingSearchTasks', 'remainingOwnedContainers', 'remainingOwnedVolumes']) assert.equal(cleanup[field], 0);
for (const file of ['es198-pr203-review-state.json', 'es198-pr203-review-postflight.json',
    'es198-pr203-review-postflight-stats.json', 'es198-pr203-review-cleanup.json',
    'es198-pr203-review-start.ps1', 'es198-pr203-review-cleanup.ps1']) await copyFile(scratch + '/' + file, stage + '/' + file);
const sourceFiles = ['scripts/qualification/es955-failures.ts', 'scripts/qualification/es955.ts',
    'scripts/qualification/fixture/HyperionQualifierPlugin.java', 'scripts/qualification/fixture/build.sh',
    'scripts/qualification/fixture/plugin-descriptor.properties', 'scripts/qualification/fixture/README.md',
    'tests/unit/es955-failures.test.ts', 'build/api/routes/v2-history/get_actions/functions.js',
    'build/indexer/helpers/es-connection.js', 'package-lock.json'];
for (const file of sourceFiles) {
    await mkdir(path.dirname(stage + '/source/' + file), {recursive: true});
    await copyFile(repo + '/' + file, stage + '/source/' + file);
}
await copyFile(state.pluginDirectory + '/hyperion-qualifier.jar', stage + '/hyperion-qualifier.jar');
assert.equal(digest(await readFile(stage + '/hyperion-qualifier.jar')), state.pluginJarSha256);
await copyFile(scratch + '/es198-pr203-package.mjs', stage + '/package.mjs');
await writeFile(stage + '/README.md', '# PR203 review follow-up evidence\n\n'
    + 'Three new 87-case runs use separate native task-cancellation/query-timeout counters and stricter acceptance gates. Original evidence remains byte-preserved in ../es955-failures-20261019 and is not replaced or combined with these reruns.\n\n'
    + 'The archive includes measured runner/fixture/helper source snapshots, exact fixture JAR, local setup and cleanup, server counters and all three reports. Runtime paths in state identify throwaway local resources. No full-stack, pressure, replica or leak-freedom claim follows.\n');
const artifacts = [];
async function inventory(prefix = '') {
    for (const entry of (await readdir(stage + '/' + prefix, {withFileTypes: true})).sort((a,b) => a.name.localeCompare(b.name))) {
        const relative = prefix + entry.name;
        if (entry.isDirectory()) await inventory(relative + '/');
        else { const bytes = await readFile(stage + '/' + relative); artifacts.push({path: relative, bytes: bytes.length, sha256: digest(bytes)}); }
    }
}
await inventory();
const executableRecord = async p => ({path: p, sha256: digest(await readFile(p))});
await save(dest + '/manifest.json', {schemaVersion: 1, createdAt: new Date().toISOString(),
    baseCommit: '2f76badff3fed51d09c303c6c46a1eb44051bd6d',
    sourceState: 'Uncommitted review correction source snapshots; measured runner reports independently record their hashes.',
    review: 'https://github.com/eosrio/hyperion-history-api/pull/203#pullrequestreview-5566805267',
    fixture: state, node: await executableRecord(process.execPath),
    bun: await executableRecord('C:/Users/igorl/.bun/bin/bun.exe'), artifacts});
await save(dest + '/summary.json', {schemaVersion: 1, localDate: '2026-10-19',
    scope: 'Fresh qualification after PR203 evidence-oracle review', runs: summaries,
    totalTrials: 261, verifiedCollectionDeadlines: 30, verifiedHttpTaskCancellations: 15, verifiedExplicitTaskCancellations: 15,
    cleanup, originalEvidence: '../es955-failures-20261019',
    limits: ['Same bounded synthetic single-node corpus; zero replicas; unchanged server/client pins',
        'Original 261 cases retained separately; independent raw-event audit confirmed their intended paths',
        'Separate retained native counters establish which exception occurred, even after diagnostic event eviction',
        'Resource-accounting recovery is not sustained memory-pressure, heap-leak freedom or runtime performance qualification']});
await writeFile(dest + '/.gitattributes', '*.json text eol=lf\nSHA256SUMS text eol=lf\n*.tar.gz binary\n');
const tar = spawnSync('tar', ['-czf', dest + '/raw-evidence.tar.gz', '-C', stage, '.'], {encoding: 'utf8'});
assert.equal(tar.status, 0, tar.stderr);
const verify = scratch + '/es198-pr203-review-verify'; await mkdir(verify);
const extract = spawnSync('tar', ['-xzf', dest + '/raw-evidence.tar.gz', '-C', verify], {encoding: 'utf8'});
assert.equal(extract.status, 0, extract.stderr);
for (const a of artifacts) assert.equal(digest(await readFile(verify + '/' + a.path)), a.sha256, 'archive read-back mismatch: ' + a.path);
await writeFile(dest + '/SHA256SUMS', (await Promise.all(['manifest.json','summary.json','raw-evidence.tar.gz'].map(async p => `${digest(await readFile(dest + '/' + p))}  ${p}`))).join('\n') + '\n');
console.log(JSON.stringify({runs: summaries.map(r => ({name:r.name,trials:r.trials,maxRecoveryMs:r.maxPerCaseRecoveryMs,peakRequestBytes:r.peakSampledRequestBreakerBytes})),artifacts:artifacts.length,cleanup}));
