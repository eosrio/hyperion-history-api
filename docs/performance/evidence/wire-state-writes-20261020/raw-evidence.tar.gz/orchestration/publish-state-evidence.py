import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile

work = Path(__file__).resolve().parent
candidate = '093e111e739805a9b4eb531259709647042a8c20'
destination = work / 'hyperion-history-api/docs/performance/evidence/wire-state-writes-20261020'
staging = work / 'publication-staging-v2'
assert not staging.exists()
assert not destination.exists() or (destination.is_dir() and not any(destination.iterdir()))
receipt = json.loads((work / 'linux-received/package-receipt.json').read_text())
archive_path = work / 'linux-received/linux-state-evidence.tar.gz'
manifest_path = work / 'linux-received/linux-state-manifest.json'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(archive_path.read_bytes()) == receipt['sha256']
assert sha(manifest_path.read_bytes()) == receipt['manifestSha256']
manifest = json.loads(manifest_path.read_text())
assert manifest['sourceCommit'] == candidate
expected = {item['path']: item for item in manifest['files']}
assert len(expected) == len(manifest['files']) <= 10000
assert sum(item['bytes'] for item in expected.values()) <= 512 * 1024 * 1024
staging.mkdir()
destination.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    assert len(members) == len(expected) + 1
    for member in members:
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert member.size <= 128 * 1024 * 1024
        data = archive.extractfile(member).read()
        if member.name == manifest_path.name:
            assert data == manifest_path.read_bytes()
        else:
            item = expected.pop(member.name)
            assert len(data) == item['bytes'] and sha(data) == item['sha256']
        target = staging / 'linux' / member.name
        target.parent.mkdir(parents=True, exist_ok=True)
        assert not target.exists()
        target.write_bytes(data)
assert not expected

def copy(source, target):
    assert source.is_file() and not source.is_symlink() and not source.is_junction()
    assert source.stat().st_size <= 128 * 1024 * 1024
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    data = source.read_bytes()
    target.write_bytes(data)
    assert sha(target.read_bytes()) == sha(data)

local_records = [
    'npm-ci.log', 'build-membership-fix.log', 'typecheck-membership-app.log', 'typecheck-membership-qualification.log',
    'unit-final.log', 'unit-final-fixture-fix.log', 'unit-final-membership-fix.log', 'version-pin-focused.log',
    'inherited-membership-before-native.log', 'inherited-membership-after-node22.log', 'inherited-membership-after-node24.log',
    'legacy-dynamic-repro.mjs', 'legacy-dynamic-repro.json', 'legacy-dynamic-repro.md', 'legacy-dynamic-repro-root.json',
    'barrier-guards-root.log', 'state-guards.log', 'optin-node22-root.log',
    'standards-review-received.md', 'spec-review-received.md', 'followup-review-received.md',
    'ci-candidate.json', 'ci-checks-candidate.json',
]
for name in local_records:
    copy(work / name, staging / 'local-records' / name)
for name in ('prepare-linux-state-run.py', 'update-linux-state-candidate.py', 'sync-linux-state-candidate.py',
             'run-linux-state-case.py', 'package-linux-state-evidence.py', 'publish-state-evidence.py'):
    copy(work / name, staging / 'orchestration' / name)

ci = json.loads((work / 'ci-candidate.json').read_text())
checks = json.loads((work / 'ci-checks-candidate.json').read_text())
assert ci['headSha'] == candidate and ci['status'] == 'completed' and ci['conclusion'] == 'success'
assert len(checks) == 9 and all(check['state'] == 'SUCCESS' for check in checks)
results = []
for entry in manifest['cases']:
    if not entry['acceptance']:
        continue
    case = entry['case']
    root = staging / 'linux/evidence' / case
    report = json.loads((root / 'run/report.json').read_text())
    case_receipt = json.loads((root / 'case.json').read_text())
    assert report['sourceCommit'] == candidate and report['status'] == case_receipt['status'] == 'passed'
    state = report['stateWrites']
    assert state['serverVersion'] == '8.0.32' and state['mode'] == case.split('-')[1]
    assert state['final']['rows'] == (12 if state['mode'] == 'enabled' else 0)
    for observation in state['snapshots']:
        data = (root / 'run' / observation['file']).read_bytes()
        assert sha(data) == observation['observationSha256']
    assert report['masterExit'] == {'code': 0, 'signal': None} and report['shutdown']['success']
    assert case_receipt['resourceInventoryRestored'] and all(item['ok'] for item in report['cleanup'])
    for physical in report['durableCopies']:
        for field in ('sourceProofsSha256', 'expectationsSha256', 'actions', 'blocks', 'historyDeltas', 'abiReferences', 'coordinatorCommits'):
            assert physical['evidence'][field] == report['outputs'][field]
    results.append({'case': case, 'report': 'linux/evidence/' + case + '/run/report.json',
                    'reportSha256': sha((root / 'run/report.json').read_bytes()), 'sourceCommit': candidate,
                    'runtime': report['runtime'], 'serverVersion': report['server']['version']['number'],
                    'stateWrites': state, 'readerConfirmations': report['readerConfirmations'],
                    'replayMetrics': report['replayMetrics'], 'bulkAccounting': report['bulkAccounting'],
                    'publicationEvidence': report['publicationEvidence'],
                    'outputs': {key: value for key, value in report['outputs'].items() if key not in ('sourceProofs', 'gaps')},
                    'shutdown': report['shutdown'], 'masterExit': report['masterExit'],
                    'lastIndexedBeforeShutdown': report['lastIndexedBeforeShutdown'],
                    'cleanup': {'resourceInventoryRestored': True, 'remainingContainers': 0, 'remainingVolumes': 0, 'remainingNetworks': 0}})
assert len(results) == 4
summary = {'schemaVersion': 1, 'sourceCommit': candidate,
           'pullRequest': 'https://github.com/eosrio/hyperion-history-api/pull/239',
           'scope': 'Legacy Mongo effects of original retained Wire blocks through native Linux workers; correctness only',
           'host': {'name': 'x570-hyperion-1', 'os': 'Ubuntu 24.04.4', 'kernel': '6.8.0-136-generic', 'hardware': 'Ryzen 9 5950X; 128 GiB RAM'},
           'runs': results, 'excludedCases': [entry for entry in manifest['cases'] if not entry['acceptance']],
           'ci': ci, 'ciChecks': checks, 'unitTests': {'passed': 978, 'skipped': 1, 'failed': 0, 'expectations': 6728},
           'limits': ['Only selected legacy Mongo collections; no portable runtime initialization, API readiness or canonical recovery grant.',
                      'Original 7d blocks 2..120 only; initial ancestry/ABI state unknown; selected testnet launch pins pending.',
                      'Two secondary insertions observed; secondary update/deletion, duplicate delivery and crash/restart are not qualified.',
                      'Legacy Mongo worker fixture is 8.0.32 with driver7.2.0, separate from portable adapter Mongo8.0.34 conformance.',
                      'Public action admission and gated full-range history storage remain disabled; no retained-history upgrade qualification.',
                      'Supervised clean child exits are separate from production checkpoint/restart and power-loss durability.',
                      'No Rust, Bun runtime, Wire6508, fork/reconnect or performance conclusion follows from these observed cases.']}
(destination / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
files = []
for path in sorted(staging.rglob('*')):
    if path.is_file():
        data = path.read_bytes()
        files.append({'path': path.relative_to(staging).as_posix(), 'bytes': len(data), 'sha256': sha(data)})
assert len(files) < 10000 and sum(item['bytes'] for item in files) < 512 * 1024 * 1024
published_manifest = {'schemaVersion': 1, 'sourceCommit': candidate, 'files': files,
                      'linuxAliases': 'linux/linux-state-manifest.json records metadata-only relative log aliases'}
(destination / 'manifest.json').write_bytes((json.dumps(published_manifest, indent=2) + '\n').encode())
with tarfile.open(destination / 'raw-evidence.tar.gz', 'x:gz') as archive:
    for item in files:
        path = staging / item['path']
        assert sha(path.read_bytes()) == item['sha256']
        archive.add(path, arcname=item['path'], recursive=False)
shutil.copyfile(staging / 'linux/evidence/postflight.json', destination / 'postflight.json')
print(json.dumps({'directory': str(destination), 'files': len(files), 'rawBytes': sum(item['bytes'] for item in files),
                  'archiveBytes': (destination / 'raw-evidence.tar.gz').stat().st_size,
                  'archiveSha256': sha((destination / 'raw-evidence.tar.gz').read_bytes())}))
