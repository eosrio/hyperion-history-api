import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

previous, candidate = sys.argv[1:]
assert all(re.fullmatch('[0-9a-f]{40}', value) for value in (previous, candidate))
root = Path('/var/snap/docker/common/hyperion-qualification/run-20261020-wire-state-writes')
repo = root / 'repo'
assert root.is_dir() and not root.is_symlink() and repo.is_dir() and not repo.is_symlink()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == previous
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
for path in (root / 'evidence').glob('node*-*-*'):
    receipt = json.loads((path / 'case.json').read_text())
    assert receipt['resourceInventoryRestored'] and 'completedAt' in receipt
    assert all(receipt['coreRemaining'][key] == 0 for key in ('remainingContainers', 'remainingVolumes', 'remainingNetworks'))
preparation = json.loads((root / 'preparation.json').read_text())
env = os.environ.copy()
node = Path(preparation['runtimes']['node24']['path'])
bun = Path(preparation['runtimes']['bun']['path'])
env['PATH'] = os.pathsep.join([str(node.parent), str(bun.parent), env['PATH']])
receipt = {'previousRevision': previous, 'sourceRevision': candidate, 'servicesCreated': False, 'steps': []}
steps = [
    ('fetch', ['git', 'fetch', 'origin', 'codex/wire-state-write-qualification']),
    ('fast-forward', ['git', 'merge', '--ff-only', candidate]),
    ('typecheck-qualification', [bun, 'check', '-p', 'scripts/qualification/tsconfig.json']),
]
for name, args in steps:
    path = root / 'evidence' / ('candidate-' + candidate[:7] + '-' + name + '.log')
    with path.open('xb') as log:
        result = subprocess.run([str(arg) for arg in args], cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    receipt['steps'].append({'step': name, 'exitCode': result.returncode, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    assert result.returncode == 0, name
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == candidate
receipt['status'] = 'prepared'
with (root / ('candidate-' + candidate[:7] + '.json')).open('x') as output:
    json.dump(receipt, output, indent=2)
    output.write('\n')
print(json.dumps(receipt))
