"""Run one fresh, owned Wire worker correctness case; retain failure and cleanup receipts."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

root = Path('/var/snap/docker/common/hyperion-qualification/run-20261020-wire-state-writes')
repo = root / 'repo'
preparation = json.loads((root / 'preparation.json').read_text())
runtime_name, mode, case_name, expected_commit = sys.argv[1:]
assert runtime_name in ('node22', 'node24')
assert mode in ('enabled', 'disabled')
assert re.fullmatch(re.escape(runtime_name + '-' + mode) + r'-[1-9]', case_name)
assert len(expected_commit) == 40 and all(c in '0123456789abcdef' for c in expected_commit)
assert not root.is_symlink() and repo.is_dir() and not repo.is_symlink()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == expected_commit
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
node = Path(preparation['runtimes'][runtime_name]['path'])
pwsh = Path(preparation['runtimes']['pwsh']['path'])
for tool in (runtime_name, 'pwsh', 'bun'):
    record = preparation['runtimes'][tool]
    assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['sha256']
case = root / 'evidence' / case_name
assert not case.exists() and not case.is_symlink(), 'refusing existing case evidence'
case.mkdir()
state = case / 'state.json'
output = case / 'run'
env = os.environ.copy()
env['PATH'] = os.pathsep.join([str(node.parent), str(pwsh.parent),
                              str(Path(preparation['runtimes']['bun']['path']).parent), env['PATH']])
fixture = repo / 'scripts/qualification/es955-worker-fixture.ps1'


def inventory():
    result = {}
    for kind, args in [('containers', ['ps', '-aq', '--no-trunc']),
                       ('volumes', ['volume', 'ls', '-q']),
                       ('networks', ['network', 'ls', '-q', '--no-trunc'])]:
        result[kind] = sorted(subprocess.check_output(['docker', *args], text=True, timeout=20).split())
    return result


def command(label, args, timeout):
    with (case / (label + '.log')).open('xb') as log:
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run([str(item) for item in args], cwd=repo, env=env,
                                stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    return {'command': label, 'startedAt': started, 'exitCode': result.returncode,
            'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'logSha256': hashlib.sha256((case / (label + '.log')).read_bytes()).hexdigest()}


receipt = {'schemaVersion': 1, 'case': case_name, 'runtime': preparation['runtimes'][runtime_name],
           'sourceCommit': expected_commit, 'status': 'running', 'commands': [],
           'before': inventory(), 'host': os.uname()._asdict() if hasattr(os.uname(), '_asdict') else list(os.uname())}
(case / 'before.json').write_text(json.dumps(receipt, indent=2) + '\n')
try:
    created = command('create', [pwsh, '-NoProfile', '-File', fixture, '-Action', 'create', '-StateFile', state], 360)
    receipt['commands'].append(created)
    assert created['exitCode'] == 0, 'fixture create failed; see retained create.log'
    run = command('driver', [node, '--experimental-strip-types', repo / 'scripts/qualification/wire-worker-replay.ts', state, output, '--contract-state', mode], 700)
    receipt['commands'].append(run)
    if (output / 'report.json').is_file():
        report_bytes = (output / 'report.json').read_bytes()
        report = json.loads(report_bytes)
        receipt['reportSha256'] = hashlib.sha256(report_bytes).hexdigest()
        receipt['workerStatus'] = report['status']
        receipt['stateMode'] = mode
        receipt['workerError'] = report.get('error')
        receipt['masterExit'] = report.get('masterExit')
        receipt['workerCleanup'] = report.get('cleanup')
        assert report['status'] == 'passed', 'worker correctness run failed; see retained report'
        assert report['stateWrites']['mode'] == mode
        assert report['stateWrites']['final']['rows'] == (12 if mode == 'enabled' else 0)
        if mode == 'enabled':
            assert [item['through'] for item in report['stateWrites']['snapshots']] == [78,81,84,87,90,93,96,99,120]
        receipt['sourceCommitMatches'] = report.get('sourceCommit') == expected_commit
        assert receipt['sourceCommitMatches'], 'driver source commit differs'
    else:
        raise AssertionError('driver report absent')
    assert run['exitCode'] == 0, 'driver failed; see retained driver.log'
    receipt['status'] = 'passed'
except Exception as error:
    receipt['status'] = 'failed'
    receipt['error'] = str(error)
finally:
    if state.is_file():
        try:
            cleanup = command('cleanup', [pwsh, '-NoProfile', '-File', fixture, '-Action', 'cleanup', '-StateFile', state], 180)
            receipt['commands'].append(cleanup)
            assert cleanup['exitCode'] == 0, 'ownership-checked cleanup failed'
            cleanup_bytes = Path(str(state) + '.cleanup.json').read_bytes()
            cleanup_result = json.loads(cleanup_bytes)
            receipt['cleanupSha256'] = hashlib.sha256(cleanup_bytes).hexdigest()
            receipt['coreRemaining'] = cleanup_result['coreCleanup']
            assert all(cleanup_result['coreCleanup'][key] == 0 for key in
                       ('remainingContainers', 'remainingVolumes', 'remainingNetworks'))
        except Exception as error:
            receipt['status'] = 'failed'
            receipt['cleanupError'] = str(error)
    receipt['after'] = inventory()
    receipt['resourceInventoryRestored'] = receipt['before'] == receipt['after']
    if not receipt['resourceInventoryRestored']:
        receipt['status'] = 'failed'
    receipt['completedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (case / 'case.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
sys.exit(0 if receipt['status'] == 'passed' else 1)
