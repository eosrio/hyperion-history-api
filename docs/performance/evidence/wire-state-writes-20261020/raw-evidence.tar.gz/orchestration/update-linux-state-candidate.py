import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/var/snap/docker/common/hyperion-qualification/run-20261020-wire-state-writes')
repo = root / 'repo'
previous = '5a1aa7b9816d041a31044d255d283ab137938eaf'
candidate = 'b2aa1102198d43b5eab988fda1e7ffd5a777dfe1'
assert root.is_dir() and not root.is_symlink() and repo.is_dir() and not repo.is_symlink()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == previous
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
assert not any((root / 'evidence').glob('node*-*-1'))
preparation = json.loads((root / 'preparation.json').read_text())
env = os.environ.copy()
node = Path(preparation['runtimes']['node24']['path'])
bun = Path(preparation['runtimes']['bun']['path'])
env['PATH'] = os.pathsep.join([str(node.parent), str(bun.parent), env['PATH']])
for name in ('node24', 'node22', 'bun'):
    record = preparation['runtimes'][name]
    assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['sha256']
receipt = {'previousRevision': previous, 'sourceRevision': candidate, 'servicesCreated': False, 'steps': []}
steps = [
    ('fetch', ['git', 'fetch', 'origin', 'codex/wire-state-write-qualification']),
    ('fast-forward', ['git', 'merge', '--ff-only', candidate]),
    ('build', ['npm', 'run', 'build']),
    ('typecheck-app', [bun, 'check', '-p', 'tsconfig.json']),
    ('typecheck-qualification', [bun, 'check', '-p', 'scripts/qualification/tsconfig.json']),
    ('opt-in-node24', [node, 'tests/unit/contract-state-authorization-worker.mjs']),
    ('opt-in-node22', [preparation['runtimes']['node22']['path'], 'tests/unit/contract-state-authorization-worker.mjs']),
]
for name, args in steps:
    path = root / 'evidence' / ('candidate-b2aa110-' + name + '.log')
    with path.open('xb') as log:
        result = subprocess.run([str(arg) for arg in args], cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    receipt['steps'].append({'step': name, 'exitCode': result.returncode, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    assert result.returncode == 0, name
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == candidate
receipt['status'] = 'prepared'
with (root / 'candidate-b2aa110.json').open('x') as output:
    json.dump(receipt, output, indent=2)
    output.write('\n')
print(json.dumps(receipt))
