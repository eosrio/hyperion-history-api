import hashlib
import json
import os
from pathlib import Path
import subprocess

base=Path('/var/snap/docker/common/hyperion-qualification')
root=base/'run-20261020-wire-state-writes'
candidate='5a1aa7b9816d041a31044d255d283ab137938eaf'
assert base.is_dir() and not base.is_symlink() and not root.exists() and not root.is_symlink()
previous=json.loads((base/'run-20261020-wire-workers/preparation.json').read_text())
for name,record in previous['runtimes'].items():
    assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest()==record['sha256']
root.mkdir()
(root/'evidence').mkdir()
receipt={'schemaVersion':1,'sourceRevision':candidate,'directory':str(root),'runtimes':previous['runtimes'],
         'servicesCreated':False,'steps':[]}
subprocess.run(['git','clone','--depth','1','--branch','codex/wire-state-write-qualification',
                'https://github.com/eosrio/hyperion-history-api.git',str(root/'repo')],check=True,timeout=180)
repo=root/'repo'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==candidate
env=os.environ.copy()
node=Path(receipt['runtimes']['node24']['path'])
bun=Path(receipt['runtimes']['bun']['path'])
pwsh=Path(receipt['runtimes']['pwsh']['path'])
env['PATH']=os.pathsep.join([str(node.parent),str(bun.parent),str(pwsh.parent),env['PATH']])
(root/'preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
steps=[('npm-ci',['npm','ci','--allow-git=all','--no-audit','--no-fund']),
       ('typecheck-app',[bun,'check','-p','tsconfig.json']),
       ('typecheck-qualification',[bun,'check','-p','scripts/qualification/tsconfig.json']),
       ('source-node24',[node,'--experimental-strip-types','scripts/qualification/check-wire-replay-fixture.mjs']),
       ('source-node22',[receipt['runtimes']['node22']['path'],'--experimental-strip-types','scripts/qualification/check-wire-replay-fixture.mjs'])]
for label,args in steps:
    path=root/'evidence'/(label+'.log')
    with path.open('xb') as log:
        result=subprocess.run([str(arg) for arg in args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    receipt['steps'].append({'step':label,'exitCode':result.returncode,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (root/'preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    assert result.returncode==0,label+' failed; preserve log and source'
receipt['status']='prepared'
(root/'preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
