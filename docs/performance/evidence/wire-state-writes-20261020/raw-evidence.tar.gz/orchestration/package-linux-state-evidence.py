import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tarfile

candidate, *selected = sys.argv[1:]
assert re.fullmatch('[0-9a-f]{40}', candidate)
assert len(selected) == 4 and len(set(selected)) == 4
assert {tuple(name.split('-')[:2]) for name in selected} == {
    ('node22', 'enabled'), ('node22', 'disabled'), ('node24', 'enabled'), ('node24', 'disabled')}
assert all(re.fullmatch(r'node(?:22|24)-(?:enabled|disabled)-[1-9]', name) for name in selected)
root = Path('/var/snap/docker/common/hyperion-qualification/run-20261020-wire-state-writes')
repo = root / 'repo'
assert root.is_dir() and not root.is_symlink()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
cases = []
runs = []
for case in sorted((root / 'evidence').glob('node*-*-*')):
    receipt = json.loads((case / 'case.json').read_text())
    assert receipt['resourceInventoryRestored'] and receipt['before'] == receipt['after']
    assert all(receipt['coreRemaining'][key] == 0 for key in ('remainingContainers', 'remainingVolumes', 'remainingNetworks'))
    runs.append(json.loads((case / 'state.json').read_text())['run'])
    if case.name not in selected:
        assert receipt['status'] == 'failed', 'unselected successful case requires explanation'
        cases.append({'case': case.name, 'acceptance': False, 'status': receipt['status']})
        continue
    report = json.loads((case / 'run/report.json').read_text())
    assert receipt['status'] == report['status'] == 'passed'
    assert receipt['sourceCommit'] == report['sourceCommit'] == candidate
    assert report['readerConfirmations']['blocks'] == 119
    assert report['replayMetrics']['totalSentBlocks'] == report['replayMetrics']['totalAcknowledgedBlocks'] == 119
    assert report['masterExit'] == {'code': 0, 'signal': None}
    assert report['shutdown']['success'] and not report['shutdown']['forced'] and not report['shutdown']['unresolved']
    assert report['shutdown']['exited'] == report['shutdown']['children']
    assert all(row['ok'] for row in report['cleanup'])
    state = report['stateWrites']
    assert state['mode'] == case.name.split('-')[1] and state['serverVersion'] == '8.0.32'
    assert not state['servingReadinessQualified'] and not state['final']['servingReadinessQualified']
    assert state['final']['rows'] == (12 if state['mode'] == 'enabled' else 0)
    assert [entry['through'] for entry in state['snapshots']] == ([78,81,84,87,90,93,96,99,120] if state['mode'] == 'enabled' else [])
    assert len(report['durableCopies']) == 2
    cases.append({'case': case.name, 'status': 'passed', 'acceptance': True, 'sourceCommit': candidate})
assert set(selected) <= {entry['case'] for entry in cases}

remaining = []
for item in os.scandir('/proc'):
    if not item.name.isdigit():
        continue
    proc = Path(item.path)
    try:
        args = (proc / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        cwd = (proc / 'cwd').resolve(strict=True)
    except (FileNotFoundError, ProcessLookupError):
        continue
    if cwd.is_relative_to(root / 'evidence') or str(repo / 'build/indexer/launcher.js') in args:
        remaining.append({'pid': int(item.name), 'cwd': str(cwd), 'command': args})
assert not remaining, 'owned worker processes remain'
resources = []
for run in runs:
    assert re.fullmatch('[0-9a-f]{12}', run)
    entry = {'run': run}
    for key, args in [('containers', ['ps', '-aq', '--filter']), ('volumes', ['volume', 'ls', '-q', '--filter']), ('networks', ['network', 'ls', '-q', '--filter'])]:
        entry[key] = subprocess.check_output(['docker', *args, 'label=io.eosrio.run=' + run], text=True, timeout=20).split()
        assert not entry[key], 'owned resources remain'
    resources.append(entry)
postflight = {'schemaVersion': 1, 'performedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'host': os.uname().nodename, 'testedCodeCommit': candidate,
              'ownedWorkerProcessesRemaining': remaining, 'ownedResourcesRemaining': resources}
with (root / 'evidence/postflight.json').open('x') as output:
    json.dump(postflight, output, indent=2)
    output.write('\n')

entries = [root / 'preparation.json', *sorted(root.glob('candidate-*.json')), *sorted((root / 'evidence').rglob('*'))]
files, links = [], []
for path in entries:
    if path.is_symlink():
        target = path.readlink()
        assert path.name == 'deserialization_errors.log' and len(target.parts) == 1 and not target.is_absolute()
        actual = path.parent / target
        assert actual.is_file() and not actual.is_symlink()
        links.append({'path': path.relative_to(root).as_posix(), 'target': str(target),
                      'targetSha256': hashlib.sha256(actual.read_bytes()).hexdigest(),
                      'archiveTreatment': 'metadata only; ordinary target retained'})
        continue
    if path.is_dir():
        continue
    assert path.is_file() and path.stat().st_size <= 128 * 1024 * 1024
    relative = path.relative_to(root).as_posix()
    assert not PurePosixPath(relative).is_absolute() and '..' not in PurePosixPath(relative).parts
    data = path.read_bytes()
    files.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
assert len(files) <= 10000 and sum(item['bytes'] for item in files) <= 512 * 1024 * 1024
manifest = {'schemaVersion': 1, 'sourceCommit': candidate, 'cases': cases, 'files': files, 'links': links,
            'bytes': sum(item['bytes'] for item in files)}
manifest_path = root / 'linux-state-manifest.json'
with manifest_path.open('x') as output:
    json.dump(manifest, output, indent=2)
    output.write('\n')
archive = root / 'linux-state-evidence.tar.gz'
with tarfile.open(archive, 'x:gz') as output:
    for item in files:
        path = root / item['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256'], 'evidence changed during packaging'
        output.add(path, arcname=item['path'], recursive=False)
    output.add(manifest_path, arcname=manifest_path.name, recursive=False)
print(json.dumps({'path': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'bytes': archive.stat().st_size, 'manifestSha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
                  'files': len(files), 'sourceBytes': manifest['bytes']}))
