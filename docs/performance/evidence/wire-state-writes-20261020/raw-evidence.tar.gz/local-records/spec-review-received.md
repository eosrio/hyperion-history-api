# Spec review: Wire state opt-in and Mongo effect qualification

Reviewer: windows:codex:hyperion-tools (/root/action_admission_spec_final).
Correlation: task_wire_state_spec_b8777b7_20261020.
Fixed command: git diff 5043829d633c397f493e107e1766c9eb19cacbd1...b8777b754ea0bd35c3119d78965c0df037190a0f.
Both refs resolve; the nonempty range contains only b8777b7, "fix: honor state opt-in and qualify Wire Mongo effects".
Spec: out/portable-state-workers/disabled-contract-state-issue.md (HAPI238), bounded HAPI212 qualification, accepted architecture.

## Finding

[P2] Require own contract/table entries for operator authorization.
Spec: "Require explicit enabled:true for operator-configured contract/table writes" and "Exercise the real producer method for disabled/omitted/enabled flags, selected/unselected tables and plugin-authorized accounts."

In src/indexer/workers/deserializer.ts:1690, the rewritten operatorAuthorized expression uses inherited object lookup. With enabled:true, contracts:{contracta:{records:{}}}, no plugin authorization, and an actual row for contracta::constructor, contracts.contracta.constructor resolves the inherited Object function. Publication therefore proceeds for an unselected table. Both names are valid Antelope names. With contracts:{} and constructor::prototype, the expression also authorizes an unselected contract. Require own-property membership at both dictionary levels and add these denied cases to the emitted-producer regression.

This inherited selection weakness existed before the diff; it remains an unmet selection requirement in the rewritten authorization, rather than an unintended consequence of requiring enabled:true.

## Other reviewed behavior and qualification limits

No additional missing/wrong behavior or scope creep found. The feature-absent early return is preserved, while independent plugin authorization survives false/omitted enabled when the feature object exists. Authorized payload/header construction and queue rotation remain unchanged.

The barrier only caps original sends; it does not mint credits or modify captured results/status. The state oracle derives from independently audited physical source rows/official decoded values, checks primary and secondary identities, intermediate updates and actual post-delete absence, and requires empty selected collections in the disabled control. Existing ownership/namespace checks and serving/initialization gates remain.

The separately inspected two-line follow-up adding enabled:true to positive protocol fixtures correctly restores their explicit opt-in without relaxing effect/proof assertions; it is outside this fixed range.

No tests or services run by this reviewer. Full-suite results and actual Linux enabled/disabled write evidence remain root-owned pending qualification. Neither #191/#221 nor broad release readiness is established.
