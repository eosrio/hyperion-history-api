# Legacy dynamic state: actual-method reproduction

Task `task_legacy_dynamic_repro_5043829_20261020`; request `evt_20261020T120226_44e43079c342`.
Author lane `/root/action_coverage_flow`, identity `windows:codex:hyperion-tools`.

Fixed History API source: `5043829d633c397f493e107e1766c9eb19cacbd1`, in `out/wire-full-worker/hyperion-history-api`. The bounded script requires that HEAD and clean target production source. It imports the existing emitted production classes, retains source/build/function hashes, bypasses the connection-owning worker constructor, and stubs only owned transport/database boundaries. It invokes the real `pushToDynamicTableQueue`, `enqueueDerivedPublication`, `MongoRoutes`, `indexMongoBatch`, `ElasticRoutes`, dynamic route registration and generic bulk settlement methods.

The script passed syntax checking and executed on Node v24.19.0 in under one second. Socket connects were blocked, with **zero attempts**. No service, Docker, remote, source, commit or push changes occurred. Its marked temporary configuration directory was removed by the guarded `finally` path. All messages and database results are explicitly constructed component data and simulated transport receipts; this is not native database, RabbitMQ, capture or state-readiness evidence.

## Active path and confirmed operator flag behavior

`IndexerWorker` checks Mongo routes before ES routes (`src/indexer/workers/indexer.ts:63`). `MongoRoutes` registers `dynamic-table` when a Mongo connection/client is available (`helpers/mongo-routes.ts:23`). Its actual dynamic route (`:211`) reads `headers.present` and uses:

- Ordinary legacy rows: collection `${code}-${table}`, filter `{'@scope': scope, '@pk': primary_key}`.
- Protocol rows: the same collection separation, filter `{'@protocol_key': protocolStateKey(protocol.id, chainId, logicalIdentity)}`; retained metadata includes `@protocol` and the state key.

The producer intentionally omits `body.id`, `body.present` and `headers.id`; these fields are unnecessary for this active Mongo route. The captured insert/deletion envelopes retain headers `present:1` and `present:0`, respectively.

Actual route/batch methods issued four `updateOne` operations and one `deleteOne` across two collections. The same scope/key updated within `contracta-alpha`, remained independent in `contracta-beta`, and a different scope stayed independent within `alpha`. After the simulated deletion, only scope `bob` remained in `alpha`, while `beta` retained its row. All five original delivery tags were ACKed exactly once after the simulated writes completed; no NACKs occurred.

The producer's flag handling (`workers/deserializer.ts:1682`) confirmed distinct cases:

| Operator state / account authorization | Publications |
|---|---:|
| `enabled:false`, operator-configured table, no plugin authorization | 1 |
| `enabled` omitted, operator-configured table, no plugin authorization | 1 |
| `enabled:false`, empty operator tables, explicit plugin-authorized account | 1 |
| Falsey contract-state feature | 0 |
| `enabled:true`, neither configured nor authorized | 0 |

The first disabled operator envelope also reached the actual Mongo route and generated a simulated write/ACK. Master prepares operator collections only when `contract_state.enabled` is truthy (`modules/master.ts:2253`), while the producer checks only object truthiness before its table/allowlist tests. This confirms the operator flag mismatch.

Plugin authorization is a separate compatibility path: `HyperionModuleLoader.appendDynamicContracts` (`modules/loader.ts:199`) adds enabled plugins' declared accounts to `allowedDynamicContracts`; the worker populates that set at `deserializer.ts:171`. The script preserves this as a separate case. These explicitly plugin-required writes are **not** classified as a flag bug. The accepted follow-up is to gate operator-configured mappings while retaining plugin dependencies; no production fix was made here.

## Inactive Elasticsearch helper

The normal `ElasticRoutes` constructor has **no `dynamic-table` route**: both registration calls are commented out (`helpers/elastic-routes.ts:525,536`). Master likewise does not register a dynamic ES index mapping (`modules/master.ts:860`). The missing-body-field observation must not be described as an operational ES state failure.

For the requested latent-helper probe only, the script explicitly calls the existing private registration method. That helper reads `body.id/body.present` even though the actual producer supplies neither. Both insert and deletion therefore generate `update` metadata with `_id:undefined`; JSON serialization omits `_id`, and no delete operation appears. Its target is `${chain}-dt-${code}`, which supplies contract separation but no table separation itself. This is an inactive incompatible helper; **no fix is proposed**.

Two controlled response cases show actual settlement behavior: local transport refusal and an untrustworthy item-success response each caused both delivery tags to be NACKed/requeued, with zero ACKs. No ES server response was claimed. Explicitly constructed body-id/presence controls, which the actual producer does not emit, generate update/delete operations. The missing-delete 404 control ACKed both originals with an indexed count of one. Two explicit insert controls sharing one ID were both ACKed by item position; the current generic builder does not drop the second receipt through its temporary ID map. These controls establish settlement behavior, not a valid ES identity policy.

## Secondary relevance and limits

Production `processProtocolRecord` sends both primary and source-secondary normalized records to the dynamic helper (`deserializer.ts:2212–2238`); only primary insertions execute primary-table hooks. The script's **constructed**, uncaptured secondary envelopes use identical secondary keys with distinct primary suffixes. The actual Mongo route produced distinct protocol-key filters in the same `wiresec-users` collection and preserved metadata. This checks route identity only. It does not prove selected-testnet input, secondary update/deletion, rollback, replay completeness, durable acknowledgments, query behavior or live state readiness.

The portable state implementation remains HAPI #191 through MongoDB. This report does not replace its backend-neutral projection/worker/fork/serving qualification. Root owns the separate operator flag fix and real Wire Mongo worker acceptance.

## Reproduction and immutable files

Run with the fixed checkout and a **new** output path:

```powershell
& C:/Users/igorl/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe P:/eosrio/hyperion-tools/out/sequence-coverage/legacy-dynamic-repro-5043829-20261020.mjs --repo P:/eosrio/hyperion-tools/out/wire-full-worker/hyperion-history-api --output P:/eosrio/hyperion-tools/out/sequence-coverage/legacy-dynamic-repro-repeat.json
```

Script SHA-256: `67de7f77ba4f49886b5c3e62f56d27936bf56642c50f35a60883102fb5042037`.

Receipt JSON SHA-256: `418e1286749dcea57d72c86d050ed993dd7ce67c19ef18c6d5105c8de5583c74`.

Both files are frozen beside this note under `out/sequence-coverage/`. The receipt preserves exact enqueue bodies/headers, raw content hashes, bulk operation metadata (including visible undefined values and actual serialized NDJSON), Mongo operations/collection identities, delivery dispositions and source/build/function provenance.
