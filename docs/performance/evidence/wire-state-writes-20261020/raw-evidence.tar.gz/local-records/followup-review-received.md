# Independent follow-up review: b2aa110

Reviewer: windows:codex:hyperion-tools (/root/action_admission_spec_final).
Correlation: task_wire_state_followup_b2aa110_20261020.
Fixed command: git diff b8777b754ea0bd35c3119d78965c0df037190a0f...b2aa1102198d43b5eab988fda1e7ffd5a777dfe1.
Both refs resolve; the nonempty range contains:
- 5a1aa7b test: explicitly enable state in positive Wire fixtures
- b2aa110 fix: require own contract and table selections

## Standards

No concrete findings. Reviewed the four changed files against repository AGENTS.md, docs/development-build.md and the code-review skill's heuristic baseline. The change remains localized to authorization and focused regressions, adds no dependency/toolchain changes, and does not alter worker/public interfaces. No tooling-enforced or speculative style findings reported.

## Spec

No remaining concrete findings. The prior inherited-membership P2 is resolved in src/indexer/workers/deserializer.ts:1690-1693: own-property membership is required for both the contract dictionary and its table dictionary before operator authorization succeeds.

This meets HAPI238's requirement to exercise "selected/unselected tables and plugin-authorized accounts" while keeping "payload and source metadata unchanged for authorized writes." The emitted-producer regression adds inherited contract/table cases and both actual constructor counterexamples. It also positively checks explicit constructor table and constructor contract selections; no name blacklist is substituted for membership.

Explicit enabled:true remains required for operator selection. Independent plugin authorization and the absent-feature early return are unchanged. Authorized payload/header construction and queue rotation are outside the changed production hunk.

The only changes in tests/unit/protocol-abi-consumer-worker.mjs:26 and tests/unit/protocol-worker-fixture.mjs:43 add enabled:true to existing positive configurations. Their original effect, source-proof, failure and byte assertions remain unchanged. This corrects fixture authorization rather than weakening the intended opt-in behavior.

This follow-up introduces no source-barrier, Mongo oracle, initialization, API-readiness or release-scope change.

No tests, services or source edits performed. Root's native Node22/24 results, current full suite and fresh Linux qualification are separate evidence; this note establishes only the read-only follow-up code verdict.

Standards: 0 findings. Spec: 0 remaining findings; prior P2 resolved.
