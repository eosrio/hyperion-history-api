/** Resource-free reproduction against existing emitted production methods. No database/broker/chain services. */
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {createHash, randomUUID} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {existsSync, lstatSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, rmSync, writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {basename, dirname, join, resolve, sep} from 'node:path';
import {pathToFileURL} from 'node:url';
import {Socket} from 'node:net';

const args = process.argv.slice(2), options = {};
for (let i = 0; i < args.length; i += 2) {assert.ok(['--repo', '--output'].includes(args[i]) && args[i + 1]); assert.ok(!options[args[i]]); options[args[i]] = args[i + 1];}
assert.ok(options['--repo'] && options['--output'], 'Usage: node legacy-dynamic-repro-5043829-20261020.mjs --repo <fixed HAPI checkout> --output <new receipt.json>');
const repo = realpathSync(resolve(options['--repo'])), output = resolve(options['--output']);
assert.ok(!existsSync(output) && !lstatSync(realpathSync(dirname(output))).isSymbolicLink(), 'output must be new under an existing ordinary directory');
const revision = '5043829d633c397f493e107e1766c9eb19cacbd1';
const git = (...args) => execFileSync('git', ['--no-optional-locks', '-C', repo, ...args], {encoding: 'utf8', timeout: 5000, env: {...process.env, GIT_OPTIONAL_LOCKS: '0'}}).trim();
assert.equal(git('rev-parse', 'HEAD'), revision, 'fixed source revision required');
const paths = ['src/indexer/workers/deserializer.ts', 'src/indexer/helpers/elastic-routes.ts', 'src/indexer/helpers/mongo-routes.ts',
    'src/indexer/helpers/mongo-batch.ts', 'src/indexer/workers/indexer.ts', 'src/indexer/modules/master.ts'];
assert.equal(git('diff', '--no-ext-diff', revision, '--', ...paths), '', 'target production source must be unchanged');
const hash = value => createHash('sha256').update(value).digest('hex');
const clone = value => structuredClone(value);
const provenance = [...paths, ...paths.slice(0, 4).map(path => path.replace(/^src\//, 'build/').replace(/\.ts$/, '.js'))]
    .map(path => ({path, bytes: readFileSync(join(repo, path)).length, sha256: hash(readFileSync(join(repo, path)))}));
const chain = 'owned-dynamic-probe', chainId = 'f'.repeat(64), originalCwd = process.cwd();
const watchdog = setTimeout(() => {console.error('Bounded component probe exceeded 10 seconds'); process.exit(124);}, 10000); watchdog.unref();
const taskTemporaryBase = realpathSync(tmpdir()), taskTemporary = realpathSync(mkdtempSync(join(taskTemporaryBase, 'hyperion-dynamic-probe-'))), marker = randomUUID();
writeFileSync(join(taskTemporary, '.owner'), marker, {flag: 'wx'});
const oldEnv = {CONFIG_JSON: process.env.CONFIG_JSON, worker_role: process.env.worker_role, live_mode: process.env.live_mode};
const networkAttempts = [], originalConnect = Socket.prototype.connect;
Socket.prototype.connect = function () {networkAttempts.push('blocked socket connect'); throw new Error('Network disabled in owned component reproduction');};
const evidence = {schemaVersion: 1, revision, node: process.version, kind: 'constructed-production-method-component-reproduction',
    qualification: {nativeDatabase: false, broker: false, sourceCapture: false, stateReadiness: false}, provenance, cases: {}};
function capture(body, headers, tag) {return {content: Buffer.from(body), properties: {headers: clone(headers)}, fields: {deliveryTag: tag, consumerTag: 'owned-probe'}};}
class Channel extends EventEmitter {
    acknowledgments = []; requeues = []; closed = false; pending;
    constructor(messages) {super(); this.pending = new Set(messages.map(message => message.fields.deliveryTag));}
    ack(message) {const tag = message.fields.deliveryTag; assert.ok(this.pending.delete(tag), 'duplicate/foreign ACK'); this.acknowledgments.push(tag);}
    nack(message, multiple, requeue) {assert.equal(multiple, false); const tag = message.fields.deliveryTag; assert.ok(this.pending.delete(tag), 'duplicate/foreign NACK'); this.requeues.push({tag, requeue});}
    async close() {this.closed = true; this.emit('close');}
}
const row = (present, table = 'alpha', scope = 'alice', value = 1) => ({'@timestamp': '2026-10-20T12:00:00.000', code: 'contracta', table,
    scope, primary_key: '7', payer: 'alice', block_num: 50 + value, block_id: value.toString(16).padStart(64, '0'), present, data: {value}});
let Main, ElasticRoutes, MongoRoutes, indexMongoBatch;
try {
    mkdirSync(join(taskTemporary, 'config'));
    writeFileSync(join(taskTemporary, 'chain.json'), JSON.stringify({settings: {chain, eosio_alias: 'eosio', parser: '3.2'},
        indexer: {}, features: {}, scaling: {}, api: {}, whitelists: {actions: [], deltas: []}}));
    writeFileSync(join(taskTemporary, 'config/connections.json'), JSON.stringify({chains: {[chain]: {chain_id: chainId}}}));
    process.env.CONFIG_JSON = join(taskTemporary, 'chain.json'); process.env.worker_role = 'reader'; process.env.live_mode = 'true'; process.chdir(taskTemporary);
    [{default: Main}, {ElasticRoutes}, {MongoRoutes}, {indexMongoBatch}] = await Promise.all([
        import(pathToFileURL(join(repo, 'build/indexer/workers/deserializer.js')).href),
        import(pathToFileURL(join(repo, 'build/indexer/helpers/elastic-routes.js')).href),
        import(pathToFileURL(join(repo, 'build/indexer/helpers/mongo-routes.js')).href),
        import(pathToFileURL(join(repo, 'build/indexer/helpers/mongo-batch.js')).href),
    ]);
    evidence.methodHashes = Object.fromEntries([
        ['pushToDynamicTableQueue', Main.prototype.pushToDynamicTableQueue], ['enqueueDerivedPublication', Main.prototype.enqueueDerivedPublication],
        ['registerDynamicTableRoute', ElasticRoutes.prototype.registerDynamicTableRoute], ['createGenericBuilder', ElasticRoutes.prototype.createGenericBuilder],
        ['mongoAddDynamicRoutes', MongoRoutes.prototype.addDynamicRoutes], ['indexMongoBatch', indexMongoBatch],
    ].map(([name, method]) => [name, hash(Function.prototype.toString.call(method))]));
    async function produce(contractState, rows, allowed = []) {
        const sent = [], worker = Object.create(Main.prototype);
        Object.assign(worker, {chain, dyn_emit_idx: 1, allowedDynamicContracts: new Set(allowed),
            conf: {features: {contract_state: contractState}, scaling: {dyn_idx_queues: 2}},
            preIndexingQueue: {async push(payload) {sent.push({queue: payload.queue, content: Buffer.from(payload.content), headers: clone(payload.headers)});}}});
        for (const input of rows) worker.pushToDynamicTableQueue(clone(input));
        await new Promise(resolve => setImmediate(resolve));
        return sent;
    }
    const configured = enabled => ({enabled, contracts: {contracta: {alpha: {}, beta: {}}, wiresec: {users: {}}}});
    const enabled = await produce(configured(true), [row(1), row(0, 'alpha', 'alice', 2)]);
    assert.equal(enabled.length, 2);
    for (const message of enabled) {const body = JSON.parse(message.content); assert.equal(Object.hasOwn(body, 'id'), false); assert.equal(Object.hasOwn(body, 'present'), false); assert.equal(Object.hasOwn(message.headers, 'id'), false);}
    assert.deepEqual(enabled.map(message => message.headers.present), [1, 0]);
    evidence.cases.producerEnabled = enabled.map(message => ({queue: message.queue, body: JSON.parse(message.content), headers: message.headers, contentSha256: hash(message.content)}));
    const disabled = await produce(configured(false), [row(1)]), disabledAllowed = await produce({enabled: false, contracts: {}}, [row(1)], ['contracta']);
    const omitted = configured(false); delete omitted.enabled; const omittedEnabled = await produce(omitted, [row(1)]);
    const falsey = await produce(false, [row(1)]), notConfigured = await produce({enabled: true, contracts: {}}, [row(1)]);
    assert.equal(disabled.length, 1); assert.equal(disabledAllowed.length, 1); assert.equal(omittedEnabled.length, 1); assert.equal(falsey.length, 0); assert.equal(notConfigured.length, 0);
    evidence.cases.featureGate = {enabledFalseConfiguredPublications: disabled.length, enabledFalseAllowedContractPublications: disabledAllowed.length,
        enabledOmittedOperatorConfiguredPublications: omittedEnabled.length, pluginAuthorizedAccounts: ['contracta'],
        falseyFeaturePublications: falsey.length, enabledTrueUnselectedPublications: notConfigured.length};

    async function elastic(messages, mode, registerLatent) {
        const requests = [], channel = new Channel(messages), cm = {chain, config: {settings: {index_version: 'v1', index_partition_size: 1000}, scaling: {indexing_queues: 1}}, ingestClients: [{async bulk(request) {
            requests.push(clone(request)); const items = [];
            for (let offset = 0; offset < request.operations.length;) {const op = request.operations[offset], kind = Object.keys(op)[0], id = op[kind]._id;
                if (mode === 'reject-invalid' && id === undefined) throw new Error('Owned transport refuses missing operation ID; this is not an ES server response');
                items.push({[kind]: {_id: String(id), status: kind === 'delete' ? 404 : 200}}); offset += kind === 'delete' ? 1 : 2;}
            return {errors: items.some(item => Object.values(item)[0].status >= 400), items};}}]};
        const routes = new ElasticRoutes(cm); assert.equal(routes.routes['dynamic-table'], undefined);
        if (!registerLatent) return {normalConstructorHasDynamicRoute: false};
        // Explicitly invoke the existing private helper. This does not represent the registered runtime route.
        routes.registerDynamicTableRoute(); let indexed;
        await routes.routes['dynamic-table'](messages, channel, result => {indexed = result;});
        return {latentHelperManuallyRegistered: true, simulatedTransportMode: mode, requests: requests.map(request => ({...request,
            operationsWithUndefinedVisible: request.operations.map(op => JSON.parse(JSON.stringify(op, (_key, value) => value === undefined ? {$undefined: true} : value))),
            ndjson: request.operations.map(op => JSON.stringify(op)).join('\n') + '\n'})), indexed, acknowledgments: channel.acknowledgments, requeues: channel.requeues};
    }
    const messages = enabled.map((message, index) => capture(message.content, message.headers, index + 1));
    evidence.cases.defaultElastic = await elastic(messages, 'reject-invalid', false);
    evidence.cases.latentElasticActualProducer = await elastic(messages, 'reject-invalid', true);
    assert.deepEqual(evidence.cases.latentElasticActualProducer.acknowledgments, []); assert.equal(evidence.cases.latentElasticActualProducer.requeues.length, 2);
    assert.ok(evidence.cases.latentElasticActualProducer.requests[0].operations.every((op, index) => index % 2 || Object.hasOwn(op, 'update')));
    evidence.cases.latentElasticUntrustworthySuccess = await elastic(messages, 'fabricated-item-success', true);
    assert.deepEqual(evidence.cases.latentElasticUntrustworthySuccess.acknowledgments, []); assert.equal(evidence.cases.latentElasticUntrustworthySuccess.requeues.length, 2);
    const explicitBodyControls = messages.map((message, index) => capture(Buffer.from(JSON.stringify({...JSON.parse(message.content), id: 'explicit-control-id', present: index ? 0 : 1})), message.properties.headers, index + 1));
    evidence.cases.latentElasticExplicitBodyControl = await elastic(explicitBodyControls, 'valid-explicit-control', true);
    assert.deepEqual(evidence.cases.latentElasticExplicitBodyControl.acknowledgments, [1, 2]); assert.equal(evidence.cases.latentElasticExplicitBodyControl.indexed, 1);
    const duplicateControls = explicitBodyControls.map((message, index) => capture(Buffer.from(JSON.stringify({...JSON.parse(message.content), present: 1})), {...message.properties.headers, table: index ? 'beta' : 'alpha'}, index + 1));
    evidence.cases.latentElasticDuplicateIdControl = await elastic(duplicateControls, 'valid-explicit-control', true);
    assert.deepEqual(evidence.cases.latentElasticDuplicateIdControl.acknowledgments, [1, 2]); assert.equal(evidence.cases.latentElasticDuplicateIdControl.indexed, 2);

    async function mongo(publications) {
        const writes = [], stored = new Map(); let prepareCalls = 0;
        const routes = new MongoRoutes({chain, prepareMongoClient() {prepareCalls++;}, conn: {mongodb: {database_prefix: 'owned'}},
            mongodbClient: {db: () => ({collection: collection => ({async bulkWrite(operations, options) {writes.push({collection, operations: clone(operations), options: clone(options)});
                assert.equal(options.ordered, true); const rows = stored.get(collection) ?? new Map(); stored.set(collection, rows);
                for (const operation of operations) {const value = operation.updateOne ?? operation.deleteOne, key = JSON.stringify(value.filter);
                    if (operation.updateOne) rows.set(key, {...rows.get(key), ...clone(value.update.$set)}); else rows.delete(key);}
                return {acknowledged: true};}})})}});
        const messages = publications.map((publication, index) => capture(publication.content, publication.headers, index + 1)), channel = new Channel(messages);
        const indexed = await indexMongoBatch(messages, routes.routes['dynamic-table'], channel, () => true, reason => {throw reason;}, async () => {throw new Error('Unexpected retry');});
        return {simulatedDatabaseEffects: true, routeRegistered: typeof routes.routes['dynamic-table'] === 'function', prepareCalls, writes, indexed,
            acknowledgments: channel.acknowledgments, requeues: channel.requeues,
            finalRows: Object.fromEntries([...stored].map(([collection, rows]) => [collection, [...rows.values()]]))};
    }
    const selectedRows = [row(1), row(1, 'alpha', 'alice', 2), row(1, 'beta', 'alice', 3), row(1, 'alpha', 'bob', 4), row(0, 'alpha', 'alice', 5)];
    evidence.cases.activeMongo = await mongo(await produce(configured(true), selectedRows));
    assert.deepEqual(evidence.cases.activeMongo.acknowledgments, [1, 2, 3, 4, 5]);
    assert.equal(evidence.cases.activeMongo.finalRows['contracta-alpha'].length, 1); assert.equal(evidence.cases.activeMongo.finalRows['contracta-alpha'][0]['@scope'], 'bob');
    assert.equal(evidence.cases.activeMongo.finalRows['contracta-beta'].length, 1);
    evidence.cases.disabledStillReachesActiveMongo = await mongo(disabled); assert.equal(evidence.cases.disabledStillReachesActiveMongo.writes.length, 1);
    const secondary = ['01', '02'].map((primarySuffix, index) => ({...row(1, 'users', '', index + 1), code: 'wiresec', data: {},
        primary_key: 'constructed-key-' + index, protocol: {id: '@eosrio/hyperion-wire-plugin', source: {chainId},
            logicalIdentity: `wire-kv-v1:index:${chainId}:9:37799:aa:${primarySuffix}`, metadata: {recordKind: 'index'}}}));
    evidence.cases.constructedSecondaryMongo = await mongo(await produce(configured(true), secondary));
    const secondaryFilters = evidence.cases.constructedSecondaryMongo.writes[0].operations.map(operation => operation.updateOne.filter);
    assert.equal(secondaryFilters.length, 2); assert.notDeepEqual(secondaryFilters[0], secondaryFilters[1]);
    evidence.cases.constructedSecondaryMongo.sourceCaptured = false;
    evidence.networkAttempts = networkAttempts; assert.equal(networkAttempts.length, 0);
    for (const item of provenance) assert.equal(hash(readFileSync(join(repo, item.path))), item.sha256, 'production artifact drift');
    evidence.status = 'reproduced'; evidence.findings = {activeMongoUsesHeadersPresentAndCollectionIdentity: true, disabledOperatorConfiguredProducerEnqueues: true,
        elasticDynamicRouteOperational: false, latentElasticHelperMissingIdAndBodyPresence: true, duplicateIdsSettledByPositionInControl: true};
    writeFileSync(output, JSON.stringify(evidence, (_key, value) => value === undefined ? {$undefined: true} : value, 2) + '\n', {flag: 'wx'});
    console.log(JSON.stringify({status: evidence.status, output, sha256: hash(readFileSync(output)), findings: evidence.findings, networkAttempts: networkAttempts.length}));
} finally {
    clearTimeout(watchdog);
    Socket.prototype.connect = originalConnect; process.chdir(originalCwd);
    for (const [key, value] of Object.entries(oldEnv)) {if (value === undefined) delete process.env[key]; else process.env[key] = value;}
    // Only the exact marked, ordinary mkdtemp child of the resolved temp directory may be removed.
    assert.equal(dirname(taskTemporary), taskTemporaryBase); assert.ok(basename(taskTemporary).startsWith('hyperion-dynamic-probe-'));
    assert.equal(realpathSync(taskTemporary), taskTemporary); assert.ok(!lstatSync(taskTemporary).isSymbolicLink());
    assert.equal(readFileSync(join(taskTemporary, '.owner'), 'utf8'), marker); rmSync(taskTemporary, {recursive: true});
}
