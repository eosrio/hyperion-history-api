Independent Standards review: Wire state opt-in and legacy Mongo effects

Fixed range: 5043829d633c397f493e107e1766c9eb19cacbd1...b8777b754ea0bd35c3119d78965c0df037190a0f.
Both refs resolve. The nonempty range contains one commit, b8777b7 (13 files; 572 additions, 70 removals).

Documented-standard breaches: none found.
Heuristic baseline smells: none actionable. Tooling-enforced trivia excluded.

Reviewed against HAPI AGENTS.md and docs/development-build.md; Tools AGENTS.md, architecture definition, component profiling program, and ADRs 0021/0023/0024/0034/0040.

Basis:
- src/indexer/workers/deserializer.ts:1684-1693 retains the absent-feature guard and makes operator authorization explicit: "contractState.enabled === true && contractState.contracts?.[jsonRow.code]?.[jsonRow.table]". The separate "this.allowedDynamicContracts.has(jsonRow.code)" preserves existing plugin dependency authorization. Authorized publication body, headers and queue rotation remain unchanged.
- The qualification continues through the existing worker/RabbitMQ/Mongo route. It introduces no portable-hook native-write bypass, replacement worker topology, history deletion or reindex requirement.
- scripts/qualification/wire-worker-replay.ts:305-314 refuses preexisting state collections on the ownership-checked fixture and records actual Mongo version. Lines 341-367 hold original source prefixes, require expected block identity and drained queues, and retain raw database observations plus their hashes.
- scripts/qualification/wire-state-outputs.ts:67-95 compares complete selected collection contents, rejects duplicate physical identities, bounds reads to 1,001 rows/five seconds and refuses truncation; the acceptance bound is 1,000 rows.
- docs/performance/wire-worker-replay.md:100-120 explicitly distinguishes enabled/disabled legacy Mongo effects from complete initial state, canonical rollback, checkpoint/restart, portable-runtime integration and HTTP readiness. The existing release gates are not weakened or marked complete.

This is a static Standards-axis review, not live acceptance. No tests/services were started, and no candidate code was edited. The root-reported two-line positive-fixture enabled:true follow-up is outside this fixed range; root owns its validation and the repeated full suite.
