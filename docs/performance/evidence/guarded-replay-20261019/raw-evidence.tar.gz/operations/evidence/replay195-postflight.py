import pathlib,json,urllib.request,base64,time,datetime,hashlib
root=pathlib.Path('/var/snap/docker/common/hyperion-qualification/run-20261019-195-208')
state_path=root/'fixture195g.json'; state=json.loads(state_path.read_text())
out=root/'replay195-final'; report=json.loads((out/'report.json').read_text())
assert report['status']=='passed', report.get('error')
assert report['fixtureRun']==state['run']
assert report['sourceCommit']=='4448aa090e60a71ae30c2739591ad0b4b8a6085f'
assert report['masterExit']=={'code':0,'signal':None}
assert all(row.get('ok',False) for row in report['cleanup'])
for file,expected in report['sourceHashes'].items():
    assert hashlib.sha256((out/'sources'/file).read_bytes()).hexdigest()==expected,file
manifest=json.loads((out/'fixture/manifest.json').read_text())
for item in manifest['inputs']:
    data=(out/'fixture'/item['file']).read_bytes()
    assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],item['file']
assert len(report['finalActions'])==len(report['fixture']['actions'])==12
assert len(report['finalBlocks'])==report['fixture']['replayBlocks']
assert len(report['finalAbiHistory'])==2 and len(report['durableCopies'])==4
assert report['rpcFallbackAttempts']==[] and report['replayErrors']==[]
rows=[json.loads(line) for file in (out/'observer').glob('*.jsonl') for line in file.read_text().splitlines() if line.strip()]
pids={row['pid'] for row in rows if row.get('kind')=='start'}
assert report['masterPid'] in pids and len(pids)>5
auth='Basic '+base64.b64encode(b'qualifier:qualifier-test-only').decode()
def get(url,broker=False):
    req=urllib.request.Request(url,headers={'Authorization':auth} if broker else {})
    with urllib.request.urlopen(req,timeout=10) as response:return json.load(response)
samples=[]
for number in range(3):
    alive=[pid for pid in sorted(pids) if pathlib.Path('/proc',str(pid)).exists()]
    queues=get(state['core']['broker']['managementUrl']+'/api/queues/%2F',True)
    assert all(q['name'].startswith(report['chain']+':') for q in queues)
    messages=sum(q['messages'] for q in queues);unacked=sum(q['messages_unacknowledged'] for q in queues)
    consumers=sum(q['consumers'] for q in queues)
    connections=get(state['core']['broker']['managementUrl']+'/api/connections',True)
    tasks=get(state['core']['nodes'][0]['url']+'/_tasks?detailed=true')
    work=[task for node in tasks['nodes'].values() for task in node.get('tasks',{}).values() if any(term in task.get('action','') for term in ['indices:data/write','indices:data/read/search'])]
    assert not alive and not messages and not unacked and not consumers and not connections and not work,(alive,messages,unacked,consumers,connections,work)
    samples.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observedPidsAlive':alive,'brokerQueues':len(queues),'brokerMessages':messages,'brokerUnacked':unacked,'brokerConsumers':consumers,'brokerConnections':len(connections),'activeSearchWrites':len(work)})
    if number<2:time.sleep(1)
result={'status':'passed','run':state['run'],'sourceCommit':report['sourceCommit'],'fixtureManifestSha256':hashlib.sha256(state_path.read_bytes()).hexdigest(),'verifiedSourceSnapshots':len(report['sourceHashes']),'verifiedFixtureInputs':len(manifest['inputs']),'observedPids':sorted(pids),'consecutiveIdleSamples':3,'samples':samples,'logicalActions':12,'replayedBlocks':len(report['finalBlocks']),'durableCopyObservations':4,'lastIndexedRedis':report.get('lastIndexedRedis'),'scope':'Independent byte verification and owned process/broker/ES-idle postflight before exact fixture cleanup; no master/host/power-loss qualification.'}
(root/'evidence/replay195-postflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
