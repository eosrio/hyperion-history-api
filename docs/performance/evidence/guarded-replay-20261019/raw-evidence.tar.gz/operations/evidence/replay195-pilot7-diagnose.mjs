import fs from 'node:fs/promises';
import {Client} from '/var/snap/docker/common/hyperion-qualification/run-20261019-195-208/replay-final/node_modules/@elastic/elasticsearch/index.js';
import {auditFixture} from '/var/snap/docker/common/hyperion-qualification/run-20261019-195-208/replay-final/scripts/qualification/contract-fixture.ts';
import {assertBlockOutputs,assertActionOutputs} from '/var/snap/docker/common/hyperion-qualification/run-20261019-195-208/replay-final/scripts/qualification/contract-replay.ts';
const root='/var/snap/docker/common/hyperion-qualification/run-20261019-195-208';
const s=JSON.parse(await fs.readFile(root+'/fixture195d.json'));
const fixture=await auditFixture(root+'/replay195-final/fixture');
const client=new Client({node:s.core.nodes[0].url,maxRetries:0});
const chain='hyp-replay-'+s.run;
const result={};
for(const [kind,field,expected,check] of [
 ['block','block_num',fixture.records.filter(x=>x.blockNum>=fixture.replayStart),assertBlockOutputs],
 ['action','global_sequence',fixture.actions,assertActionOutputs]]) {
 const response=await client.search({index:chain+'-'+kind+'-*',size:10000,sort:[{[field]:'asc'}],track_total_hits:true});
 const hits=response.hits.hits;
 try {check(hits,expected);result[kind]={passed:true,count:hits.length};}
 catch(error){result[kind]={passed:false,count:hits.length,error:String(error),stack:error.stack,firstHit:hits[0],lastHit:hits.at(-1),firstExpected:expected[0],lastExpected:expected.at(-1)};}
}
await client.close();
await fs.writeFile(root+'/evidence/replay195-pilot7-output-diagnosis.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
