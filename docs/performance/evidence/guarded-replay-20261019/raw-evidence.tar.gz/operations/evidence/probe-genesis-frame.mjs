import {createRequire} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
const root='/var/snap/docker/common/hyperion-qualification/run-20261019-195-208';
const require=createRequire(join(root,'replay/package.json'));
const {WebSocket}=require('ws'); const {ABI,Serializer}=require('@wharfkit/antelope');
const state=JSON.parse(readFileSync(join(root,'fixture195.json')));
const socket=new WebSocket(state.spring.shipUrl);let abi;let status=false;
const deadline=setTimeout(()=>{socket.terminate();process.exitCode=1;},10000);
socket.on('error',error=>{console.error(error);process.exitCode=1;clearTimeout(deadline);});
socket.on('message',(data,isBinary)=>{
 try {
  if(!isBinary){writeFileSync(join(root,'evidence/probe-genesis-protocol.json'),data);abi=ABI.from(JSON.parse(data));socket.send(Serializer.encode({object:['get_status_request_v0',{}],type:'request',abi}).array);return;}
  const result=Serializer.objectify(Serializer.decode({data:new Uint8Array(data),type:'result',abi}));
  if(!status){status=true;socket.send(Serializer.encode({object:['get_blocks_request_v0',{start_block_num:1,end_block_num:2,max_messages_in_flight:1,have_positions:[],irreversible_only:true,fetch_block:true,fetch_traces:true,fetch_deltas:true}],type:'request',abi}).array);return;}
  writeFileSync(join(root,'evidence/probe-genesis-frame.bin'),data);
  const row={variant:result[0],this_block:result[1].this_block,prev_block:result[1].prev_block,head:result[1].head,last_irreversible:result[1].last_irreversible,blockBytes:String(result[1].block).length/2};
  writeFileSync(join(root,'evidence/probe-genesis-frame.json'),JSON.stringify(row,null,2)+'\n');console.log(JSON.stringify(row));clearTimeout(deadline);socket.close();
 }catch(error){console.error(error);clearTimeout(deadline);socket.terminate();process.exitCode=1;}
});
