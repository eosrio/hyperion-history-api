"""Freeze completed #195 evidence. No remote calls or fixture mutations.

Inputs JSON points to bounded, downloaded regular files under --scratch. This
script reuses the already audited regular-file archive writer, archives itself
and that writer, and rejects incomplete acceptance and missing cleanup receipts.
"""
import argparse, json, pathlib, runpy, os, uuid
from urllib.parse import unquote
from collections import Counter
from datetime import datetime, timezone

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', required=True)
    parser.add_argument('--scratch', required=True)
    parser.add_argument('--inputs', required=True)
    parser.add_argument('--destination', required=True)
    args = parser.parse_args()
    repo = pathlib.Path(args.repo).resolve(); scratch = pathlib.Path(args.scratch).resolve()
    helpers = scratch/'es198-workers-package.py'
    h = runpy.run_path(str(helpers)); require = h['require']; read = h['read_json']; sha = h['file_sha']; enc = h['encoded']
    cfg = read(pathlib.Path(args.inputs)); raw = pathlib.Path(cfg['rawRoot']).resolve()
    require(raw.is_relative_to(scratch) and raw != scratch, 'Raw evidence root escapes scratch')
    run = raw/'replay195-final'; report = read(run/'report.json')
    require(report['status'] == 'passed', 'Final finite run did not pass')
    require(report['sourceCommit'] == cfg['sourceCommit'], 'Wrong measured source commit')
    require(report['runtime']['node'] == 'v24.19.0' and report['runtime']['platform'] == 'linux' and report['runtime']['arch'] == 'x64', 'Unexpected measured runtime')
    require(report['server']['version']['number'] == '9.5.5', 'Wrong Elasticsearch server')
    require(report['masterExit'] == {'code':0,'signal':None}, 'Master OS exit failed')
    require(report['config']['settings']['auto_stop'] == 300, 'Finite run lacks bounded auto-stop')
    require(not report['replayErrors'] and not report['rpcFallbackAttempts'], 'Replay or current ABI fallback errors')
    require(report['cleanup'] and all(item.get('ok') is True for item in report['cleanup']), 'Qualifier cleanup failed')
    state = read(raw/cfg['state']); post = read(raw/cfg['postflight']); cleanup = read(raw/cfg['cleanup'])
    require(state['run'] == post['run'] == cleanup['run'] == report['fixtureRun'], 'Receipt run identities differ')
    require(sha(raw/cfg['state']) == report['stateSha256'], 'State bytes differ from measured manifest')
    require(post['status'] == 'passed', 'Independent postflight failed')
    require(post['sourceCommit'] == cfg['sourceCommit'] and post['fixtureManifestSha256'] == sha(raw/cfg['state']), 'Postflight checked different source/fixture')
    require(post['consecutiveIdleSamples'] >= 3 and len(post['samples']) >= 3, 'Independent idle/process coverage missing')
    for sample in post['samples']:
        require(not sample['observedPidsAlive'] and all(sample[key] == 0 for key in ['brokerMessages','brokerUnacked','brokerConsumers','brokerConnections','activeSearchWrites']), 'Postflight did not establish idle owned processes/services')
    core = cleanup['coreCleanup']
    require(len(cleanup['extraContainers']) == len(cleanup['extraVolumes']) == 3, 'Extra fixture cleanup incomplete')
    require(len(core['containers']) == len(core['volumes']) == 4 and core['network'] == state['network'], 'Core fixture cleanup incomplete')
    require(all(core[k] == 0 for k in ['remainingContainers','remainingVolumes','remainingNetworks']), 'Owned fixture resources remain')
    fixture_dir = run/'fixture'; fixture = read(fixture_dir/'manifest.json')
    require(fixture['complete'] is True and fixture['origin'] == 'known-genesis', 'Incomplete/unsupported capture')
    require(sha(fixture_dir/'manifest.json') == report['fixture']['manifestSha256'], 'Fixture manifest identity differs')
    for item in fixture['inputs']:
        part = pathlib.PurePosixPath(item['file']); require(not part.is_absolute() and '..' not in part.parts and '\\' not in item['file'], 'Unsafe capture member')
        p = fixture_dir/pathlib.Path(*part.parts)
        require(p.stat().st_size == item['bytes'] and sha(p) == item['sha256'], 'Capture input bytes/digest differ')
    require(len(fixture['expected']) == len(report['fixture']['actions']) == len(report['finalActions']) == 12, 'Action coverage differs')
    require(len(fixture['abiHistory']) == len(report['finalAbiHistory']) == 2, 'ABI coverage differs')
    start = report['fixture']['replayRange']['start']; end = report['fixture']['replayRange']['end']
    require(start in [1,2] and end == fixture['range']['end'] and len(report['finalBlocks']) == end-start+1 == report['fixture']['replayBlocks'], 'Replay range differs')
    for n, hit in enumerate(report['finalBlocks'], start):
        require(hit['_id'] == str(n) and hit['_source']['block_num'] == n, 'Block identity/order differs')
        if n > start: require(hit['_source']['prev_id'] == report['finalBlocks'][n-start-1]['_source']['block_id'], 'Output block link differs')
    for hit, expected, audited in zip(report['finalActions'],fixture['expected'],report['fixture']['actions']):
        actual = hit['_source']; require(hit['_id'] == str(audited['globalSequence']), 'Action sequence identity differs')
        require(actual['global_sequence'] == audited['globalSequence'] and actual['trx_id'] == expected['trxId'] == audited['trxId'], 'Action transaction differs')
        require(actual['block_num'] == expected['block'] == audited['block'] and actual['block_id'] == audited['blockId'], 'Action block differs')
        require('ds_error' not in actual and actual['act']['account'] == 'hyp.replay' and actual['act']['name'] == 'record', 'Action decode/domain differs')
        data = dict(actual['act']['data']); data['sequence'] = int(data['sequence'])
        require(data == expected['data'] == audited['data'] and actual['act']['authorization'] == [{'actor':'hyp.replay','permission':'active'}], 'Action output differs')
    for actual, expected in zip(report['finalAbiHistory'],fixture['abiHistory']):
        value = actual['_source']; require(value['account'] == expected['account'] and value['block'] == expected['block'], 'ABI identity differs')
        require(bytes.fromhex(value['abi_hex']) == bytes.fromhex(expected['abiHex']), 'ABI bytes differ')
    require(len(report['durableCopies']) == 4 and len({row['node'] for row in report['durableCopies']}) == 2, 'Physical-copy evidence incomplete')
    for key,name in [('blocks','finalBlocks'),('actions','finalActions')]:
        encoded_outputs=json.dumps(report[name],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
        require(h['sha'](encoded_outputs)==report['outputSha256'][key], 'Recomputed logical output digest differs')
    for row in report['durableCopies']:
        key = 'blocks' if '-block-' in row['index'] else 'actions'
        require(row['sha256'] == report['outputSha256'][key] and row['count'] == len(report['finalBlocks' if key=='blocks' else 'finalActions']), 'Physical-copy output differs')
    for value in report['indexSettings'].values():
        require(value['settings']['index']['number_of_replicas'] == '1', 'Wrong replica setting')
        durability = value['settings']['index'].get('translog',{}).get('durability',value['defaults']['index']['translog']['durability'])
        require(isinstance(durability,str) and durability.lower() == 'request', 'Wrong translog durability')
    require(report['finalQueues'] and all(all(row[k] == 0 for k in ['ready','unacked','messages']) for row in report['finalQueues']), 'Queue drain failed')
    rows = h['observer_rows'](run); starts = [row for row in rows if row['kind']=='start']; forks = [row for row in rows if row['kind']=='worker_fork']
    require(len({row['pid'] for row in starts}) == len(starts) >= 10 and len(forks) == len(starts)-1, 'Incomplete/duplicate process inventory')
    require(not any(row['kind']=='observer_error' for row in rows), 'Observer errors')
    shutdown = next(row for row in rows if row['kind']=='shutdown' and row['pid']==report['masterPid'])
    require(shutdown['success'] and all(shutdown[k] == [] for k in ['forced','unresolved','failedChildren']), 'Shutdown rejected')
    require(len(shutdown['childExits']) == len(forks), 'Missing child exit evidence')
    for start_row in starts:
        pid = start_row['pid']; exits = [row for row in rows if row['kind']=='exit' and row['pid']==pid]
        flushes = [row for row in rows if row['kind']=='flush' and row['pid']==pid]
        require(len(exits)==1 and exits[0]['code']==0 and flushes, 'Observed process did not exit/flush')
        require(flushes[-1]['success'] and flushes[-1]['droppedRecords']==0 and flushes[-1]['profileState']=='disabled', 'Observer evidence incomplete')
    require(sorted(post['observedPids']) == sorted(row['pid'] for row in starts), 'Postflight process inventory differs')
    confirms = sorted(row['message']['block_num'] for row in rows if row['kind']=='ipc_send' and row.get('event')=='read_block' and row['role']=='reader')
    require(confirms == list(range(start,end+1)), 'Reader confirm coverage differs')
    require(len(report['readerCompletion']) == 1, 'Reader completion missing')
    successful = failed = repeated = retries = 0; prior = {}; copies = Counter()
    for receipt in report['bulkReceipts']:
        for key in ['request','responseBody']:
            item=receipt[key]; p=run/'bulk'/item['file']; require(p.parent==run/'bulk' and p.stat().st_size==item['bytes'] and sha(p)==item['sha256'], 'Raw bulk bytes differ')
        lines=(run/'bulk'/receipt['request']['file']).read_text().rstrip().splitlines(); offset=0; actual_operations=[]
        while offset<len(lines):
            metadata=json.loads(lines[offset]); offset+=1; require(len(metadata)==1,'Invalid raw bulk metadata')
            kind=next(iter(metadata)); require(kind in ['index','create','update','delete'],'Unsupported raw bulk operation')
            entry=metadata[kind]; default_index=unquote(receipt['path'].split('?')[0].strip('/').split('/')[0])
            actual_operations.append({'operation':kind,'index':entry.get('_index',default_index),'id':str(entry['_id'])})
            if kind!='delete': require(offset<len(lines),'Missing raw bulk source'); json.loads(lines[offset]); offset+=1
        require(actual_operations==receipt['operations'],'Raw bulk operation ledger differs')
        response=read(run/'bulk'/receipt['responseBody']['file']); require(response==receipt['response'], 'Raw bulk response differs')
        require(receipt['responseReceivedAt']>=receipt['startedAt'], 'Invalid bulk timing')
        okay=200<=receipt['status']<300
        if okay: require(len(response['items'])==len(receipt['operations']), 'Bulk response coverage differs')
        response_failed=False
        for i,op in enumerate(receipt['operations']):
            item=response['items'][i][op['operation']] if okay else None
            if okay: require(str(item['_id'])==op['id'] and item['_index']==op['index'], 'Bulk item identity differs')
            success=okay and 200<=item['status']<300 and not item.get('error'); response_failed |= not success
            key=(op['index'],op['id'],op['operation']); old=prior.get(key)
            repeated += old is not None; retries += old is not None and not old[0] and receipt['startedAt']>=old[1]
            prior[key]=(success,receipt['responseReceivedAt']); successful+=success; failed+=not success
            if success and item.get('_shards'):
                require(item['_shards']['failed']==0, 'Bulk shard failure'); copies[str(item['_shards']['successful'])]+=1
        if okay: require(response['errors']==response_failed, 'Bulk error summary differs')
    accounting=report['bulkAccounting']
    require({key:accounting[key] for key in ['requests','successfulItems','failedItems','repeatedAttempts','attemptsAfterObservedFailure','acknowledgedCopies']} ==
        {'requests':len(report['bulkReceipts']),'successfulItems':successful,'failedItems':failed,'repeatedAttempts':repeated,'attemptsAfterObservedFailure':retries,'acknowledgedCopies':dict(copies)}, 'Recomputed bulk accounting differs')
    audit_path=scratch/'h45-195-existing-replay-audit-20261019.json'; audit=read(audit_path)
    require(sha(audit_path)=='9f47d38c992d55a503c36e7f01453299daea58336b2d30ee3dae642a839031a6' and len(audit['files'])==13 and all(row['unchanged'] and row['sha256_before']==row['sha256_after'] for row in audit['files']), 'Legacy read-only audit changed')
    archive=h['Archive'](repo,scratch); archive.tree('run/final',run,'Accepted finite contract replay; source snapshots are exact measured bytes',status='passed',run=state['run'])
    source_hashes=h['verify_sources'](archive,report,'run/final',run)
    require(post['verifiedSourceSnapshots']==len(source_hashes) and post['verifiedFixtureInputs']==len(fixture['inputs']), 'Postflight byte-verification coverage differs')
    excluded=[]
    for number in cfg['excludedPilots']:
        path=raw/f'replay195-case{number}'; pilot=read(path/'report.json'); require(pilot['status']=='failed','Excluded pilot unexpectedly passed')
        archive.tree(f'pilots/excluded/case{number}',path,'Failed preparation/pilot; excluded from final acceptance and all throughput totals',status='excluded-failed',run=pilot['fixtureRun'])
        excluded.append({'pilot':number,'sourceCommit':pilot['sourceCommit'],'reportSha256':sha(path/'report.json'),'fixtureRun':pilot['fixtureRun'],'error':pilot.get('error'),'capturedBlocks':pilot.get('fixture',{}).get('blocks')})
    for path in sorted(raw.iterdir()):
        if path.is_file(): archive.add('operations/'+path.name,path=path,role='Fixture ownership/configuration and cleanup receipts')
    archive.tree('operations/evidence',raw/'evidence','Preparation, native imports, checks, independent postflight, failed-pilot diagnostics and exact cleanup logs')
    archive.add('audit/existing-replay-audit.json',path=audit_path,role='Immutable read-only audit of 13 pre-existing helper sources')
    for path in [pathlib.Path(__file__),helpers,pathlib.Path(args.inputs)]: archive.add('packaging/'+path.name,path=path,role='Reproducible evidence packager/input declaration; not measured runtime')
    for value in cfg.get('supportingFiles',[]):
        path=pathlib.Path(value); archive.add('validation/'+path.name,path=path,role='Local validation or red/green regression; separate from measured run')
    limits=report['limits']+[
        'Qualifier shutdown bypasses production gracefulStop checkpoint persistence; a null Redis cursor is not synthesized. #195 remains open for persisted checkpoint and restart acceptance.',
        'No throughput, CPU profile, automatic ABI discovery, historical mainnet, fork recovery, contract computation, state projection or host power-loss durability claim.',
        'Failed pilots are excluded. Their report source hash metadata is retained; final measured source/build/native binary snapshots are archived in full.',
        'Known public genesis key and isolated fixture test credentials are retained as raw evidence; no production credentials are included.']
    summary={'schemaVersion':1,'status':'passed-finite-output','issue':'https://github.com/eosrio/hyperion-history-api/issues/195','sourceCommit':cfg['sourceCommit'],
        'fixtureRun':state['run'],'startedAt':report['startedAt'],'completedAt':report['completedAt'],'runtime':report['runtime'],
        'capturedBlocks':fixture['blocks'],'workerReplayRange':{'start':start,'end':end},'replayedBlocks':len(report['finalBlocks']),
        'actions':12,'abiDeployments':2,'exactPhysicalCopies':report['durableCopies'],'bulkAccounting':accounting,
        'observedProcesses':len(starts),'readerConfirmedBlocks':len(confirms),'masterOsExit':report['masterExit'],
        'lastIndexedRedis':report.get('lastIndexedRedis'),'persistedRestartAcceptance':'open-not-established',
        'postflight':{'status':post['status'],'consecutiveIdleSamples':post['consecutiveIdleSamples'],'observedPidsAlive':[]},
        'fixtureCleanup':{'containers':7,'volumes':7,'networks':1,'remaining':0},'excludedPilots':excluded,'limits':limits}
    archive.add('README.json',data=enc({'scope':summary['status'],'sourceCommit':cfg['sourceCommit'],'limits':limits}),role='Archive interpretation and boundaries')
    candidate=scratch/('h45-195-candidate-'+uuid.uuid4().hex+'.tar.gz'); archive.write_and_verify(candidate)
    dest=pathlib.Path(args.destination).resolve(); require(dest.is_relative_to(repo/'docs/performance/evidence') and not dest.exists(),'Unsafe/existing destination'); dest.mkdir()
    manifest={'schemaVersion':1,'createdAt':datetime.now(timezone.utc).isoformat(),'archive':'raw-evidence.tar.gz','archiveSha256':sha(candidate),
        'sourceCommit':cfg['sourceCommit'],'sourceHashes':source_hashes,'memberCount':len(archive.members),'members':[archive.members[key][0] for key in sorted(archive.members)],
        'sourceProvenance':'Final source/build/native snapshots are byte-exact and hash-checked. Failed pilots, local validation and packaging support are labeled separately.'}
    files={'raw-evidence.tar.gz':candidate.read_bytes(),'summary.json':enc(summary),'manifest.json':enc(manifest),
        '.gitattributes':b'raw-evidence.tar.gz binary\nsummary.json -text\nmanifest.json -text\nSHA256SUMS -text\n.gitattributes -text\n'}
    for name,data in files.items():
        with (dest/name).open('xb') as output: output.write(data); output.flush(); os.fsync(output.fileno())
    checks=''.join(sha(dest/name)+'  '+name+'\n' for name in files).encode()
    with (dest/'SHA256SUMS').open('xb') as output: output.write(checks); output.flush(); os.fsync(output.fileno())
    for line in checks.decode().splitlines():
        expected,name=line.split('  '); require(sha(dest/name)==expected,'Final checksum readback failed')
    print(json.dumps({'status':'packaged','destination':str(dest),'archiveSha256':manifest['archiveSha256'],'members':len(archive.members),'rawBytes':archive.total,'summary':summary}))

if __name__=='__main__': main()
