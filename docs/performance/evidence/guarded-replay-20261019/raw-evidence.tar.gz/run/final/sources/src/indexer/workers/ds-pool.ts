import { cargo, queue } from "async";
import { ConsumeMessage, Message } from "amqplib";
import { join, resolve } from "path";
import { existsSync, readdirSync, readFileSync } from "fs";
import { Redis, RedisValue } from "ioredis";

import { debugLog, hLog } from "../helpers/common_functions.js";
import { RabbitQueueDef } from "../definitions/index-queues.js";
import { ActionTrace } from "../../interfaces/action-trace.js";
import { HyperionWorker } from "./hyperionWorker.js";
import { HyperionActionAct } from "../../interfaces/hyperion-action.js";
import { ABI, Action, Serializer } from "@wharfkit/antelope";
import { HyperionAbi } from "../../interfaces/hyperion-abi.js";
import { groupActionTraces } from "../helpers/action-dedup.js";

interface CustomAbiDef {
    abi: string;
    startingBlock: number;
    endingBlock: number;
}

function cleanActionTrace(t: any) {
    try {
        if (t.return_value === '') {
            delete t.return_value;
        }
        if (t.context_free === false) {
            delete t.context_free;
        }
        if (t.elapsed === '0') {
            delete t.elapsed;
        }

        // remove act_digest from grouped receipts since it was written to the action
        if (t.receipts && t.receipts.length > 0) {
            t.act_digest = t.receipts[0].act_digest;
            for (let receipt of t.receipts) {
                delete receipt.act_digest;
            }
        } else {
            delete t.receipts;
        }

        delete t.receiver;

        // onblock action case
        if (t.signatures && t.signatures.length === 0) {
            delete t.signatures;
        }

        if (t.inline_count === 0) {
            delete t.inline_count;
        }

        if (t.net_usage_words === 0) {
            delete t.net_usage_words;
        }
    } catch (e) {
        console.log(e);
    }
}

export default class DSPoolWorker extends HyperionWorker {


    shipABI: ABI | undefined;

    types;
    tables: Map<string, string> = new Map();
    local_queue;
    consumerQueue;
    preIndexingQueue;
    temp_ds_counter = 0;
    act_emit_idx = 1;
    allowStreaming = false;
    // common functions
    common;
    totalHits = 0;
    // contract usage map (temporary)
    contractUsage = {};
    contracts: Map<string, {
        contract: ABI;
        valid_until: number;
        valid_from: number;
    }> = new Map();
    monitoringLoop?: NodeJS.Timeout;
    actionDsCounter = 0;

    customAbiMap: Map<string, CustomAbiDef[]> = new Map();
    private noActionCounter = 0;

    // tx caching layer
    private readonly ioRedisClient: Redis;
    txCacheExpiration = 3600;

    constructor() {
        super();

        this.ioRedisClient = new Redis(this.manager.conn.redis);
        if (this.conf.api.tx_cache_expiration_sec) {
            if (typeof this.conf.api.tx_cache_expiration_sec === 'string') {
                this.txCacheExpiration = parseInt(this.conf.api.tx_cache_expiration_sec, 10);
            } else {
                this.txCacheExpiration = this.conf.api.tx_cache_expiration_sec;
            }
        }

        this.consumerQueue = cargo((payload: ConsumeMessage[], cb) => {
            // hLog(`Processing ${payload.length} messages`);
            this.processMessages(payload).catch((err) => {
                hLog('NackAll:', err);
                if (this.ch && this.ch_ready) {
                    try {
                        this.ch.nackAll();
                    } catch (e: any) {
                        hLog(e.message);
                    }
                }
            }).finally(() => {
                cb();
            });
        }, this.conf.prefetch.block);

        this.preIndexingQueue = queue((data: any, cb) => {
            if (this.ch_ready && this.ch) {
                try {
                    this.ch.sendToQueue(data.queue, data.content, { headers: data.headers });
                } catch (e: any) {
                    hLog(e.message);
                }
                cb();
            } else {
                hLog('Channel is not ready!');
            }
        }, 1);

        this.processCustomABI();

        // Define Common Functions
        this.common = {
            attachActionExtras: this.attachActionExtras,
            deserializeActionAtBlockNative: this.deserializeActionAtBlockNative
        }
    }

    processCustomABI() {
        if (this.conf.settings.allow_custom_abi) {

            if (!this.customAbiMap) {
                this.customAbiMap = new Map<string, CustomAbiDef[]>();
            }

            const dir = join(resolve(), "custom-abi", this.chain);
            if (existsSync(dir)) {
                const files = readdirSync(dir);
                for (const abiFile of files) {
                    try {
                        const [code, startingBlock, suffix] = abiFile.split("-");
                        const endingBlock = suffix.split(".")[0];
                        hLog(`Custom ABI for ${code} from ${startingBlock} up to ${endingBlock}`);
                        const parsedAbi = readFileSync(join(dir, abiFile)).toString();
                        const def: CustomAbiDef = {
                            abi: parsedAbi,
                            startingBlock: parseInt(startingBlock),
                            endingBlock: parseInt(endingBlock)
                        };

                        if (!this.customAbiMap.has(code)) {
                            this.customAbiMap.set(code, [def]);
                        } else {
                            this.customAbiMap.get(code)?.push(def);
                        }

                    } catch (e: any) {
                        hLog(e.message);
                    }
                }
            }
        }
    }

    attachActionExtras(self: DSPoolWorker, action: ActionTrace) {
        self.mLoader.processActionData(action);
    }

    recordContractUsage(code: string) {
        // console.log(this.totalHits, this.actionDsCounter, this.monitoringLoop);
        this.totalHits++;
        if (this.contractUsage[code]) {
            this.contractUsage[code]++;
        } else {
            this.contractUsage[code] = 1;
        }
    }

    /** Per-cargo ABI-lookup memo (cleared each batch in processMessages). At
     *  mainnet density the same (contract, block) ABI is fetched once per action
     *  of that contract; the ES result is deterministic, so caching it per batch
     *  is format-safe. */
    private poolAbiCache = new Map<string, any>();
    /** Per-cargo type-resolution memo, keyed (field|contract|type|block). Skips
     *  repeated getAbiDataType native calls; block in the key keeps it correct. */
    private poolTypeCache = new Map<string, [boolean, string]>();
    // Native contexts are mutable per contract. A cached type name alone does
    // not prove that the ABI currently loaded belongs to this action's block.
    private loadedActionAbis = new Map<string, {block: number; hex: string}>();

    private clearTypeCacheForContract(contract: string) {
        for (const key of this.poolTypeCache.keys()) {
            if (key.split('|')[1] === contract) this.poolTypeCache.delete(key);
        }
    }

    async fetchAbiHexAtBlockElastic(
        contract_name: string,
        last_block: number,
        get_json: boolean,
        fetch_offset: number
    ) {
        const cacheKey = contract_name + '|' + last_block + '|' + (get_json ? 'j' : 'h') + '|' + fetch_offset;
        const cached = this.poolAbiCache.get(cacheKey);
        if (cached !== undefined) {
            return cached;
        }
        const stopAbiFetch = this.profiler.start('fetch_abi_es');
        try {
            const _includes = ["block", "actions", "tables"];
            if (get_json) {
                _includes.push("abi");
            } else {
                _includes.push("abi_hex");
            }
            // const t_start = process.hrtime.bigint();
            const queryResult = await this.client.search<any>({
                index: `${this.chain}-abi-*`,
                size: 1 + fetch_offset,
                query: {
                    bool: {
                        must: [
                            { term: { account: contract_name } },
                            { range: { block: { lte: last_block } } }
                        ]
                    }
                },
                sort: [{ block: { order: "desc" } }],
                _source: { includes: _includes }
            });
            // const t_end = process.hrtime.bigint();
            const results = queryResult.hits.hits;
            // const duration = (Number(t_end - t_start) / 1000 / 1000).toFixed(2);
            let result: any;
            if (results.length > 0) {
                // hLog(`fetch abi from elastic took: ${duration} ms`);
                result = results[fetch_offset]._source;
            } else {
                result = null;
            }
            this.poolAbiCache.set(cacheKey, result);
            return result;
        } catch (e) {
            hLog(e);
            return null;
        } finally {
            stopAbiFetch();
        }
    }

    async verifyLocalType(contract: string, type: string, block_num: number, field: string): Promise<[boolean, string]> {

        const vkey = field + '|' + contract + '|' + type + '|' + block_num;
        const selectedAbi = await this.fetchAbiHexAtBlockElastic(contract, block_num, false, 0);
        if (selectedAbi?.abi_hex) {
            const loaded = this.loadedActionAbis.get(contract);
            if (loaded?.block !== selectedAbi.block || loaded?.hex !== selectedAbi.abi_hex) {
                this.clearTypeCacheForContract(contract);
                let status = false;
                try {
                    status = this.loadAbiHex(contract, selectedAbi.block, selectedAbi.abi_hex);
                } catch (error: any) {
                    debugLog(`Failed to load ${contract} ABI at ${selectedAbi.block}: ${error.message}`);
                }
                if (!status) {
                    this.loadedActionAbis.delete(contract);
                    return [false, ''];
                }
                this.loadedActionAbis.set(contract, {block: selectedAbi.block, hex: selectedAbi.abi_hex});
            }
        } else if (this.loadedActionAbis.has(contract)) {
            // A previously decoded, later block cannot supply an ABI for a
            // block with no historical reference. Preserve the normal fallback.
            this.loadedActionAbis.delete(contract);
            this.abieos.deleteContract(contract);
            this.clearTypeCacheForContract(contract);
        }
        const vCached = this.poolTypeCache.get(vkey);
        if (vCached !== undefined) {
            return vCached;
        }

        let _status: boolean;
        let resultType = '';

        try {
            resultType = this.getAbiDataType(field, contract, type);
            _status = !!resultType;
        } catch (e: any) {
            debugLog(`(abieos) ${contract}::${type} (type: "${type}") @ ${block_num} >>> ${e.message}`);
            _status = false;
        }

        if (!_status) {

            if (this.conf.settings.allow_custom_abi) {
                if (this.customAbiMap.has(contract)) {
                    const list = this.customAbiMap.get(contract);
                    if (list) {
                        const matchingAbi = list.find(entry => {
                            return entry.startingBlock < block_num && entry.endingBlock > block_num;
                        });
                        if (matchingAbi && matchingAbi.abi) {
                            this.loadedActionAbis.delete(contract);
                            this.clearTypeCacheForContract(contract);
                            _status = this.abieos.loadAbi(contract, matchingAbi.abi);
                        }
                    }
                }
            }

            if (!_status) {
                const savedAbi = await this.fetchAbiHexAtBlockElastic(contract, block_num, false, 0);
                if (savedAbi) {
                    if (savedAbi[field + 's'] && savedAbi[field + 's'].includes(type)) {
                        if (savedAbi.abi_hex) {

                            // _status = this.loadAbiHex(contract, savedAbi.block, savedAbi.abi_hex);

                            try {

                                _status = this.loadAbiHex(contract, savedAbi.block, savedAbi.abi_hex);

                            } catch (error: any) {

                                debugLog(`(abieos) ${contract}::${type} (field: "${field}") @ ${block_num} >>> ${error.message}`);

                            }
                        }
                    }
                }
            }

            // successful load from ES cache
            if (_status) {
                try {
                    resultType = this.getAbiDataType(field, contract, type);
                    if (resultType) {
                        _status = true;
                        // early return since the loaded abi should work
                        this.poolTypeCache.set(vkey, [_status, resultType]);
                        return [_status, resultType];
                    } else {
                        _status = false;
                    }
                } catch (e: any) {
                    debugLog(`(abieos/cached) >> ${e.message}`);
                    _status = false;
                }
            }

            if (!_status) {
                try {
                    this.loadedActionAbis.delete(contract);
                    this.clearTypeCacheForContract(contract);
                    _status = await this.loadCurrentAbiHex(contract);
                } catch (error: any) {
                    debugLog(`(abieos/current) >> ${error.message}`);
                    _status = false;
                }
            }

            if (_status) {
                try {
                    resultType = this.getAbiDataType(field, contract, type);
                    _status = true;
                } catch (e: any) {
                    debugLog(`(abieos/current) >> ${e.message}`);
                    _status = false;
                }
            }
        }
        const verifyResult: [boolean, string] = [_status, resultType];
        this.poolTypeCache.set(vkey, verifyResult);
        return verifyResult;
    }

    async deserializeActionAtBlockNative(self: DSPoolWorker, action: HyperionActionAct, block_num: number): Promise<any> {
        self.recordContractUsage(action.account);
        const [_status, actionType] = await self.verifyLocalType(action.account, action.name, block_num, "action");
        if (_status && actionType) {
            const stopAbieos = self.profiler.start('abieos_deserialization');
            try {
                return self.abieos.binToJson(action.account, actionType, Buffer.from(action.data, 'hex'));
            } catch (e: any) {
                debugLog(`(abieos) ${action.account}::${action.name} (type: "${actionType}") @ ${block_num} >>> ${e.message}`);
            } finally {
                stopAbieos();
            }
        }
        return self.deserializeActionAtBlock(action, block_num);
    }

    async getContractAtBlock(accountName: string, block_num: number, check_action: string): Promise<ABI | null> {

        // recover ABI from cache
        if (this.contracts.has(accountName)) {
            let _sc = this.contracts.get(accountName);
            if (_sc) {
                if ((_sc.valid_until > block_num && block_num > _sc.valid_from) || _sc.valid_until === -1) {
                    if (_sc.contract.actions.find(value => value.name === check_action)) {
                        return _sc.contract;
                    }
                }
            }
        }

        let savedAbi: HyperionAbi | null;
        let abi: ABI;
        savedAbi = await this.fetchAbiHexAtBlockElastic(accountName, block_num, true, 0);
        if (savedAbi === null || (savedAbi.actions && !savedAbi.actions.includes(check_action))) {
            savedAbi = await this.getAbiFromHeadBlock(accountName);
            if (!savedAbi) {
                return null;
            }
            abi = ABI.from(savedAbi.abi)
        } else {
            try {
                abi = ABI.from(savedAbi.abi);
            } catch (e: any) {
                hLog('failed to parse abi at getContractAtBlock --> ' + e.message);
                return null;
            }
        }

        if (!abi) {
            return null;
        }


        if (check_action) {
            // check if the action is in the abi
            if (abi.getActionType(check_action)) {
                if (!this.failedAbiMap.has(accountName) || !this.failedAbiMap.get(accountName)?.has(-1)) {
                    try {
                        this.loadedActionAbis.delete(accountName);
                        this.clearTypeCacheForContract(accountName);
                        this.abieos.loadAbi(accountName, JSON.stringify(abi));
                    } catch (e:any) {
                        hLog(`failed to load abi for ${accountName} @ ${block_num} >>> ${e.message}`);
                    }
                } else {
                    debugLog('ignore reloading of current abi for', accountName);
                }
                this.contracts.set(accountName, {
                    contract: abi,
                    valid_until: savedAbi.valid_until ? savedAbi.valid_until : -1,
                    valid_from: savedAbi.valid_from ? savedAbi.valid_from : -1
                });
            }
        }
        return abi;
    }

    async deserializeActionAtBlock(action: HyperionActionAct, block_num: number): Promise<any | null> {
        const stopAntelope = this.profiler.start('antelope_deserialization');
        try {
            const contract = await this.getContractAtBlock(action.account, block_num, action.name);
            if (!contract) {
                return null;
            }
            try {
                const typedAction = Action.from(action);
                const decodedData = typedAction.decodeData(contract);
                return Serializer.objectify(decodedData);
            } catch (e: any) {
                debugLog(`(antelope) ${action.account}::${action.name} @ ${block_num} >>> ${e.message}`);
                return null;
            }
        } finally {
            stopAntelope();
        }
    }

    // Per-batch Redis pipeline accumulator. processTraces appends its
    // tx-cache writes here instead of doing its own round-trip; processMessages
    // flushes the whole batch with a single .exec() at the end.
    //
    // Hyperion has two operating modes with different cache-visibility needs:
    //
    //   • Batch indexing (historical catch-up): no live API traffic, throughput
    //     wins. We accumulate cache writes across the whole cargo and flush
    //     once at the end. Cargo-sized flush amortises Redis RTTs.
    //
    //   • Live indexing (caught up to chain head): API calls may hit
    //     `get_transaction(id)` for transactions submitted moments earlier.
    //     We flush per-trace so the cache is visible as fast as possible.
    //
    // The master tags each AMQP message with `live = 'true' | 'false'` based
    // on which reader produced it (continuous vs parallel). processTraces
    // reads that flag and flushes immediately for live traces; non-live
    // traces remain queued for the end-of-batch flush. No config knob is
    // needed for the common case — it follows the master's reader mode
    // automatically. Operators who want to override may set
    // `api.tx_cache_mode: 'sync' | 'batch' | 'auto'` (default 'auto').
    private redisBatchPipeline: any = null;
    private redisBatchHasOps = false;

    async processMessages(messages: Message[]) {
        const stop = this.profiler.start('process_messages_batch');
        this.poolAbiCache.clear();   // per-cargo ABI-lookup memo
        this.poolTypeCache.clear();  // per-cargo type-resolution memo
        try {
            this.redisBatchPipeline = this.ioRedisClient
                ? this.ioRedisClient.pipeline()
                : null;
            this.redisBatchHasOps = false;

            try {
                for (const data of messages) {
                    const parsedData = JSON.parse(Buffer.from(data.content).toString());
                    await this.processTraces(parsedData, data.properties.headers);
                    // ack message
                    if (this.ch_ready && this.ch) {
                        try {
                            this.ch.ack(data);
                        } catch (e) {
                            console.log(e);
                            console.log(parsedData);
                            console.log(data.properties.headers);
                        }
                    } else {
                        hLog("Channel is not ready!");
                    }
                }
            } finally {
                // ALWAYS attempt the end-of-batch flush — even if the for-loop
                // threw partway through. We want completed traces' cache
                // writes to persist even when a later trace in the same
                // batch fails to deserialize. Worst case the flush itself
                // fails and we log it; the durable AMQP path for those
                // traces is unaffected.
                await this.flushRedisBatch();
            }
        } finally {
            stop();
        }
    }

    private async flushRedisBatch(): Promise<void> {
        if (this.redisBatchPipeline && this.redisBatchHasOps) {
            try {
                const stopRedis = this.profiler.start('redis_batch_exec');
                await this.redisBatchPipeline.exec();
                stopRedis();
            } catch (e) {
                hLog(e);
            }
        }
        this.redisBatchPipeline = null;
        this.redisBatchHasOps = false;
    }

    /**
     * Resolve the tx-cache flush policy. Returns `true` if the given trace
     * should be flushed to Redis immediately (per-trace, lower latency) or
     * `false` if it can ride on the end-of-cargo batch flush (higher
     * throughput).
     */
    private shouldFlushTxCacheNow(live: string | undefined): boolean {
        const mode = this.conf.api.tx_cache_mode ?? 'auto';
        if (mode === 'sync') return true;
        if (mode === 'batch') return false;
        // 'auto' (default): per-trace flush for live traces, end-of-batch
        // for historical/parallel traces.
        return live === 'true';
    }

    async processTraces(transaction_trace, extra) {
        const stopTraces = this.profiler.start('process_traces');
        try {
            const { cpu_usage_us, net_usage_words, signatures } = transaction_trace;
            const { block_num, block_id, producer, ts, inline_count, filtered, live } = extra;

            if (transaction_trace.status === 0) {
                let action_count = 0;
                const trx_id = transaction_trace['id'].toLowerCase();
                const _actDataArray: any[] = [];
                const _processedTraces: ActionTrace[] = [];
                let action_traces: ActionTrace[] = transaction_trace['action_traces'];
                const trx_data = {
                    trx_id,
                    block_num,
                    block_id,
                    producer,
                    cpu_usage_us,
                    net_usage_words,
                    ts,
                    inline_count,
                    filtered,
                    signatures
                };

                const usageIncluded = { status: false };

                // perform action flattening if necessary
                if (this.mLoader.parser?.flatten) {
                    const trace_counters = { trace_index: 0 };
                    action_traces = await this.mLoader.parser.flattenInlineActions(action_traces, 0, trace_counters, 0);
                    action_traces.sort((a, b) => {
                        return a[1].receipt[1].global_sequence - b[1].receipt[1].global_sequence;
                    });
                }

                for (const action_trace of action_traces) {

                    // print original trace, uncomment below
                    // console.log(trx_id, JSON.stringify(action_trace[1], null, 2));

                    if (action_trace[0].startsWith('action_trace_')) {
                        const ds_status = await this.mLoader.parser?.parseAction(this,
                            ts,
                            action_trace[1],
                            trx_data,
                            _actDataArray,
                            _processedTraces,
                            transaction_trace,
                            usageIncluded
                        );
                        if (ds_status) {
                            this.temp_ds_counter++;
                            action_count++;
                            // print deserialized trace, uncomment below
                            // console.log(trx_id, JSON.stringify(action_trace[1], null, 2));
                        }
                    }

                    // console.log(action_trace);
                }

                // Group action traces: merge notification receipts while preserving
                // genuinely distinct duplicate actions (fixes #148)
                const _finalTraces = groupActionTraces(_processedTraces);

                // Submit Actions after deduplication

                const redisPayload = new Map<string, RedisValue>();

                for (const uniqueAction of _finalTraces) {

                    cleanActionTrace(uniqueAction);

                    // remove contract console logs by default
                    if (!this.conf.features.contract_console) {
                        delete uniqueAction.console;
                    } else {
                        if (uniqueAction.console) {
                            console.log(uniqueAction.block_num, uniqueAction.act.account, uniqueAction.act.name, uniqueAction.console);
                        }
                    }

                    const payload = Buffer.from(JSON.stringify(uniqueAction));
                    redisPayload.set(uniqueAction.global_sequence.toString(), payload);
                    this.actionDsCounter++;
                    this.pushToActionsQueue(payload, block_num);
                    if (live === 'true') {
                        this.pushToActionStreamingQueue(payload, uniqueAction);
                    }
                }

                // Queue tx-cache writes onto the batch-level pipeline.
                // For batch indexing traces (live !== 'true') the actual
                // round-trip happens once at the end of the cargo via
                // processMessages → ~N traces collapse into one Redis
                // network exchange.
                //
                // For live indexing traces (live === 'true'), flush
                // immediately so the cache is visible for API queries that
                // may arrive moments after the action — at the cost of
                // doing the same one-pipeline round-trip per trace that
                // the experiment-1 per-trace pipeline already proved is
                // safe and ~half the cost of two separate awaits.
                if (this.redisBatchPipeline && !this.conf.api.disable_tx_cache && redisPayload.size > 0) {
                    this.redisBatchPipeline
                        .hset('trx_' + trx_data.trx_id, redisPayload)
                        .expire('trx_' + trx_data.trx_id, this.txCacheExpiration);
                    this.redisBatchHasOps = true;

                    if (this.shouldFlushTxCacheNow(live)) {
                        // Flush the current pipeline now; create a fresh
                        // one for any subsequent traces in the same batch.
                        const stopLive = this.profiler.start('redis_live_flush');
                        try {
                            await this.redisBatchPipeline.exec();
                        } catch (e) {
                            hLog(e);
                        } finally {
                            stopLive();
                        }
                        this.redisBatchPipeline = this.ioRedisClient
                            ? this.ioRedisClient.pipeline()
                            : null;
                        this.redisBatchHasOps = false;
                    }
                }
            }
        } finally {
            stopTraces();
        }
    }

    pushToActionsQueue(payload: any, block_num: number) {
        if (this.conf.indexer.disable_indexing) return;
        const q = this.chain + ":index_actions:" + (this.act_emit_idx);
        this.act_emit_idx++;
        if (this.act_emit_idx > (this.conf.scaling.ad_idx_queues)) {
            this.act_emit_idx = 1;
        }
        // Hot path: publish directly via the AMQP channel. amqplib buffers
        // internally and returns false on backpressure; the cargo wrapper
        // around processMessages is the natural throttling point so we
        // don't need a per-push async queue here. Fall back to the
        // preIndexingQueue only when the channel isn't ready.
        if (this.ch_ready && this.ch) {
            try {
                this.ch.sendToQueue(q, payload, { headers: { block_num } });
                return;
            } catch (e: any) {
                hLog(e.message);
            }
        }
        // Channel temporarily unavailable — queue for the async worker
        // which will retry once ch_ready returns true.
        this.preIndexingQueue.push({
            queue: q,
            content: payload,
            headers: { block_num }
        });
    }

    pushToActionStreamingQueue(payload: any, uniqueAction: any) {
        if (this.allowStreaming && this.conf.features['streaming'].traces && this.ch) {
            try {
                const notificationArray = new Set();
                uniqueAction.act.authorization.forEach((auth: any) => {
                    notificationArray.add(auth.actor);
                });
                uniqueAction.receipts.forEach((rec: any) => {
                    notificationArray.add(rec.receiver);
                });
                const headers = {
                    event: 'trace',
                    account: uniqueAction['act']['account'],
                    name: uniqueAction['act']['name'],
                    notified: [...notificationArray].join(",")
                };
                this.ch.publish('', this.chain + ':stream', payload, { headers });
            } catch (e) {
                hLog(e);
            }
        }
    }

    async initConsumer() {
        if (this.ch_ready && this.ch) {
            await this.ch.prefetch(this.conf.prefetch.block);
            await this.ch.consume(this.local_queue, (data) => {
                if (data) {
                    this.consumerQueue.push(data);
                }
            });
            debugLog(`started consuming from ${this.local_queue}`);
        }
    }

    deleteCache(contract: string) {
        this.loadedActionAbis.delete(contract);
        this.clearTypeCacheForContract(contract);
        // delete cache contract on abieos context
        const status = this.abieos.deleteContract(contract);
        if (!status) {
            debugLog('Contract not found on cache!');
        } else {
            debugLog(`🗑️ Contract successfully removed from cache!`);
        }
    }

    startMonitoring() {

        // hLog(`Starting monitoring loop on ds_worker ${process.env.local_id}`);
        // Monitor Contract Usage
        if (!this.monitoringLoop) {
            this.monitoringLoop = setInterval(() => {
                if (this.totalHits > 0) {
                    process.send?.({
                        event: 'contract_usage_report',
                        data: this.contractUsage,
                        total_hits: this.totalHits
                    });
                    // hLog(`${this.local_queue} ->> ${this.actionDsCounter} actions`);
                    process.send?.({
                        event: 'ds_report',
                        actions: this.actionDsCounter
                    });
                    this.noActionCounter = 0;
                } else {
                    if (!this.conf.indexer.abi_scan_mode && !this.conf.indexer.live_reader) {
                        this.noActionCounter++;
                        if (this.noActionCounter > 60) {
                            debugLog(`No actions processed for ${this.noActionCounter} seconds!`);
                        }
                    }
                }
                this.contractUsage = {};
                this.totalHits = 0;
                this.actionDsCounter = 0;
            }, 1000);
        }
        // hLog(`Monitoring loop started on ds_worker ${process.env.local_id}`);
    }

    initializeShipAbi(abiString: string) {
        this.shipABI = ABI.from(abiString);
        this.abieos.loadAbi("0", abiString);
        this.startMonitoring();
    }

    async assertQueues(): Promise<void> {
        const queue_prefix = this.conf.settings.chain;
        this.local_queue = queue_prefix + ':ds_pool:' + process.env.local_id;
        if (this.ch) {
            this.ch_ready = true;
            await this.ch.assertQueue(this.local_queue, RabbitQueueDef);
            await this.initConsumer();
        }
    }

    onIpcMessage(msg: any): void {
        switch (msg.event) {
            case 'initialize_abi': {
                this.initializeShipAbi(msg.data);
                break;
            }
            case 'remove_contract': {
                // hLog(`[${process.env.local_id}] Delete contract: ${msg.contract}`);
                this.deleteCache(msg.contract);
                break;
            }
            case 'connect_ws': {
                this.allowStreaming = true;
                break;
            }
        }
    }

    onReady() {
        process.send?.({
            event: 'ds_ready',
            id: process.env.worker_id
        });
    }

    async run(): Promise<void> {
        debugLog(`Standalone deserializer launched with id: ${process.env.local_id}`);
        this.events.once('ready', () => {
            // check if the ship abi is loaded
            if (!this.shipABI) {
                this.onReady();
            }
        });
    }
}
