/** Offline issue230 evidence packaging. Never builds, invokes Docker/Git, or changes an input. */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {constants} from 'node:fs';
import {lstat, open, readdir, readlink, mkdir, readFile, realpath, writeFile} from 'node:fs/promises';
import {dirname, isAbsolute, join, relative, resolve, sep} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';

export const expectedCommit = '8b483fd0aec2819e1c15171e3950d39e715c6bd6';
export const expectedPatch = '7c30b1c5cf7311750c3c7726fc8091cdee1f440f19ee4d51c620b67813e30ddb';
export const limits = Object.freeze({files: 10000, bytes: 128 * 1024 * 1024, fileBytes: 32 * 1024 * 1024, jsonBytes: 16 * 1024 * 1024, depth: 20});
const root = dirname(fileURLToPath(import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const canonical = value => JSON.stringify(value, (_key, entry) => entry && typeof entry === 'object' && !Array.isArray(entry)
    ? Object.fromEntries(Object.keys(entry).sort().map(key => [key, entry[key]])) : entry);
const hex64 = /^[0-9a-f]{64}$/;
const stages = ['before-fragment', 'after-fragment', 'before-ack'];
export function evidencePlan() {
    return [24, 22].flatMap(major => [{kind: 'wire', major, name: `action-admission-wire-native-node${major}-review1-20261020-run`,
        state: 'action-admission-wire-native-review1-20261020-state.json'}, ...stages.map(stage => ({kind: 'native', major, stage,
        name: `action-admission-crash-node${major}-${stage}-review1-20261020-run`,
        state: `action-admission-crash-node${major}-${stage}-review1-20261020-state.json`}))]);
}
export function archivePath(value) {
    assert.ok(typeof value === 'string' && value.length > 0 && value.length <= 512 && !isAbsolute(value), 'invalid relative evidence path');
    assert.ok(/^[A-Za-z0-9_@.+/=-]+$/.test(value), 'evidence path contains unsafe characters');
    const parts = value.split('/'); assert.ok(parts.length <= limits.depth && parts.every(part => part && !['.', '..'].includes(part)
        && !part.endsWith('.') && !/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part)), 'unsafe evidence path component');
    return value;
}
export function checkBudget(files, bytes) {
    assert.ok(Number.isSafeInteger(files) && files >= 0 && files <= limits.files, 'evidence file-count bound exceeded');
    assert.ok(Number.isSafeInteger(bytes) && bytes >= 0 && bytes <= limits.bytes, 'evidence byte bound exceeded');
}
export function logAliasTarget(path, target, context) {
    assert.ok(context && /^action-admission-crash-node(?:22|24)-(?:before-fragment|after-fragment|before-ack)-review1-20261020-run$/.test(context.run),
        `unrecognized evidence symlink: ${path} -> ${target}`);
    assert.match(context.chain, /^hyp-replay-[a-f0-9]{12}$/);
    const parent = `${context.run}/logs/${context.chain}`;
    assert.equal(path, parent + '/deserialization_errors.log', `unrecognized evidence symlink: ${path} -> ${target}`);
    assert.match(target, /^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}\.\d{3}Z_ds_err_[0-9]+_[0-9]+\.log$/,
        `unsafe log alias target: ${path} -> ${target}`);
    return archivePath(parent + '/' + target);
}
export async function inspectLogAlias(base, path, context) {
    const parent = path.split('/').slice(0, -1).join('/'); await noLinks(base, parent, false);
    const link = join(base, path), entry = await lstat(link); assert.ok(entry.isSymbolicLink(), 'expected log alias link');
    const target = await readlink(link), regular = logAliasTarget(path, target, context);
    // Open the separately named original file through noLinks/O_NOFOLLOW; never read through the alias.
    const bytes = await stableBytes(base, regular);
    assert.equal(await readlink(link), target, 'log alias changed during validation');
    return {path: 'runs/' + path, target: 'runs/' + regular, targetBytes: bytes.length, targetSha256: sha(bytes),
        reason: 'Hyperion deserialization log convenience alias; original regular log is included separately.'};
}
function contained(base, target) {const rel = relative(base, target); assert.ok(rel && rel !== '..' && !rel.startsWith('..' + sep) && !isAbsolute(rel), 'path escapes evidence boundary'); return rel;}
async function noLinks(base, name, file = true) {
    archivePath(name); const baseStat = await lstat(base); assert.ok(baseStat.isDirectory() && !baseStat.isSymbolicLink(), 'input root is not a real directory');
    assert.equal((await realpath(base)).toLowerCase(), resolve(base).toLowerCase(), 'input root traverses a symlink');
    let path = base;
    const parts = name.split('/');
    for (let index = 0; index < parts.length; index++) {
        path = join(path, parts[index]); const entry = await lstat(path);
        assert.ok(!entry.isSymbolicLink(), 'evidence symlink/reparse point refused');
        assert.ok(index === parts.length - 1 && file ? entry.isFile() : entry.isDirectory(), 'invalid evidence file/directory');
    }
    contained(base, path); return path;
}
async function stableBytes(base, name, maximum = limits.fileBytes) {
    const path = await noLinks(base, name), before = await lstat(path);
    assert.ok(before.size >= 0 && before.size <= maximum, `bounded evidence file required: ${name}`);
    const handle = await open(path, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
    try {
        const opened = await handle.stat(); assert.equal(opened.ino, before.ino); assert.equal(opened.dev, before.dev); assert.equal(opened.size, before.size);
        const bytes = await handle.readFile(); const after = await handle.stat();
        assert.equal(bytes.length, before.size); assert.equal(after.size, before.size); assert.equal(after.mtimeMs, before.mtimeMs);
        assert.equal(after.ctimeMs, before.ctimeMs); await noLinks(base, name); return bytes;
    } finally {await handle.close();}
}
const json = async (base, name) => JSON.parse((await stableBytes(base, name, limits.jsonBytes)).toString());
const exactVersion = major => major === 24 ? 'v24.19.0' : 'v22.23.3';
export function validateWireReport(report, major) {
    assert.equal(report.status, 'passed'); assert.equal(report.schemaVersion, 1); assert.equal(report.runtime?.node, exactVersion(major));
    assert.equal(report.runtime.platform, 'win32'); assert.equal(report.runtime.arch, 'x64'); assert.match(report.fixtureRun, /^[a-f0-9]{12}$/);
    assert.equal(report.nativeAddonResolutions, 0); assert.deepEqual(report.amqpErrors, []);
    assert.equal(report.cases.length, 3); assert.equal(report.writes.length, 402);
    for (const write of report.writes) {assert.deepEqual(write.shards, {total: 2, successful: 2, failed: 0}); assert.match(write.requestSha256, hex64);}
    const profiles = ['wire-sysio-6508c9e8-engineering-v1', 'wire-sysio-7dede884-engineering-v1', 'wire-sysio-7dede884-engineering-v1'];
    for (const [index, item] of report.cases.entries()) {
        const suffix = ['6508', '7d', 'captured7d'][index]; assert.equal(item.chain, `hyp-wire-admit-${report.fixtureRun}-n${major}-${suffix}`);
        assert.equal(item.status, 'passed'); assert.equal(item.profileId, profiles[index]); assert.equal(item.targetRemainsEmpty, true);
        assert.equal(item.target.name, item.chain + '-action-v1-000001'); assert.ok(typeof item.target.uuid === 'string' && item.target.uuid);
        assert.ok(item.publications.length > 0 && item.publications.every(row => row.confirmed && row.mandatory && row.persistent));
        assert.equal(item.queues.length, 3); assert.ok(item.queues.every(row => row.messageCount === 0 && row.consumerCount === 0 && row.queue.startsWith(item.chain + ':')));
        assert.equal(item.durableIncompleteRecords.length, 1); assert.equal(item.incomplete.length, 1);
        for (const block of item.blocks) assert.equal(block.producer.codeRevision, expectedCommit);
        if (index < 2) {
            assert.equal(item.kind, 'constructed-source');
            for (const key of ['sourceDerivedMembership', 'certifiedOrigins', 'absentAbiIncomplete', 'unrelatedContinues']) assert.equal(item[key], true);
            assert.deepEqual(item.blocks.map(block => block.blockNum), [1, 2, 3, 4]);
            assert.deepEqual(item.blocks.map(block => block.sealed), [true, true, false, true]);
            assert.deepEqual(item.blocks[1].outputs.map(value => value.effect.globalSequence), ['9007199254740993', '9223372036854775808']);
            assert.deepEqual(item.blocks[2].outputs.map(value => value.effect.globalSequence), ['9223372036854775812']);
            assert.equal(item.blocks[3].outputs[0].effect.globalSequence, '18446744073709551615');
        } else {
            assert.equal(item.kind, 'unmodified-retained-native-capture'); assert.equal(item.sourceRevision, '7dede884e0150d36fa788e85a119e10653ade8ca');
            assert.equal(item.blocks.length, 1); assert.equal(item.blocks[0].blockNum, 6350); assert.equal(item.blocks[0].sealed, false); assert.deepEqual(item.blocks[0].outputs, []);
            assert.equal(item.capture.fileSha256, 'b5797ca6738c42bfe88ce1e91c3e7021511cc29ddd69a21a06f6bdf0abd5abc7');
            assert.equal(item.capture.expectedIncomplete, true); assert.equal(item.capture.completeSourceCertificate, false); assert.equal(item.capture.priorFrontierInvented, false);
        }
    }
    return {runtime: report.runtime.node, cases: report.cases.map(item => ({kind: item.kind, profileId: item.profileId, blocks: item.blocks.length,
        sealed: item.blocks.filter(block => block.sealed).length, incomplete: item.durableIncompleteRecords.length, targetEmpty: item.targetRemainsEmpty})),
        verifiedAllCopyWrites: report.writes.length, amqpErrors: 0, nativeAddonResolutions: 0};
}
export function validateNativeReport(report, major, stage) {
    assert.equal(report.status, 'passed'); assert.equal(report.runtime?.node, exactVersion(major)); assert.equal(report.runtime.platform, 'win32');
    assert.equal(report.runtime.arch, 'x64'); assert.equal(report.sourceCommit, expectedCommit); assert.equal(report.actionSourceAdmission, true);
    assert.equal(report.chain, `hyp-replay-${report.fixtureRun}`);
    assert.deepEqual(report.replayErrors, []); assert.deepEqual(report.rpcFallbackAttempts, []); assert.ok(report.rpcRequests.every(row => row.denied === false));
    assert.ok(report.cleanup.some(row => row.name === 'workers' && row.ok === true)); assert.ok(report.cleanup.every(row => row.ok !== false && !row.error));
    const membership = report.actionMembership;
    assert.equal(membership.source, 'audited-retained-native-capture'); assert.equal(membership.profileId, 'antelope-default-v1');
    assert.equal(membership.replayedBlocks, 87); assert.equal(membership.plans.length, 87); assert.equal(membership.transactions, 103); assert.equal(membership.selectedGroups, 12);
    assert.equal(new Set(membership.plans.map(plan => plan.admissionId)).size, 87);
    assert.equal(membership.plans.reduce((sum, plan) => sum + plan.transactions, 0), 103); assert.equal(membership.plans.reduce((sum, plan) => sum + plan.effects, 0), 12);
    for (const plan of membership.plans) assert.equal(plan.producer.codeRevision, expectedCommit);
    assert.equal(report.finalActions.length, 12); assert.equal(report.finalBlocks.length, 87); assert.equal(report.durableCopies.length, 4);
    for (const kind of ['action', 'block']) {
        const copies = report.durableCopies.filter(row => row.index.includes('-' + kind + '-'));
        assert.equal(copies.length, 2); assert.equal(new Set(copies.map(row => row.node)).size, 2);
        assert.equal(copies[0].count, kind === 'action' ? 12 : 87); assert.equal(copies[1].count, copies[0].count); assert.equal(copies[0].sha256, copies[1].sha256);
    }
    assert.equal(report.actionSourceCrashControl.stage, stage); assert.equal(report.actionSourceCrashObserved.marker.stage, stage);
    const recovery = report.intentionalRecovery; assert.equal(recovery.outcome, 'intentional-process-exit-and-recovery'); assert.equal(recovery.originalAckAttempts, 0);
    assert.deepEqual(report.masterExit, {code: 1, signal: null}); assert.deepEqual(recovery.rawMasterExit, report.masterExit);
    assert.equal(recovery.marker.exitCode, 86); assert.equal(recovery.replacement.redelivered, true);
    assert.notEqual(recovery.replacement.pid, recovery.marker.pid); assert.equal(recovery.rawShutdown.success, false);
    assert.equal(recovery.rawShutdown.failedChildren.length, 1); assert.equal(recovery.rawShutdown.failedChildren[0].code, 86);
    assert.ok(report.finalQueues.every(row => row.ready === 0 && row.unacked === 0 && row.messages === 0));
    assert.equal(report.readerCompletion.length, 1); assert.equal(report.bulkAccounting.failedItems, 0);
    assert.equal(sha(canonical(report.finalActions)), report.outputSha256.actions); assert.equal(sha(canonical(report.finalBlocks)), report.outputSha256.blocks);
    return {runtime: report.runtime.node, stage, retainedSources: 87, transactions: 103, selectedGroups: 12, physicalCopyChecks: 4,
        deniedRpc: 0, bulkAcknowledgedCopies: report.bulkAccounting.acknowledgedCopies, rawMasterExit: report.masterExit, rawWorkerExit: 86, replacementRedelivered: true};
}
export function validateCodeCi(record) {
    assert.equal(record.number, 232); assert.equal(record.headRefOid, expectedCommit); assert.equal(record.url, 'https://github.com/eosrio/hyperion-history-api/pull/232');
    const expected = ['es955-fixture', ...['build', 'projection-mongodb', 'action-sequences-design', 'action-source-journal'].flatMap(name => [name + ' (22.x)', name + ' (24.x)'])];
    assert.equal(record.statusCheckRollup.length, 9); assert.deepEqual(record.statusCheckRollup.map(row => row.name).sort(), expected.sort());
    for (const row of record.statusCheckRollup) {assert.equal(row.status, 'COMPLETED'); assert.equal(row.conclusion, 'SUCCESS');
        assert.ok(Number.isFinite(Date.parse(row.completedAt))); assert.match(row.detailsUrl, /^https:\/\/github\.com\/eosrio\/hyperion-history-api\/actions\/runs\/[0-9]+\/job\/[0-9]+$/);}
    return {headCommit: expectedCommit, completedSuccessfulChecks: 9, pullRequest: record.url, evidence: 'review/issue230-code-commit-ci.json'};
}
export function canonicalReceiptTimestamp(value) {
    assert.equal(typeof value, 'string', 'receipt timestamp must be text');
    const match = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.([0-9]{1,9}))?Z$/.exec(value);
    assert.ok(match, 'receipt timestamp requires a UTC ISO date with at most nanosecond precision');
    const date = new Date(match[1] + 'Z');
    assert.ok(Number.isFinite(date.getTime()) && date.toISOString().slice(0, 19) === match[1], 'invalid receipt calendar date');
    // Validate the whole-second calendar above; compare all fractional digits as text, never milliseconds.
    const fraction = (match[2] ?? '').replace(/0+$/, '');
    return match[1] + (fraction ? '.' + fraction : '') + 'Z';
}
export function validateCleanup(state, core, receipt, coreReceipt) {
    assert.equal(state.schemaVersion, 1); assert.equal(state.status, 'ready'); assert.deepEqual(state.core, core);
    assert.match(state.run, /^[a-f0-9]{12}$/); assert.equal(core.run, state.run); assert.equal(receipt.run, state.run); assert.equal(coreReceipt.run, state.run);
    assert.equal(state.network, `hyp-es955-replicas-${state.run}`); assert.equal(coreReceipt.network, state.network);
    assert.equal(receipt.coreStateFile, state.coreStateFile);
    const normalized = value => ({...value, inspectedAt: canonicalReceiptTimestamp(value.inspectedAt), completedAt: canonicalReceiptTimestamp(value.completedAt)});
    assert.deepEqual(normalized(receipt.coreCleanup), normalized(coreReceipt));
    for (const key of ['remainingContainers', 'remainingVolumes', 'remainingNetworks']) assert.equal(coreReceipt[key], 0);
    assert.deepEqual([...receipt.extraContainers].sort(), [state.redis, state.mongo, state.spring].map(item => item.containerId).sort());
    assert.deepEqual([...receipt.extraVolumes].sort(), [state.redis, state.mongo, state.spring].map(item => item.volume).sort());
    assert.deepEqual([...coreReceipt.containers].sort(), [...core.nodes, core.broker].map(item => item.containerId).sort());
    assert.deepEqual([...coreReceipt.volumes].sort(), [...core.nodes, core.broker].map(item => item.volume).sort());
    assert.ok(Number.isFinite(Date.parse(receipt.completedAt)) && Number.isFinite(Date.parse(coreReceipt.completedAt)));
    return {run: state.run, containers: 7, volumes: 7, network: state.network, remainingContainers: 0, remainingVolumes: 0, remainingNetworks: 0};
}
export function mergeSourceHashes(reports) {
    const union = new Map();
    for (const report of reports) {
        assert.ok(report.sourceHashes && Object.keys(report.sourceHashes).length > 0);
        for (const [path, hash] of Object.entries(report.sourceHashes)) {archivePath(path); assert.match(hash, hex64);
            if (union.has(path)) assert.equal(union.get(path), hash, `reported source drift: ${path}`); else union.set(path, hash);}
    }
    return union;
}
async function walk(base, directory, visit, aliases, context, depth = 0) {
    assert.ok(depth < limits.depth, 'evidence directory nesting exceeded');
    const path = await noLinks(base, directory, false);
    for (const entry of (await readdir(path, {withFileTypes: true})).sort((a, b) => a.name.localeCompare(b.name, 'en'))) {
        const name = directory + '/' + entry.name; archivePath(name);
        const stat = await lstat(join(base, name));
        if (stat.isSymbolicLink()) {aliases.push(await inspectLogAlias(base, name, context)); continue;}
        if (name.endsWith('/sources/node_modules') || name.includes('/sources/node_modules/')) continue; // Dependencies remain hashed in unmodified reports.
        if (stat.isDirectory()) await walk(base, name, visit, aliases, context, depth + 1); else {assert.ok(stat.isFile()); await visit(name);}
    }
}
export async function packageEvidence({codeRepo, stage, destination}) {
    codeRepo = resolve(codeRepo); stage = resolve(stage); destination = resolve(destination);
    assert.equal(destination.toLowerCase(), join(codeRepo, 'docs/performance/evidence/action-source-admission-20261020').toLowerCase(), 'unexpected evidence destination');
    assert.equal(dirname(stage).toLowerCase(), resolve(root).toLowerCase()); assert.match(relative(root, stage), /^issue230-evidence-stage-[a-z0-9-]+$/);
    await noLinks(codeRepo, 'docs/performance', false);
    for (const target of [stage, destination]) await assert.rejects(lstat(target), error => error.code === 'ENOENT', 'refusing existing package output');
    try {await noLinks(codeRepo, 'docs/performance/evidence', false);} catch (error) {if (error.code !== 'ENOENT') throw error;}
    const tarVersion = execFileSync('tar', ['--version'], {encoding: 'utf8', timeout: 5000, windowsHide: true, maxBuffer: 65536}).trim();
    const plans = evidencePlan(), reports = [], cleanup = [], selected = new Map(), omittedAliases = [];
    let total = 0;
    const add = async (base, source, path, expectedHash) => {
        archivePath(path); assert.ok(!selected.has(path), 'duplicate archive member');
        const bytes = await stableBytes(base, source); if (expectedHash) assert.equal(sha(bytes), expectedHash, `evidence hash mismatch: ${source}`);
        total += bytes.length; checkBudget(selected.size + 1, total);
        selected.set(path, {base, source, bytes: bytes.length, sha256: sha(bytes)});
    };
    const reportSummaries = [], stateByName = new Map();
    for (const plan of plans) {
        const report = await json(root, plan.name + '/report.json'); reports.push(report);
        reportSummaries.push({directory: plan.name, ...(plan.kind === 'wire' ? validateWireReport(report, plan.major) : validateNativeReport(report, plan.major, plan.stage))});
        if (!stateByName.has(plan.state)) {
            const state = await json(root, plan.state), core = await json(root, plan.state + '.core.json'), receipt = await json(root, plan.state + '.cleanup.json'), coreReceipt = await json(root, plan.state + '.core.json.cleanup.json');
            cleanup.push(validateCleanup(state, core, receipt, coreReceipt)); stateByName.set(plan.state, state);
            for (const suffix of ['', '.core.json', '.cleanup.json', '.core.json.cleanup.json']) await add(root, plan.state + suffix, 'resources/' + plan.state + suffix);
        }
        const state = stateByName.get(plan.state); assert.equal(report.fixtureRun, state.run);
        assert.equal(resolve(state.coreStateFile).toLowerCase(), join(root, plan.state + '.core.json').toLowerCase());
        const stateBytes = await stableBytes(root, plan.state); assert.equal(report.stateSha256, sha(stateBytes));
        if (plan.kind === 'native') {
            assert.equal(report.server.version.number, '9.5.5'); assert.equal(report.server.cluster_uuid, state.core.clusterUuid);
            assert.equal(report.server.cluster_name, state.core.clusterName);
        } else {
            for (const node of state.core.nodes) {
                assert.equal(report.identities[node.name].version.number, '9.5.5'); assert.equal(report.identities[node.name].cluster_uuid, state.core.clusterUuid);
                assert.equal(report.identities[node.name].cluster_name, state.core.clusterName);
            }
        }
        await walk(root, plan.name, async file => {
            const within = file.slice(plan.name.length + 1);
            const snapshot = within.startsWith('sources/') ? within.slice(8) : null;
            if (snapshot) assert.ok(Object.hasOwn(report.sourceHashes, snapshot), 'unreported source snapshot refused');
            await add(root, file, 'runs/' + file, snapshot ? report.sourceHashes[snapshot] : undefined);
        }, omittedAliases, plan.kind === 'native' ? {run: plan.name, chain: report.chain} : undefined);
    }
    assert.equal(omittedAliases.length, 6);
    for (const alias of omittedAliases) {
        const original = selected.get(alias.target); assert.ok(original, 'log alias original is missing from manifest');
        assert.equal(original.sha256, alias.targetSha256); assert.equal(original.bytes, alias.targetBytes);
    }
    assert.equal(stateByName.size, 7); assert.equal(new Set(cleanup.map(item => item.run)).size, 7);
    const hashes = mergeSourceHashes(reports);
    for (const [file, hash] of hashes) {
        const bytes = await stableBytes(codeRepo, file); assert.equal(sha(bytes), hash, `current file differs from final run: ${file}`);
        if (!file.startsWith('node_modules/')) await add(codeRepo, file, 'code/' + file, hash);
    }
    const requiredCommon = ['package-lock.json', 'src/indexer/workers/state-reader.ts', 'src/indexer/workers/deserializer.ts', 'src/indexer/workers/ds-pool.ts',
        'build/indexer/workers/state-reader.js', 'build/indexer/workers/deserializer.js', 'build/indexer/workers/ds-pool.js',
        'scripts/qualification/contract-replay.ts', 'src/indexer/history/action-source-admission.ts', 'build/indexer/history/action-source-admission.js'];
    for (const file of requiredCommon) assert.ok(reports.every(report => report.sourceHashes[file] === hashes.get(file)), `common evidence missing: ${file}`);
    const helper = 'scripts/qualification/action-source-admission-fault.mjs'; assert.ok(hashes.has(helper));
    const {verifyActionSourceCrashRecovery} = await import(pathToFileURL(join(codeRepo, helper)).href);
    for (const [index, plan] of plans.entries()) {
        const report = reports[index];
        if (plan.kind === 'wire') {
            const sums = await json(root, plan.name + '/SHA256SUMS.json');
            for (const [file, hash] of Object.entries(sums)) assert.equal(sha(await stableBytes(root, plan.name + '/' + archivePath(file))), hash);
            continue;
        }
        assert.equal(report.fixture.manifestSha256, report.retainedInput.manifestSha256);
        assert.equal(sha(await stableBytes(root, plan.name + '/fixture/manifest.json')), report.retainedInput.manifestSha256);
        for (const input of report.retainedInput.inputs) {
            const bytes = await stableBytes(root, plan.name + '/fixture/' + archivePath(input.file));
            assert.equal(bytes.length, input.bytes); assert.equal(sha(bytes), input.sha256);
        }
        for (const receipt of report.bulkReceipts) {
            assert.equal(receipt.status, 200); assert.equal(receipt.response.errors, false);
            for (const [field, value] of [['request', receipt.request], ['responseBody', receipt.responseBody]]) {
                const bytes = await stableBytes(root, plan.name + '/bulk/' + archivePath(value.file));
                assert.equal(bytes.length, value.bytes); assert.equal(sha(bytes), value.sha256);
                if (field === 'responseBody') assert.equal(canonical(JSON.parse(bytes)), canonical(receipt.response));
            }
            for (const item of receipt.response.items) {
                const value = Object.values(item)[0]; assert.ok([200, 201].includes(value.status)); assert.equal(value.error, undefined);
                assert.equal(value._shards.total, 2); assert.ok([1, 2].includes(value._shards.successful)); assert.equal(value._shards.failed, 0);
            }
        }
        const control = await json(root, plan.name + '/admission-fault/control.json'), marker = await json(root, plan.name + '/admission-fault/fault.json'), acks = [], rows = [];
        assert.deepEqual(control, report.actionSourceCrashControl); assert.deepEqual(marker, report.actionSourceCrashObserved.marker);
        assert.equal(resolve(control.output).toLowerCase(), join(root, plan.name).toLowerCase());
        assert.equal(resolve(control.observerDirectory).toLowerCase(), join(root, plan.name, 'observer').toLowerCase());
        assert.equal(resolve(control.configFile).toLowerCase(), join(root, plan.name, 'config/chain.json').toLowerCase());
        assert.equal(control.configSha256, sha(await stableBytes(root, plan.name + '/config/chain.json')));
        assert.equal(control.stateSha256, report.stateSha256); assert.equal(control.fixtureSha256, report.retainedInput.manifestSha256);
        assert.equal(control.sourceChainId, report.retainedInput.sourceChainId);
        const faultFiles = (await readdir(join(root, plan.name, 'admission-fault'))).sort();
        assert.ok(faultFiles.every(file => ['control.json', 'fault.json'].includes(file) || /^acks-[1-9][0-9]*\.jsonl$/.test(file)));
        for (const file of faultFiles.filter(name => name.startsWith('acks-'))) {
            const text = (await stableBytes(root, `${plan.name}/admission-fault/${file}`)).toString(); assert.ok(text.endsWith('\n'));
            for (const line of text.trimEnd().split('\n')) acks.push(JSON.parse(line));
        }
        const observed = report.actionSourceCrashObserved.acks;
        assert.equal(canonical([...acks].sort((a, b) => a.pid - b.pid || a.sequence - b.sequence)), canonical([...observed].sort((a, b) => a.pid - b.pid || a.sequence - b.sequence)));
        for (const file of (await readdir(join(root, plan.name, 'observer'))).sort()) {
            assert.match(file, /^worker-[1-9][0-9]*\.jsonl$/);
            const text = (await stableBytes(root, `${plan.name}/observer/${file}`)).toString(); assert.ok(text.endsWith('\n'));
            for (const line of text.trimEnd().split('\n')) rows.push(JSON.parse(line));
        }
        const verified = verifyActionSourceCrashRecovery({control, marker, acks, rows, masterPid: report.masterPid, masterExit: report.masterExit,
            membership: report.actionMembership, finalActions: report.finalActions});
        assert.equal(canonical(verified.evidence), canonical(report.intentionalRecovery));
    }
    for (const file of ['issue230-review-candidate-d.patch', 'issue230-candidate-d-unit-suite.log', 'issue230-standards-7c30b1c-received.md', 'issue230-spec-7c30b1c-received.md', 'issue230-code-commit-ci.json'])
        await add(root, file, 'review/' + file, file.endsWith('.patch') ? expectedPatch : undefined);
    const codeCi = validateCodeCi(await json(root, 'issue230-code-commit-ci.json'));
    const unit = (await stableBytes(root, 'issue230-candidate-d-unit-suite.log')).toString();
    assert.match(unit, /(?:^|\r?\n)\s*870 pass\r?\n\s*0 fail\r?\n\s*6287 expect\(\) calls/);
    for (const file of ['issue230-standards-7c30b1c-received.md', 'issue230-spec-7c30b1c-received.md'])
        assert.ok((await stableBytes(root, file)).toString().includes(expectedPatch), 'review does not identify final immutable candidate');
    await add(root, 'package-issue230-evidence.mjs', 'collector/package-issue230-evidence.mjs');
    // All required final outcomes, cleanup and source hashes were verified before any output directory is created.
    await mkdir(stage); const raw = join(stage, 'raw'); await mkdir(raw);
    const manifestFiles = [];
    for (const [path, entry] of [...selected].sort(([a], [b]) => a.localeCompare(b, 'en'))) {
        const bytes = await stableBytes(entry.base, entry.source); assert.equal(bytes.length, entry.bytes); assert.equal(sha(bytes), entry.sha256, 'input changed after validation');
        const target = join(raw, ...path.split('/')); await mkdir(dirname(target), {recursive: true}); await writeFile(target, bytes, {flag: 'wx'});
        assert.equal(sha(await readFile(target)), entry.sha256); manifestFiles.push({path, bytes: entry.bytes, sha256: entry.sha256});
    }
    try {await mkdir(dirname(destination));} catch (error) {if (error.code !== 'EEXIST') throw error;}
    await noLinks(codeRepo, 'docs/performance/evidence', false); await mkdir(destination);
    const archive = join(destination, 'raw-evidence.tar.gz');
    execFileSync('tar', ['-czf', archive, '-C', raw, '.'], {timeout: 120000, windowsHide: true, maxBuffer: 1024 * 1024});
    const listing = execFileSync('tar', ['-tzf', archive], {encoding: 'utf8', timeout: 30000, windowsHide: true, maxBuffer: 8 * 1024 * 1024})
        .split(/\r?\n/).filter(line => line && !line.endsWith('/')).map(line => archivePath(line.startsWith('./') ? line.slice(2) : line)).sort();
    assert.deepEqual(listing, manifestFiles.map(file => file.path).sort(), 'archive membership differs from copied evidence');
    const archiveBytes = await readFile(archive); assert.ok(archiveBytes.length <= limits.bytes);
    const summary = {schemaVersion: 1, issue: 230, codeCommit: expectedCommit, reviewedCandidateSha256: expectedPatch, createdAt: new Date().toISOString(),
        scope: 'Windows x64 Node native process/source/publication correctness qualification', runtimeVersions: ['v24.19.0', 'v22.23.3'],
        finalReports: reportSummaries, cleanup, omittedAliases, finalUnitSuite: {passed: 870, failed: 0, assertions: 6287}, codeCi,
        sourceHashAgreement: {reports: reports.length, distinctPaths: hashes.size, allReportedCurrentFilesMatch: true, commonPaths: requiredCommon},
        archive: {path: 'raw-evidence.tar.gz', sha256: sha(archiveBytes), bytes: archiveBytes.length, files: manifestFiles.length, uncompressedBytes: total, tarVersion},
        limits: ['Exactly eight final review1 runs; no pilot or pre-fix run is included.',
            'Six native process-exit runs replay the same finite audited fixture in distinct owned resource sets; counts are per run.',
            'Intentional worker exit86 and raw master exit1 remain visible; recovery requires distinct replacement, exact original receipt and real broker redelivery.',
            'Constructed Wire cases support engineering profile correctness only; the one actual captured7d onblock remains incomplete without fabricated ABI/frontier.',
            'No host power-loss, master failover, broad sink/canonical/PIT/query readiness, Wire testnet, Linux runtime or performance qualification claim.',
            'The included saved GitHub record reports nine successful checks for the pinned code commit only; no later CI outcome is inferred.',
            'All-copy write receipts are explicit for Wire stores. Native legacy bulk copy counts remain separate from four final physical-copy inspections.',
            'Dependency/runtime binary snapshots are omitted from the archive; their original hashes remain in unmodified reports.']};
    const manifest = {schemaVersion: 1, codeCommit: expectedCommit, reviewedCandidateSha256: expectedPatch, files: manifestFiles, omittedAliases};
    const finalHashes = {};
    for (const [name, value] of [['summary.json', summary], ['manifest.json', manifest]]) {
        const bytes = Buffer.from(JSON.stringify(value, null, 2) + '\n'); await writeFile(join(destination, name), bytes, {flag: 'wx'}); finalHashes[name] = sha(bytes);
    }
    finalHashes['raw-evidence.tar.gz'] = sha(archiveBytes);
    const attributes = Buffer.from('raw-evidence.tar.gz -text\n*.json text eol=lf\n*.md text eol=lf\nSHA256SUMS text eol=lf\n.gitattributes text eol=lf\n');
    await writeFile(join(destination, '.gitattributes'), attributes, {flag: 'wx'}); finalHashes['.gitattributes'] = sha(attributes);
    await writeFile(join(destination, 'SHA256SUMS'), Object.entries(finalHashes).map(([name, hash]) => `${hash}  ${name}\n`).join(''), {flag: 'wx'});
    return {destination, files: manifestFiles.length, bytes: total, archiveSha256: sha(archiveBytes), reports: reports.length, resourceSets: cleanup.length};
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
    assert.equal(process.argv.length, 5, 'usage: node package-issue230-evidence.mjs CODE_REPO NEW_STAGE DESTINATION');
    console.log(JSON.stringify(await packageEvidence({codeRepo: process.argv[2], stage: process.argv[3], destination: process.argv[4]})));
}
