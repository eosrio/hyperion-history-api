import {createRequire} from 'node:module';
const require=createRequire(new URL('./package.json',import.meta.url));
const result={runtime:process.versions,execPath:process.execPath,modules:[]};
for(const name of ['@eosrio/node-abieos','uWebSockets.js']){try{require(name);result.modules.push({name,status:'loaded'});}catch(e){result.modules.push({name,status:'failed',message:e.message,stack:e.stack});}}
console.log(JSON.stringify(result,null,2));
