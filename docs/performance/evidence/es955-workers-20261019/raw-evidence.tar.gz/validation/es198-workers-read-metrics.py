import runpy,json,pathlib
s=pathlib.Path(r'C:\Users\igorl\.codex\scratch');m=runpy.run_path(str(s/'es198-workers-package.py'))
rows=[]
for label in ['control','profile']:
 d=s/f'es198-workers-node-{label}-final';r=m['read_json'](d/'report.json');rows.append(m['summarize_final'](r,d,label))
(s/'es198-workers-final-metrics.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
for r in rows:
 print(json.dumps({k:v for k,v in r.items() if k not in ['workers','server']},indent=2))
