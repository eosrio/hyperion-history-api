from pathlib import Path
repo=Path(r'C:\Users\igorl\.codex\worktrees\hyperion45-profiling\hyperion-tools')
p=repo/'docs/research/elasticsearch-9.5.5.md';t=p.read_text(encoding='utf-8');start=t.index('### Sustained load and full-worker checkpoint:');end=t.index('## Relevant changes and qualification cases',start)
s='''### Sustained load and full-worker checkpoint: 2026-10-19

The preceding slice is merged: [API #204](https://github.com/eosrio/hyperion-history-api/commit/c00cf9682b93fb2b71a7976b3fd7086cd9b0dacc),
[API #205](https://github.com/eosrio/hyperion-history-api/commit/a08618012869790962cfcf700db682a706004a1b)
and [Tools #34](https://github.com/eosrio/hyperion-tools/commit/60680bf10630a618b773f889b737673950310c4c).
The next finite slice is [API #207](https://github.com/eosrio/hyperion-history-api/pull/207),
with its [immutable measured report](https://github.com/eosrio/hyperion-history-api/blob/API_REPORT_COMMIT/docs/performance/elasticsearch-9.5.5-workers.md)
and [checksummed evidence](https://github.com/eosrio/hyperion-history-api/tree/API_REPORT_COMMIT/docs/performance/evidence/es955-workers-20261019).

Two fresh Node 24.19 fixtures each passed 100 s write, 100 s read and 100 s mixed
windows, plus warmup and three sink-stall/recovery waves. The control verified **48,260**
actions and the profile run **47,700**, with every expected ID/source independently
verified on both data nodes. All **six** waves held the next historical range until
resume while the live reader progressed. All 12 workers and master exited cleanly;
postflight found no surviving observed process, broker connection/message/unacked work
or active ES task/accounting. Each fixture's seven containers, seven volumes and network
were then removed with ownership checks. Failed controls remain excluded and preserved.

The production launcher/master/readers/deserializers/ingestors run against a known-genesis
Spring chain, three ES nodes, RabbitMQ, Redis and MongoDB. Actual SHIP traffic decodes
block headers with traces/deltas disabled. Dense synthetic actions separately enter the
real action-index queue; sorted reads directly query ES. This measures worker cargo,
prefetch, settlement and shared-reader backpressure, without qualifying historical action
decoding, contract projections, served-domain API throughput or retained-index upgrades.
The proxy gates actual bulk **request forwarding before ES dispatch**, then passes real
responses unchanged. This is delayed sink completion, separate from native pressure admission.

Client **8.19.1**, transport **8.10.1** and amqplib **2.0.1** remain pinned, with automatic
UndiciConnection on Node. Production action mappings use four primaries, one replica,
1 s refresh and `global_sequence desc` sorting. Publisher confirms, individual receipt
copy counts and final two-copy verification are recorded separately: warmup included
successful one-copy receipts. This slice does not establish broker/host power-loss durability.

Thirteen real CPU profiles cover the master and every worker through recovery. The
control also runs the observer/proxy; one fresh-fixture profile/control pair cannot
establish collector overhead or a runtime ranking. Query, bulk, queue, CPU/RSS/event-loop,
JVM/GC, pressure, breaker, refresh, merge and storage evidence is retained. Both runs
showed zero native pressure/write rejections and no breaker trips; no native saturation
or production bottleneck was established. Heap accounting recovery is distinct from
returning JVM heap to its initial occupancy or proving leak freedom.

The path exposed [reader prerequisite #206](https://github.com/eosrio/hyperion-history-api/pull/206):
wait for the actual publisher drain, ignore stale closes and resume only unsent cargo
after replacement. Windows imports required file URLs and log filenames needed colon
removal. A fresh native probe again loads node-abieos on Bun **1.4.3** but fails the
pinned uWebSockets import (`napi_register_module_v1`); Node 24 loads both. No full-worker
Bun comparison follows. Remaining confirm/replay semantics are explicitly tracked in
[API #208](https://github.com/eosrio/hyperion-history-api/issues/208), under reliability
[#187](https://github.com/eosrio/hyperion-history-api/issues/187).

Keep [#198](https://github.com/eosrio/hyperion-history-api/issues/198) open for representative
historical/contract/API paths, longer replicated load/overhead controls, large-memory
pressure, worker/broker-loss replay, distributed late-result ordering and retained-history
upgrades. No dependency upgrade, live setting change or deployment follows.

'''
p.write_text(t[:start]+s+t[end:],encoding='utf-8')
p=repo/'docs/performance/hyperion-4.5-profiling.md';t=p.read_text(encoding='utf-8');start=t.index('## Full-worker load checkpoint:');end=t.index('## Fixture and workload prerequisites',start)
s='''## Full-worker load checkpoint: 2026-10-19

[API #207](https://github.com/eosrio/hyperion-history-api/pull/207) adds the next finite
[#198](https://github.com/eosrio/hyperion-history-api/issues/198) experiment after merged
API #204/#205 and Tools #34. Its [immutable report](https://github.com/eosrio/hyperion-history-api/blob/API_REPORT_COMMIT/docs/performance/elasticsearch-9.5.5-workers.md)
and [evidence](https://github.com/eosrio/hyperion-history-api/tree/API_REPORT_COMMIT/docs/performance/evidence/es955-workers-20261019)
record two fresh Node 24.19 executions, each with 300 s of write/read/mixed phases,
plus warmup, three sink stalls and recovery. **95,960 actions** were verified exactly on
both data nodes; all six pause/resume waves and both process/resource cleanups passed.
Thirteen CPU profiles cover the master plus all 12 workers through final recovery.

Actual SHIP block headers traverse the production workers; synthetic action messages
separately feed the real action queue. Traces/deltas, contracts/state projections and
the HTTP API server are outside this run. A proxy gates bulk request forwarding before
ES dispatch; real responses are unchanged. This tests sink-completion delay and the
existing shared-reader policy, rather than native ES pressure admission or a hard queue
cap. The next pending historical range waits for resume while live reading progresses.
Range evidence observes the actual reader method, not packet delivery or full range completion.

| Evidence | Measured coverage |
|---|---|
| Workload/output | 48,260 control and 47,700 profile actions; exact IDs/sources separately checked on both copies; complete sorted pages with a known-visible read baseline |
| CPU/memory/waits | Per-PID CPU/RSS/heap and one-second event-loop samples; 13 saved profiles; backend JVM/GC, breakers, pressure, refresh, merges and storage counters |
| Recovery/cleanup | Three waves per run, live progress, no next range while paused, exact pending range invoked after resume; idle accounting and no surviving processes/broker work; all owned fixture resources removed |
| Validation | 222 unit tests, whole-project/runner Bun typechecks, TS7 build, 11 mocked lifecycle cases and 87 real observation/profile/shutdown assertions |

The control retains observer/proxy instrumentation. One sequential profile/control pair
with fresh clusters and uncontrolled host workloads cannot attribute overhead or rank
runtimes/capacity. Zero native rejection/breaker trips at this offered rate do not prove
headroom, leak freedom or a production bottleneck. Preserve the archived CPU profiles
and latency distributions as diagnostic evidence, then qualify representative dense
historical data through #195/#196 before prioritizing throughput changes.

[Reader fix #206](https://github.com/eosrio/hyperion-history-api/pull/206) and portable
Windows imports/log filenames unblock this path. Remaining negative/unknown confirms
and reader replay belong to [#208](https://github.com/eosrio/hyperion-history-api/issues/208)
and #187. Bun 1.4.3 still fails the pinned uWebSockets native import on this host, despite
node-abieos loading; there is no full-worker Bun comparison. Longer soaks, contract/API
paths, worker-loss replay, large-memory pressure and retained-index acceptance remain open.

'''
p.write_text(t[:start]+s+t[end:],encoding='utf-8')
print('Updated two measured checkpoint sections; immutable API commit placeholder remains until report commit.')
