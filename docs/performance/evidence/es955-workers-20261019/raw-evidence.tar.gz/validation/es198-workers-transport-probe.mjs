import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {esConnectionOptions} from './build/indexer/helpers/es-connection.js';
const require=createRequire(import.meta.url);const {Client,UndiciConnection,HttpConnection}=require('@elastic/elasticsearch');
const client=new Client({node:'http://127.0.0.1:9',...esConnectionOptions()});
const version=name=>JSON.parse(readFileSync(new URL('./node_modules/'+name+'/package.json',import.meta.url),'utf8')).version;
console.log(JSON.stringify({runtime:process.version,httpConnectionOverride:process.env.ES_HTTP_CONNECTION??null,client:version('@elastic/elasticsearch'),transport:version('@elastic/transport'),connection:client.connectionPool.connections[0].constructor.name,isUndiciConnection:client.connectionPool.connections[0] instanceof UndiciConnection,isHttpConnection:client.connectionPool.connections[0] instanceof HttpConnection,requestSent:false},null,2));
await client.close();

