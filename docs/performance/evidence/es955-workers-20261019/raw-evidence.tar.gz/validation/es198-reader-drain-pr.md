State readers could continue publishing 500 ms after `sendToQueue(false)` without waiting for the confirm channel to drain. Wait on the actual publisher, keep cargo pending until writable, and guard channel readiness against stale closes.

A replacement publisher also resumes the active cargo's unsent remainder after queue setup, releasing a confirmed final-message batch exactly once. Accepted messages are never blindly republished. The regressions cover real inherited `onConnect`, repeated pressure, replacement while waiting, and late close/drain/confirm events.

Validation: six focused reader/cargo/lifecycle regressions, whole-project Bun typecheck and TS7 build pass. The qualification branch's full suite passes 222 tests, including the new harness tests. Independent Spec review found no remaining issue and additionally tested consecutive replacements. Controlled channels execute actual production methods; unknown/nack confirmation recovery and source replay durability remain separate work.

Related: #198.
