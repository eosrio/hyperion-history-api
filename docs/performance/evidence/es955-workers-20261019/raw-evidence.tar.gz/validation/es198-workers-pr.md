This adds a guarded full-worker fixture and sustained Elasticsearch 9.5.5 qualification runner for #198. The actual production master, backfill/live readers, deserializers and ingestors run against owned Spring, Redis, MongoDB, RabbitMQ and three-node Elasticsearch instances. Dense synthetic actions enter the real indexing queue separately from actual SHIP block traffic.

Three controlled sink stalls require actual queue-budget pause/resume IPC, a pending backfill range held until resume, continued live progress, exact documents on both data nodes, recovered accounting and complete worker shutdown. CI checks fixture cleanup, observation/profile shutdown and query/pause oracles. Portable filesystem imports and valid log filenames unblock the production worker launcher on Windows.

Draft while the two fresh five-minute control/profile runs and checksummed evidence are being completed. Local validation: 222 unit tests, whole-project/runner Bun typechecks, TS7 build, 11 mocked fixture lifecycle cases and 87 real observer assertions pass. Includes the reader prerequisite from #206 until it merges. This does not qualify Bun full-worker support, production throughput, native ES saturation, plugin paths or retained-index upgrades.

Related: #198.
