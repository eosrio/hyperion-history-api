import {assertSortedPage,loadDocument} from 'file:///C:/Users/igorl/.codex/worktrees/hyperion45-es955/hyperion-history-api/scripts/qualification/es955-workers.ts';
assertSortedPage({timed_out:false,_shards:{failed:0},hits:{hits:[]}},4000,'review');
assertSortedPage({timed_out:false,_shards:{failed:0},hits:{hits:[{_id:'1',_source:loadDocument(1,'review')}] }},4000,'review');
console.log('Both empty and arbitrarily incomplete seeded read pages accepted');
