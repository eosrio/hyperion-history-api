param(
    [Parameter(Mandatory)][string]$StateFile,
    [Parameter(Mandatory)][string[]]$ReportDirectory,
    [Parameter(Mandatory)][string]$OutputFile
)
$ErrorActionPreference='Stop'
if (-not $IsWindows) { throw 'This postflight process audit requires Windows CIM' }
$StateFile=(Resolve-Path -LiteralPath $StateFile).Path
$OutputFile=[IO.Path]::GetFullPath($OutputFile)
$stateBytes=[IO.File]::ReadAllBytes($StateFile)
$state=[Text.Encoding]::UTF8.GetString($stateBytes)|ConvertFrom-Json
if ($state.status -ne 'ready' -or $state.run -notmatch '^[a-f0-9]{12}$' -or
    $state.network -ne "hyp-es955-replicas-$($state.run)" -or $state.core.run -ne $state.run) { throw 'Invalid ready fixture manifest' }
$stream=[IO.File]::Open($OutputFile,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
$record=[ordered]@{schemaVersion=1;status='running';startedAt=[DateTime]::UtcNow.ToString('o');run=$state.run;
    fixtureManifest=$StateFile;fixtureManifestSha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stateBytes)).ToLowerInvariant();
    scriptSha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant();
    scope='Read-only pre-cleanup observation. This script never terminates qualification masters/workers or removes fixture resources. A timed-out Docker read-only client helper may be stopped.';
    cleanupReceiptPath=$StateFile+'.cleanup.json';reports=@();processes=@();containers=@();volumes=@();network=$null;samples=@()}
function Invoke-PostflightDocker([string[]]$Arguments) {
    $psi=[Diagnostics.ProcessStartInfo]::new('docker')
    $psi.UseShellExecute=$false; $psi.CreateNoWindow=$true; $psi.RedirectStandardOutput=$true; $psi.RedirectStandardError=$true
    foreach($argument in $Arguments){$psi.ArgumentList.Add($argument)}
    $process=[Diagnostics.Process]::new(); $process.StartInfo=$psi
    try {
        if(-not $process.Start()){throw 'Docker command failed to start'}
        $stdout=$process.StandardOutput.ReadToEndAsync(); $stderr=$process.StandardError.ReadToEndAsync()
        if(-not $process.WaitForExit(10000)){
            $process.Kill($true); $process.WaitForExit(); throw "Docker read-only command timed out: $($Arguments[0])"
        }
        $text=$stdout.GetAwaiter().GetResult(); $errorText=$stderr.GetAwaiter().GetResult()
        if($process.ExitCode -ne 0){throw "Docker read-only command failed: $($Arguments[0]): $errorText"}
        if($text.Length -gt 16777216){throw 'Docker response exceeds postflight evidence bound'}
        return $text.Trim()
    } finally { $process.Dispose() }
}
function Assert-LoopbackBinding($Inspect,[string]$Port,[string]$Url) {
    $parsed=[uri]$Url; $bindings=@($Inspect.NetworkSettings.Ports.$Port)
    if($parsed.Host -ne '127.0.0.1' -or $bindings.Count -ne 1 -or
        $bindings[0].HostIp -ne '127.0.0.1' -or [string]$parsed.Port -ne [string]$bindings[0].HostPort){throw 'Endpoint is not the exact owned loopback binding'}
}
function Assert-CompleteStats($Stats) {
    if($Stats._nodes.total -ne 3 -or $Stats._nodes.successful -ne 3 -or $Stats._nodes.failed -ne 0 -or
        @($Stats.nodes.psobject.Properties).Count -ne 3){throw 'Incomplete postflight node statistics'}
}
function Convert-PostflightJsonArray([string]$Json) {
    $items=ConvertFrom-Json -InputObject $Json -NoEnumerate
    if($null -eq $items -or $items -isnot [array]) { throw 'Expected a complete REST JSON array' }
    # Preserve the array object, including [], without wrapping it in another array.
    return ,$items
}
function Test-IdleStats($Stats) {
    Assert-CompleteStats $Stats
    foreach($property in $Stats.nodes.psobject.Properties){
        $node=$property.Value
        foreach($value in @($node.indexing_pressure.memory.current.all_in_bytes,$node.indices.indexing.index_current,
            $node.indices.search.open_contexts,$node.indices.search.query_current,$node.indices.search.fetch_current,
            $node.thread_pool.write.active,$node.thread_pool.write.queue,
            $node.thread_pool.write_coordination.active,$node.thread_pool.write_coordination.queue)){
            if($null -eq $value){throw 'Postflight node idle counter missing'}
            if($value -ne 0){return $false}
        }
    }
    return $true
}
try {
    $knownPids=@{}; $chains=@(); $starts=@{}
    $directories=@($ReportDirectory | ForEach-Object {(Resolve-Path -LiteralPath $_).Path} | Sort-Object -Unique)
    if($directories.Count -lt 1 -or $directories.Count -gt 16){throw 'Report directory count exceeds postflight bounds'}
    foreach($directory in $directories){
        $reportPath=Join-Path $directory 'report.json'
        $report=Get-Content -LiteralPath $reportPath -Raw | ConvertFrom-Json
        if($report.state.run -ne $state.run -or $report.state.core.clusterUuid -ne $state.core.clusterUuid){throw 'Report belongs to another fixture'}
        if($report.chain){$chains+=@([string]$report.chain)}
        if($report.masterPid){$knownPids[[int]$report.masterPid]=$true}
        $observations=@(); $observerDirectory=Join-Path $directory 'observer'
        $files=@(Get-ChildItem -LiteralPath $observerDirectory -File -Filter 'worker-*.jsonl')
        if($files.Count -gt 128){throw 'Observer file count exceeds postflight bounds'}
        foreach($file in $files){
            if($file.Length -gt 25165824){throw 'Observer file exceeds declared observer bound'}
            foreach($line in [IO.File]::ReadLines($file.FullName)){
                if($line -notmatch '^\{"kind":"(?:start|worker_fork|shutdown_late_child|worker_exit|shutdown)"'){continue}
                $event=$line|ConvertFrom-Json
                if($event.pid){$knownPids[[int]$event.pid]=$true}
                if($event.childPid){$knownPids[[int]$event.childPid]=$true}
                if($event.kind -eq 'start'){
                    if($event.cwd -ne $directory){throw 'Observer belongs to another output directory'}
                    $starts[[int]$event.pid]=$event
                }
            }
            $observations+=@(@{file=$file.FullName;sizeBytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()})
        }
        $record.reports+=@(@{directory=$directory;reportStatus=$report.status;chain=$report.chain;masterPid=$report.masterPid;
            reportSha256=(Get-FileHash -LiteralPath $reportPath -Algorithm SHA256).Hash.ToLowerInvariant();
            observerFiles=$observations;recordedShutdown=$report.cleanup|Where-Object {$_.name -eq 'workers'}})
    }
    if($knownPids.Count -lt 1 -or $knownPids.Count -gt 256){throw 'Missing or excessive observed process identities'}
    $filter=(@($knownPids.Keys|Sort-Object)|ForEach-Object {"ProcessId=$_"}) -join ' OR '
    $live=@(Get-CimInstance Win32_Process -Filter $filter -OperationTimeoutSec 10)
    $alive=@{}; foreach($process in $live){$alive[[int]$process.ProcessId]=$process}
    $survivors=@()
    foreach($processId in @($knownPids.Keys|Sort-Object)){
        $current=$alive[$processId]; $start=$starts[$processId]
        $entry=@{pid=$processId;observerStart=if($start){$start.isoAt}else{$null};role=if($start){$start.role}else{$null};status='gone'}
        if($current){
            $entry.currentCreationTime=$current.CreationDate.ToUniversalTime().ToString('o')
            # Do not publish unrelated command lines if Windows has reused a PID.
            $reused=$start -and ($current.CreationDate.ToUniversalTime() -gt ([datetime]$start.isoAt).ToUniversalTime().AddSeconds(10))
            if($reused){$entry.status='pid-reused-by-newer-process'}else{
                $entry.status='surviving-observed-process'; $entry.name=$current.Name; $entry.commandLine=$current.CommandLine
                $survivors+=@($processId)
            }
        }
        $record.processes+=@($entry)
    }
    $record.observedProcessCount=$knownPids.Count; $record.survivingObservedProcesses=$survivors
    if($survivors.Count){throw 'Observed master/worker processes remain alive'}
    $resources=@()
    foreach($node in $state.core.nodes){$resources+=@(@{item=$node;label='es198-replicas';image=$state.core.esImage;ports=@{'9200/tcp'=$node.url}})}
    $resources+=@(@{item=$state.core.broker;label='es198-replicas';image=$state.core.rabbitImage;
        ports=@{'5672/tcp'=$state.core.broker.url;'15672/tcp'=$state.core.broker.managementUrl}})
    foreach($kind in @('redis','mongo','spring')){
        $item=$state.$kind
        $ports=switch($kind){'redis'{@{'6379/tcp'=$item.url}};'mongo'{@{'27017/tcp'=$item.url}};'spring'{@{'8888/tcp'=$item.httpUrl;'8080/tcp'=$item.shipUrl}}}
        $resources+=@(@{item=$item;label='es198-workers';image=$state.($kind+'Image');ports=$ports})
    }
    $expectedIds=@(); $expectedVolumes=@()
    foreach($resource in $resources){
        $item=$resource.item
        $inspect=@((Invoke-PostflightDocker @('inspect',$item.containerId))|ConvertFrom-Json)[0]
        if($inspect.Id -ne $item.containerId -or $inspect.Name -ne '/'+$item.name -or $inspect.Config.Image -ne $resource.image -or
            $inspect.Config.Labels.'io.eosrio.run' -ne $state.run -or $inspect.Config.Labels.'io.eosrio.qualifier' -ne $resource.label -or
            -not $inspect.State.Running){throw 'Owned fixture container identity/state mismatch'}
        if(-not @($inspect.Mounts|Where-Object {$_.Type -eq 'volume' -and $_.Name -eq $item.volume}).Count){throw 'Owned data volume mount missing'}
        foreach($port in $resource.ports.Keys){Assert-LoopbackBinding $inspect $port $resource.ports[$port]}
        $record.containers+=@($inspect); $expectedIds+=@($inspect.Id); $expectedVolumes+=@($item.volume)
        $volume=@((Invoke-PostflightDocker @('volume','inspect',$item.volume))|ConvertFrom-Json)[0]
        if($volume.Labels.'io.eosrio.run' -ne $state.run -or $volume.Labels.'io.eosrio.qualifier' -ne $resource.label){throw 'Owned fixture volume identity mismatch'}
        $record.volumes+=@($volume)
    }
    $inventory=@((Invoke-PostflightDocker @('ps','-a','--no-trunc','--filter',"label=io.eosrio.run=$($state.run)",'--format','{{.ID}}')) -split "`r?`n" | Where-Object {$_})
    $volumeInventory=@((Invoke-PostflightDocker @('volume','ls','--filter',"label=io.eosrio.run=$($state.run)",'--format','{{.Name}}')) -split "`r?`n" | Where-Object {$_})
    if(@(Compare-Object ($expectedIds|Sort-Object) ($inventory|Sort-Object)).Count -or
        @(Compare-Object ($expectedVolumes|Sort-Object) ($volumeInventory|Sort-Object)).Count){throw 'Unplanned or missing run-labelled resources'}
    $network=@((Invoke-PostflightDocker @('network','inspect',$state.network))|ConvertFrom-Json)[0]
    if($network.Labels.'io.eosrio.run' -ne $state.run -or $network.Labels.'io.eosrio.qualifier' -ne 'es198-replicas'){throw 'Fixture network ownership mismatch'}
    foreach($endpoint in $network.Containers.psobject.Properties){if($endpoint.Name -notin $expectedIds){throw 'Unexpected fixture network endpoint'}}
    $record.network=$network
    $url=$state.core.nodes[0].url; $info=Invoke-RestMethod $url -TimeoutSec 5
    if($info.cluster_uuid -ne $state.core.clusterUuid -or $info.cluster_name -ne $state.core.clusterName -or $info.version.number -ne '9.5.5'){throw 'Elasticsearch identity changed'}
    $record.cluster=$info
    $brokerUri=[uri]$state.core.broker.url; $credentials=[uri]::UnescapeDataString($brokerUri.UserInfo)
    if($credentials -ne 'qualifier:qualifier-test-only'){throw 'Unexpected fixture broker credentials'}
    $headers=@{Authorization='Basic '+[Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($credentials))}
    $management=$state.core.broker.managementUrl
    $record.brokerOverview=Invoke-RestMethod "$management/api/overview" -Headers $headers -TimeoutSec 5
    $record.brokerNodes=Invoke-RestMethod "$management/api/nodes" -Headers $headers -TimeoutSec 5
    if($record.brokerOverview.rabbitmq_version -ne '4.3.4'){throw 'Unexpected RabbitMQ version'}
    $consecutive=0; $deadline=[DateTime]::UtcNow.AddSeconds(20)
    do {
        $tasks=Invoke-RestMethod "$url/_tasks?actions=indices:data/write/bulk*,indices:data/read/search*&group_by=none" -TimeoutSec 5
        if($null -eq $tasks.tasks -or $tasks.node_failures -or $tasks.task_failures){throw 'Incomplete ungrouped task listing'}
        $stats=Invoke-RestMethod "$url/_nodes/stats/indexing_pressure,thread_pool,breaker,indices,jvm,process" -TimeoutSec 5
        $queues=Convert-PostflightJsonArray (Invoke-WebRequest "$management/api/queues" -Headers $headers -TimeoutSec 5).Content
        $connections=Convert-PostflightJsonArray (Invoke-WebRequest "$management/api/connections" -Headers $headers -TimeoutSec 5).Content
        $queueIdle=$true
        foreach($queue in $queues){
            foreach($field in @('messages','messages_ready','messages_unacknowledged')){
                if($null -eq $queue.$field){throw 'Incomplete Rabbit queue accounting'}
                if($queue.$field -ne 0){$queueIdle=$false}
            }
        }
        $taskCount=@($tasks.tasks|Where-Object {$_}).Count
        $idle=(Test-IdleStats $stats) -and $taskCount -eq 0 -and $queueIdle -and $connections.Count -eq 0
        $record.samples+=@(@{at=[DateTime]::UtcNow.ToString('o');idle=$idle;tasks=$tasks;stats=$stats;
            brokerQueues=$queues;brokerConnections=$connections;remainingTasks=$taskCount;remainingQueues=$queues.Count;remainingBrokerConnections=$connections.Count})
        if($idle){$consecutive++}else{$consecutive=0}
        if($consecutive -ge 3){break}
        Start-Sleep -Milliseconds 500
    } while([DateTime]::UtcNow -lt $deadline)
    if($consecutive -lt 3){throw 'Postflight work/pressure/broker accounting did not become idle'}
    $record.consecutiveIdleSamples=$consecutive
    $record.durableEmptyQueuesRemain=$record.samples[-1].remainingQueues
    $record.status='passed'
} catch { $record.status='failed'; $record.error=$_.Exception.ToString() }
finally {
    $record.completedAt=[DateTime]::UtcNow.ToString('o')
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($record|ConvertTo-Json -Depth 65)+"`n")
    $stream.Write($bytes); $stream.Flush($true); $stream.Dispose()
}
if($record.status -ne 'passed'){throw "Postflight failed; retained exact observations in $OutputFile : $($record.error)"}
Write-Output "Postflight passed: $($record.observedProcessCount) observed PIDs gone/reused; three idle samples; $($record.durableEmptyQueuesRemain) empty durable queues retained for fixture cleanup."
