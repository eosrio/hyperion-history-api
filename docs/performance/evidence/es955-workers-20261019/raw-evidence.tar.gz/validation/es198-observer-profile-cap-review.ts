import {spawn} from 'node:child_process';
import {mkdtempSync,mkdirSync,writeFileSync,readdirSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const dir=mkdtempSync(join(tmpdir(),'es198-observer-review-'));
try {
 mkdirSync(join(dir,'observer')); mkdirSync(join(dir,'config'));
 writeFileSync(join(dir,'chain.json'),JSON.stringify({settings:{chain:'review'},indexer:{}}));
 writeFileSync(join(dir,'config','connections.json'),'{}');
 const observer='file:///C:/Users/igorl/.codex/worktrees/hyperion45-es955/hyperion-history-api/scripts/qualification/es955-worker-observer.mjs';
 const exe='C:/Users/igorl/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe';
 const child=spawn(exe,['--import',observer,'--eval',"setTimeout(()=>process.emit('message',{event:'qualifier_shutdown'}),3500)"],{cwd:dir,env:{...process.env,CONFIG_JSON:join(dir,'chain.json'),ES198_OBSERVER_DIR:join(dir,'observer'),ES198_CPU_PROFILE:'1',ES198_PROFILE_MAX_MS:'1000'},stdio:['ignore','pipe','pipe']});
 let stderr=''; child.stderr.on('data',v=>stderr+=v);
 const code=await new Promise(resolve=>child.on('exit',resolve));
 const rows=readdirSync(join(dir,'observer')).filter(p=>p.endsWith('.jsonl')).flatMap(p=>readFileSync(join(dir,'observer',p),'utf8').trim().split('\n').map(JSON.parse));
 console.log(JSON.stringify({code,stderr,flush:rows.filter(r=>r.kind==='flush').map(r=>({reason:r.reason,success:r.success,atMs:r.monotonicMs})),samples:rows.filter(r=>r.kind==='sample').map(r=>({reason:r.reason,atMs:r.monotonicMs})),exit:rows.find(r=>r.kind==='exit')?.monotonicMs},null,2));
} finally {rmSync(dir,{recursive:true,force:true});}
