import nodeAssert from 'node:assert/strict';
import { fork } from 'node:child_process';
import cluster from 'node:cluster';
import http from 'node:http';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const repository = 'C:/Users/igorl/.codex/worktrees/hyperion45-es955/hyperion-history-api';
let assertions = 0;
const assert = new Proxy(nodeAssert, { get(target, property) {
    const value = target[property];
    return typeof value === 'function' ? (...args) => { assertions++; return value(...args); } : value;
} });
const observer = `${repository}/scripts/qualification/es955-worker-observer.mjs`;
const source = fileURLToPath(import.meta.url);
const url = path => new URL(`file:///${repository}/${path}`).href;

if (process.env.ES198_SMOKE === 'master') {
    cluster.setupPrimary({ exec: source, execArgv: process.execArgv });
    const worker = cluster.fork({ ES198_SMOKE: 'worker', worker_role: 'reader', worker_id: '1' });
    if (process.env.ES198_LATE_TEST === '1') process.on('message', message => {
        if (message?.event === 'qualifier_shutdown') setTimeout(() => {
            cluster.fork({ ES198_SMOKE: 'worker', worker_role: 'reader', worker_id: '2' });
        }, 25);
    });
    const { ConnectionManager } = await import(url('build/indexer/connections/manager.class.js'));
    const queue = await ConnectionManager.prototype.checkQueueSize.call({ conn: { amqp: {
        protocol: 'http', api: `127.0.0.1:${process.env.ES198_HTTP_PORT}`, user: 'fixture', pass: 'fixture', vhost: '/'
    } } }, 'fixture:queue');
    assert.equal(queue, 7);
    worker.once('message', message => {
        if (message.event !== 'ready') return;
        const sent = worker.send({ event: 'pause', marker: 'unchanged' }, undefined, undefined, error => {
            assert.ifError(error);
            process.send({ event: 'master_ready', queue, sendReturnBoolean: typeof sent === 'boolean' });
        });
    });
    setInterval(() => {}, 1000);
} else if (process.env.ES198_SMOKE === 'worker') {
    const { default: StateReader } = await import(url('build/indexer/workers/state-reader.js'));
    const reader = { baseRequest: {}, shipRev: 'v0', ship: { connected: false } };
    const returned = StateReader.prototype.requestBlockRange.call(reader, '17', '25');
    assert.equal(returned, undefined);
    assert.equal(reader.baseRequest.start_block_num, 17);
    assert.equal(reader.baseRequest.end_block_num, 25);
    process.on('message', message => {
        if (message.event === 'qualifier_shutdown' && process.env.ES198_LATE_TEST === '1' && process.env.worker_id === '1') {
            const until = Date.now() + 200;
            while (Date.now() < until) {}
        }
        if (message.event === 'pause') {
            assert.equal(message.marker, 'unchanged');
            process.send({ event: 'read_block', block_num: 17, id: '1' });
        }
    });
    process.send({ event: 'ready' });
    setInterval(() => {}, 1000);
} else {
    const directory = mkdtempSync(join(tmpdir(), 'es198-observer-'));
    const configDirectory = join(directory, 'config');
    mkdirSync(configDirectory);
    const config = join(directory, 'fixture.json');
    writeFileSync(config, JSON.stringify({ settings: { chain: 'fixture', parser: '3.2' }, indexer: {}, scaling: {}, plugins: {} }));
    writeFileSync(join(configDirectory, 'connections.json'), JSON.stringify({ chains: { fixture: { chain_id: '0'.repeat(64) } } }));
    let requests = 0;
    const server = http.createServer((request, response) => {
        assert.equal(request.url, '/api/queues/%2F/fixture%3Aqueue');
        requests++;
        response.setHeader('Content-Type', 'application/json');
        response.end(JSON.stringify({ messages: 7 }));
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const child = fork(source, [], {
        cwd: directory, execArgv: ['--import', pathToFileURL(observer).href],
        env: { ...process.env, ES198_SMOKE: 'master', ES198_OBSERVER_DIR: directory,
            ES198_CPU_PROFILE: '1', CONFIG_JSON: config, ES198_HTTP_PORT: String(server.address().port) },
        stdio: ['ignore', 'pipe', 'pipe', 'ipc']
    });
    let stderr = '';
    child.stderr.on('data', chunk => { stderr += chunk; });
    child.stdout.resume();
    const messages = [];
    child.on('message', message => messages.push(message));
    const exit = new Promise(resolve => child.once('exit', (code, signal) => resolve({ code, signal })));
    const deadline = Date.now() + 15000;
    try {
        while (!messages.some(message => message.event === 'master_ready') && Date.now() < deadline) {
            await new Promise(resolve => setTimeout(resolve, 25));
        }
        assert.ok(messages.some(message => message.event === 'master_ready'), stderr);
        await new Promise(resolve => setTimeout(resolve, 2300));
        child.send({ event: 'qualifier_flush', requestId: 'smoke-flush' });
        while (readdirSync(directory).filter(name => name.endsWith('.cpuprofile')).length < 2 && Date.now() < deadline) {
            await new Promise(resolve => setTimeout(resolve, 25));
        }
        child.send({ event: 'qualifier_shutdown', requestId: 'smoke-shutdown' });
        const exited = await Promise.race([exit, new Promise((_, reject) => setTimeout(() => reject(new Error('Shutdown timeout')), 10000).unref())]);
        assert.deepEqual(exited, { code: 0, signal: null }, stderr);
        assert.equal(requests, 1);
        const files = readdirSync(directory).filter(name => name.endsWith('.jsonl'));
        const expectedProcesses = process.env.ES198_LATE_TEST === '1' ? 3 : 2;
        assert.equal(files.length, expectedProcesses);
        const records = files.flatMap(name => readFileSync(join(directory, name), 'utf8').trim().split('\n').map(JSON.parse));
        for (const role of ['master', 'reader']) {
            assert.ok(records.some(row => row.kind === 'start' && row.role === role));
            assert.ok(records.filter(row => row.kind === 'sample' && row.role === role).length >= 3);
            assert.ok(records.some(row => row.kind === 'profile_saved' && row.role === role));
            assert.ok(records.some(row => row.kind === 'flush' && row.role === role && row.success));
            assert.ok(records.some(row => row.kind === 'shutdown' && row.role === role && row.success));
        }
        assert.ok(records.every(row => Number.isFinite(row.at)));
        assert.ok(records.some(row => row.kind === 'queue_sample' && row.queue === 'fixture:queue' && row.size === 7));
        assert.ok(records.some(row => row.kind === 'ipc_send' && row.event === 'pause' && row.role === 'reader'));
        assert.ok(records.some(row => row.kind === 'ipc_receive' && row.event === 'read_block' && row.role === 'reader'));
        assert.ok(records.some(row => row.kind === 'ship_range_request' && row.role === 'reader' && row.first_block === '17' && row.last_block === '25'));
        if (process.env.ES198_LATE_TEST === '1') {
            assert.ok(records.some(row => row.kind === 'shutdown_late_child'));
            assert.ok(records.some(row => row.kind === 'shutdown' && row.role === 'master' && row.children === 2 && row.exited === 2 && row.unresolved.length === 0));
        }
        for (const name of readdirSync(directory).filter(name => name.endsWith('.cpuprofile'))) {
            const profile = JSON.parse(readFileSync(join(directory, name), 'utf8'));
            assert.ok(profile.nodes.length > 0);
            assert.ok(profile.samples.length > 0);
        }
        assert.equal(stderr, '');
        console.log(JSON.stringify({ status: 'passed', parentAssertions: assertions, directory, processes: expectedProcesses, profiles: expectedProcesses, requests, records: records.length }));
    } finally {
        if (child.exitCode === null) child.kill();
        server.close();
    }
}
