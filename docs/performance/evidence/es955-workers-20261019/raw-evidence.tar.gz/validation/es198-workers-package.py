"""Freeze completed ES198 worker evidence; never run against an active measurement.

Usage: python es198-workers-package.py --repo REPO --scratch SCRATCH --destination DEST
The two final runs and their fresh fixture postflight/cleanup receipts are mandatory.
All archive inputs remain byte-for-byte unchanged. No recursive deletion is used.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import uuid


MAX_FILE = 512 * 1024 * 1024
MAX_TOTAL = 4 * 1024 * 1024 * 1024
MAX_MEMBERS = 8192
LIMITS = [
    "Dense actions enter the actual durable Rabbit indexing queue; this does not measure SHIP action decoding throughput.",
    "Actual genesis blocks traverse production master, reader, deserializer and indexer processes.",
    "The bulk proxy gates forwarding of bulk requests before dispatch to Elasticsearch. Actual upstream responses remain unchanged after release; the controlled stall does not establish native Elasticsearch saturation or delayed post-ES acknowledgments.",
    "Publisher confirms, proxy request-to-response timings (including any pre-dispatch gate), database receipt copies, and final physical-copy reads are distinct observations.",
    "No true broker-delivery-to-Elasticsearch per-item acknowledgment latency was instrumented.",
    "Profiling and observer overhead, distinct fresh fixtures, and other host workloads preclude runtime/capacity rankings.",
    "Bounded recovery observations do not establish heap-leak freedom, production capacity, long-duration stability or full-chain replay acceptance.",
    "The archived fixture password and producer key are known test-only credentials. Raw artifacts are not rewritten or sanitized.",
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path):
    require(path.is_file() and 0 < path.stat().st_size <= MAX_FILE, f"Missing, empty or excessive JSON input: {path}")
    return json.loads(path.read_bytes())


def bounded_path(path, parent):
    path = Path(path)
    require(not path.is_symlink() and not path.is_junction(), f"Link input is unsupported: {path}")
    resolved = path.resolve()
    require(resolved.is_relative_to(parent) and resolved != parent, f"Input escapes bounded root: {path}")
    return resolved


def owned_symlink_metadata(path, directory):
    """Describe a relative file link without archiving/following the link itself."""
    path = Path(path)
    directory = Path(directory).resolve()
    require(path.is_symlink() and not path.is_junction(), f"Expected a file symlink: {path}")
    literal = os.readlink(path)
    require(not Path(literal).is_absolute() and not Path(literal).drive, f"Absolute link target is unsupported: {path}")
    # abspath collapses '..' lexically; it does not resolve or read symlink targets.
    target = Path(os.path.abspath(os.path.join(path.parent, literal)))
    require(target.is_relative_to(directory) and target != directory, f"Symlink target escapes owned run: {path}")
    for component in [target] + list(target.parents):
        if component == directory:
            break
        require(not component.is_symlink() and not component.is_junction(), f"Chained symlink/junction target is unsupported: {path}")
    exists = target.exists()
    require(not exists or target.is_file(), f"Symlink target is not a regular file: {path}")
    return {"path": path.relative_to(directory).as_posix(), "literalTarget": literal,
            "resolvedRelativeTarget": target.relative_to(directory).as_posix(), "targetExists": exists,
            "targetSha256": file_sha(target) if exists else None,
            "representation": "metadata only; no extractable link is emitted"}


def distribution(values):
    values = sorted(float(value) for value in values if isinstance(value, (int, float)) and math.isfinite(value))
    if not values:
        return {"count": 0}

    def percentile(q):
        position = (len(values) - 1) * q
        lo = math.floor(position)
        hi = math.ceil(position)
        return values[lo] + (values[hi] - values[lo]) * (position - lo)

    return {"count": len(values), "min": values[0], "mean": sum(values) / len(values),
            "p50": percentile(.50), "p95": percentile(.95), "p99": percentile(.99), "max": values[-1]}


def at(value, *keys):
    for key in keys:
        if not isinstance(value, dict) or key not in value:
            return None
        value = value[key]
    return value


def delta(first, last):
    if not isinstance(first, (int, float)) or not isinstance(last, (int, float)):
        return None
    require(last >= first, "A supposedly cumulative server counter reset during the run")
    return last - first


class Archive:
    def __init__(self, repo, scratch):
        self.repo = repo
        self.scratch = scratch
        self.members = {}
        self.total = 0

    def add(self, name, path=None, data=None, role="", status=None, run=None):
        part = PurePosixPath(name)
        require(not part.is_absolute() and ".." not in part.parts and "\\" not in name, f"Unsafe archive name: {name}")
        require(name not in self.members, f"Duplicate archive member: {name}")
        require((path is None) != (data is None), "A member needs exactly one source")
        if path is not None:
            path = Path(path)
            allowed = self.repo if path.resolve().is_relative_to(self.repo) else self.scratch
            path = bounded_path(path, allowed)
            require(path.is_file(), f"Missing evidence file: {path}")
            size = path.stat().st_size
            digest = file_sha(path)
        else:
            size = len(data)
            digest = sha(data)
        require(size <= MAX_FILE, f"Member exceeds file bound: {name}")
        self.total += size
        require(self.total <= MAX_TOTAL and len(self.members) < MAX_MEMBERS, "Evidence archive bound exceeded")
        row = {"path": name, "sizeBytes": size, "sha256": digest, "role": role}
        if status is not None:
            row["status"] = status
        if run is not None:
            row["fixtureRun"] = run
        self.members[name] = (row, path, data)
        return row

    def tree(self, prefix, directory, role, status=None, run=None):
        directory = bounded_path(directory, self.scratch)
        require(directory.is_dir(), f"Missing run directory: {directory}")
        links = []
        for current, directories, files in os.walk(directory, followlinks=False):
            for name in directories:
                bounded_path(Path(current) / name, directory)
            for name in sorted(files):
                path = Path(current) / name
                if path.is_symlink():
                    links.append(owned_symlink_metadata(path, directory))
                    continue
                path = bounded_path(path, directory)
                self.add(prefix + "/" + path.relative_to(directory).as_posix(), path=path, role=role, status=status, run=run)
        if links:
            for link in links:
                if link["targetExists"]:
                    target_name = prefix + "/" + link["resolvedRelativeTarget"]
                    require(target_name in self.members and self.members[target_name][0]["sha256"] == link["targetSha256"],
                            "Owned symlink target was not independently archived as exact regular bytes")
            self.add(prefix + "/symlinks.json", data=encoded({"schemaVersion": 1, "links": links,
                "interpretation": "Relative file symlinks are represented as JSON only. Existing owned targets are independently archived regular files; bounded dangling development links retain metadata without target reads."}),
                role="owned relative log-link metadata; no extractable symlinks", status=status, run=run)

    def write_and_verify(self, candidate):
        with candidate.open("xb") as output:
            with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0, compresslevel=6) as compressed:
                with tarfile.open(fileobj=compressed, mode="w|") as archive:
                    for name in sorted(self.members):
                        row, path, data = self.members[name]
                        info = tarfile.TarInfo(name)
                        info.size = row["sizeBytes"]
                        info.mode = 0o644
                        info.mtime = 0
                        if path is None:
                            archive.addfile(info, io.BytesIO(data))
                        else:
                            require(path.stat().st_size == row["sizeBytes"] and file_sha(path) == row["sha256"], f"Input changed during packaging: {path}")
                            with path.open("rb") as source:
                                archive.addfile(info, source)
            output.flush()
            os.fsync(output.fileno())
        seen = set()
        with tarfile.open(candidate, "r:gz") as archive:
            for entry in archive:
                require(entry.isfile() and entry.name in self.members and entry.name not in seen, "Unexpected or duplicate archive member")
                row = self.members[entry.name][0]
                require(entry.size == row["sizeBytes"], f"Archived member size mismatch: {entry.name}")
                digest = hashlib.sha256()
                with archive.extractfile(entry) as source:
                    for chunk in iter(lambda: source.read(1024 * 1024), b""):
                        digest.update(chunk)
                require(digest.hexdigest() == row["sha256"], f"Archived member hash mismatch: {entry.name}")
                seen.add(entry.name)
        require(seen == set(self.members), "Archive omitted required evidence")


def verify_sources(archive, report, prefix, directory):
    hashes = report.get("sourceHashes", {})
    require(hashes, f"No measured source hashes: {directory}")
    for relative, expected in hashes.items():
        part = PurePosixPath(relative)
        require(not part.is_absolute() and ".." not in part.parts and "\\" not in relative, "Unsafe measured source path")
        source = bounded_path(directory / "sources" / Path(*part.parts), directory)
        name = prefix + "/sources/" + relative
        require(name in archive.members, f"Missing archived source snapshot: {name}")
        require(file_sha(source) == expected == archive.members[name][0]["sha256"], f"Measured source hash mismatch: {name}")
    return hashes


def observer_rows(directory):
    result = []
    for path in sorted((directory / "observer").glob("worker-*.jsonl")):
        with path.open(encoding="utf-8") as source:
            for number, line in enumerate(source, 1):
                if line.strip():
                    try:
                        result.append(json.loads(line))
                    except ValueError as error:
                        raise ValueError(f"Malformed observer evidence: {path}:{number}") from error
    require(result, "Final run has no raw observer rows")
    return result


def summarize_workers(directory, rows, profile_enabled, recovery_at):
    starts = {row["pid"]: row for row in rows if row.get("kind") == "start"}
    require(len(starts) >= 13, "Final run did not observe a full master/worker process set")
    require(not any(row.get("kind") == "observer_error" for row in rows), "Observer errors invalidate final evidence")
    roles = defaultdict(lambda: {"processes": [], "cpuProfileCount": 0})
    profile_hot = defaultdict(Counter)
    profile_frames = {}
    profile_paths = set()
    for pid, start in sorted(starts.items()):
        role = start["role"]
        flushes = [row for row in rows if row.get("pid") == pid and row.get("kind") == "flush"]
        require(flushes, f"Observer did not flush: {pid}")
        flush = flushes[-1]
        require(flush.get("success") is True and flush.get("droppedRecords") == 0 and
                flush.get("reason") == "qualifier_flush" and flush["at"] >= recovery_at, f"Observer coverage incomplete: {pid}")
        expected_state = "saved" if profile_enabled else "disabled"
        require(flush.get("profileState") == expected_state, f"Unexpected observer profile state: {pid}")
        samples = [row for row in rows if row.get("pid") == pid and row.get("kind") == "sample"]
        require(samples, f"Process has no resource samples: {pid}")
        user = sum(at(row, "cpuDeltaMicros", "user") or 0 for row in samples)
        system = sum(at(row, "cpuDeltaMicros", "system") or 0 for row in samples)
        process = {"pid": pid, "workerId": start.get("workerId"), "sampleCount": len(samples),
                   "observedFrom": start["isoAt"], "flushedAt": flush["isoAt"],
                   "sampledElapsedMs": sum(row.get("elapsedMs", 0) for row in samples),
                   "cpuUserMicros": user, "cpuSystemMicros": system,
                   "peakRssBytes": max(row["memory"]["rss"] for row in samples),
                   "firstRssBytes": samples[0]["memory"]["rss"], "lastRssBytes": samples[-1]["memory"]["rss"],
                   "peakHeapUsedBytes": max(row["memory"]["heapUsed"] for row in samples),
                   "lastHeapUsedBytes": samples[-1]["memory"]["heapUsed"],
                   "perIntervalLoopMeanMs": distribution(at(row, "eventLoopDelayMs", "mean") for row in samples),
                   "perIntervalLoopP99Ms": distribution(at(row, "eventLoopDelayMs", "p99") for row in samples)}
        if profile_enabled:
            path = directory / "observer" / f"worker-{pid}.cpuprofile"
            profile = read_json(path)
            require(profile.get("nodes") and profile.get("samples") and
                    len(profile["samples"]) == len(profile.get("timeDeltas", [])), f"Invalid real CPU profile: {pid}")
            require(profile["endTime"] > profile["startTime"], f"Empty profile duration: {pid}")
            node_map = {node["id"]: node for node in profile["nodes"]}
            self_micros = Counter()
            for node_id, elapsed in zip(profile["samples"], profile["timeDeltas"]):
                require(node_id in node_map and isinstance(elapsed, (int, float)) and elapsed >= 0, "Malformed profile sample")
                frame = node_map[node_id]["callFrame"]
                key = (frame.get("functionName", ""), frame.get("url", ""), frame.get("lineNumber", -1), frame.get("columnNumber", -1))
                self_micros[key] += elapsed
                profile_frames[key] = frame
            profile_hot[role].update(self_micros)
            process["profile"] = {"file": "observer/" + path.name, "sha256": file_sha(path),
                                  "durationMs": (profile["endTime"] - profile["startTime"]) / 1000,
                                  "samples": len(profile["samples"]), "sampledSelfMs": sum(self_micros.values()) / 1000}
            roles[role]["cpuProfileCount"] += 1
            profile_paths.add(path.name)
        roles[role]["processes"].append(process)
    found_profiles = {path.name for path in (directory / "observer").glob("*.cpuprofile")}
    require(found_profiles == profile_paths, "Unexpected/missing CPU profile files")
    result = {}
    for role, value in sorted(roles.items()):
        value["processCount"] = len(value["processes"])
        value["sampleCount"] = sum(process["sampleCount"] for process in value["processes"])
        value["cpuUserMicros"] = sum(process["cpuUserMicros"] for process in value["processes"])
        value["cpuSystemMicros"] = sum(process["cpuSystemMicros"] for process in value["processes"])
        value["largestObservedProcessRssBytes"] = max(process["peakRssBytes"] for process in value["processes"])
        if profile_enabled:
            total = sum(profile_hot[role].values())
            value["hotFunctionsBySampledSelfTime"] = [{"function": key[0], "url": key[1],
                "line": key[2] + 1 if key[2] >= 0 else None, "column": key[3] + 1 if key[3] >= 0 else None,
                "sampledSelfMs": micros / 1000, "shareOfRoleProfileSamples": micros / total if total else None}
                for key, micros in profile_hot[role].most_common(20)]
        result[role] = value
    return {"processCount": len(starts), "cpuProfileCount": len(profile_paths), "byRole": result,
            "interpretation": "Process CPU deltas and individual RSS peaks are observed values. Interval loop p99 distributions are not a combined global p99. CPU profiles show sampled self time, including idle/runtime frames; they do not establish causality or wall-time capacity."}


def server_summary(report):
    initial = report["initialStats"]
    final = report["finalStats"]
    require(initial["_nodes"] == final["_nodes"] == {"total": 3, "successful": 3, "failed": 0}, "Incomplete final server snapshots")
    require(set(initial["nodes"]) == set(final["nodes"]), "Server node identities changed")
    snapshots = [initial] + [row["stats"] for row in report["snapshots"]] + [row["stats"] for row in report["recoveryObservations"]] + [final]
    result = []
    for node_id, first in initial["nodes"].items():
        last = final["nodes"][node_id]
        samples = [snapshot["nodes"][node_id] for snapshot in snapshots]
        row = {"id": node_id, "name": first["name"], "roles": first["roles"], "samples": len(samples),
               "heapUsedBytes": {"initial": at(first, "jvm", "mem", "heap_used_in_bytes"),
                                 "final": at(last, "jvm", "mem", "heap_used_in_bytes"),
                                 "peak": max(at(sample, "jvm", "mem", "heap_used_in_bytes") for sample in samples)},
               "heapMaxBytes": at(first, "jvm", "mem", "heap_max_in_bytes"),
               "peakIndexingPressureCurrentBytes": max(at(sample, "indexing_pressure", "memory", "current", "all_in_bytes") for sample in samples),
               "processCpuMillisDelta": delta(at(first, "process", "cpu", "total_in_millis"), at(last, "process", "cpu", "total_in_millis")),
               "pressureRejectionDeltas": {}, "gc": {}, "breakers": {}, "threadPools": {}}
        for stage in ["coordinating", "primary", "replica"]:
            field = stage + "_rejections"
            row["pressureRejectionDeltas"][stage] = delta(at(first, "indexing_pressure", "memory", "total", field), at(last, "indexing_pressure", "memory", "total", field))
        for collector in at(first, "jvm", "gc", "collectors") or {}:
            row["gc"][collector] = {"countDelta": delta(at(first, "jvm", "gc", "collectors", collector, "collection_count"), at(last, "jvm", "gc", "collectors", collector, "collection_count")),
                                    "timeMillisDelta": delta(at(first, "jvm", "gc", "collectors", collector, "collection_time_in_millis"), at(last, "jvm", "gc", "collectors", collector, "collection_time_in_millis"))}
        for breaker in first.get("breakers", {}):
            row["breakers"][breaker] = {"trippedDelta": delta(at(first, "breakers", breaker, "tripped"), at(last, "breakers", breaker, "tripped")),
                                       "peakEstimatedBytes": max(at(sample, "breakers", breaker, "estimated_size_in_bytes") for sample in samples),
                                       "limitBytes": at(last, "breakers", breaker, "limit_size_in_bytes")}
        for pool in ["write", "write_coordination", "search", "search_coordination"]:
            if pool in first.get("thread_pool", {}):
                row["threadPools"][pool] = {"peakActive": max(at(sample, "thread_pool", pool, "active") for sample in samples),
                                           "peakQueue": max(at(sample, "thread_pool", pool, "queue") for sample in samples),
                                           "rejectedDelta": delta(at(first, "thread_pool", pool, "rejected"), at(last, "thread_pool", pool, "rejected")),
                                           "completedDelta": delta(at(first, "thread_pool", pool, "completed"), at(last, "thread_pool", pool, "completed"))}
        for section, fields in {"merges": ["total", "total_time_in_millis", "total_throttled_time_in_millis"],
                                "refresh": ["total", "total_time_in_millis"], "flush": ["total", "total_time_in_millis"]}.items():
            row[section + "Deltas"] = {field: delta(at(first, "indices", section, field), at(last, "indices", section, field)) for field in fields}
        result.append(row)
    return result


def expected_action_digest(report):
    digest = hashlib.sha256()
    for sequence in range(1, report["confirmedDocuments"] + 1):
        document = {"@timestamp": "2026-10-19T00:00:00.000Z", "global_sequence": sequence, "block_num": 1,
                    "act": {"account": "qualifier", "name": "load", "authorization": [],
                            "data": {"sequence": sequence, "marker": report["marker"], "payload": "q" * 512}},
                    "notified": [], "action_ordinal": 1, "creator_action_ordinal": 0}
        digest.update((json.dumps(document, sort_keys=True, separators=(",", ":")) + "\n").encode())
    return digest.hexdigest()


def summarize_final(report, directory, label):
    require(report["status"] == "passed" and report["seconds"] >= 300, f"Final {label} is not a passed sustained run")
    require(report["profile"] is (label == "profile"), f"Incorrect final profiling mode: {label}")
    require(report["runtime"]["node"] == "v24.19.0" and report["runtime"].get("bun") is None, "Final worker runtime differs from controlled Node24")
    require(all(item.get("ok") is True for item in report["cleanup"]) and
            {item.get("name") for item in report["cleanup"]} >= {"workers", "publisher", "broker", "client"}, "Final run cleanup failed")
    worker_cleanup = next(item for item in report["cleanup"] if item["name"] == "workers")
    require(worker_cleanup["shutdown"]["success"] is True and not worker_cleanup["shutdown"]["unresolved"], "Final worker shutdown incomplete")
    copies = report["finalCopies"]
    require(len(copies) == 2 and copies[0]["node"] != copies[1]["node"], "Final evidence did not target both physical copies")
    digest = expected_action_digest(report)
    require(all(copy["exactSources"] is True and copy["count"] == report["confirmedDocuments"] and copy["sha256"] == digest for copy in copies), "Final exact-source digest does not match deterministic workload")
    rows = observer_rows(directory)
    recovery_at = report["recoveryObservations"][-1]["at"]
    phases = []
    for phase in report["windows"]:
        start = phase["startedAt"]
        end = start + phase["elapsedMs"]
        queries = [row for row in report["queries"] if start <= row["at"] < end]
        bulks = [row for row in report["bulks"] if start <= row["at"] < end]
        phases.append({**phase, "publisherConfirmedActions": phase["confirmedTo"] - phase["confirmedFrom"],
                       "achievedPublisherActionsPerSecond": (phase["confirmedTo"] - phase["confirmedFrom"]) * 1000 / phase["elapsedMs"],
                       "queriesCompletedInWindow": len(queries), "queryWallMs": distribution(row["wallMs"] for row in queries),
                       "queryServerTookMs": distribution(row["took"] for row in queries),
                       "bulkResponsesCompletedInWindow": len(bulks), "bulkProxyWallMs": distribution(row["wallMs"] for row in bulks),
                       "bulkServerTookMs": distribution(row.get("took") for row in bulks)})
    require([phase["name"] for phase in phases] == ["warmup", "write", "read", "mixed"], "Final phase coverage missing")
    waves = []
    require(len(report["faults"]) == 3, "Final run lacks three backpressure waves")
    for fault in report["faults"]:
        pause, pending, resumed, request = (fault[key] for key in ["paused", "pendingRange", "resumed", "resumedRequest"])
        require(pause["role"] == pending["role"] == resumed["role"] == request["role"] == "reader", "Fault did not observe the actual backfill reader")
        require(pause["at"] < pending["at"] < fault["releasedAt"] <= resumed["at"] <= request["at"], "Backpressure event order is invalid")
        forbidden = [row for row in rows if row.get("kind") == "ship_range_request" and row.get("role") == "reader" and pending["at"] <= row["at"] < fault["releasedAt"]]
        require(not forbidden and fault["liveProgress"] > 0 and fault["heldRequests"] > 0, "Pause isolation or live progress failed")
        planned = at(pending, "message", "range") or pending.get("range")
        require(planned and request["first_block"] == planned["first_block"] and request["last_block"] == planned["last_block"], "Resume requested a different pending range")
        waves.append({"wave": fault["wave"], "gateDurationMs": fault["releasedAt"] - fault["at"],
                      "pauseToPendingRangeMs": pending["at"] - pause["at"], "pendingRangeHeldMs": fault["releasedAt"] - pending["at"],
                      "releaseToResumeMs": resumed["at"] - fault["releasedAt"], "resumeToRangeRequestMs": request["at"] - resumed["at"],
                      "pausedReaderRangeRequestsBeforeRelease": len(forbidden), "liveProgressEventsWhilePaused": fault["liveProgress"],
                      "heldProxyRequests": fault["heldRequests"], "publisherConfirmedActionDelta": fault["to"] - fault["from"],
                      "pendingRange": planned, "queuesAtRelease": fault["queuesAtRelease"], "queuesAfterDrain": fault["afterDrain"]})
    receipt_histogram = Counter()
    for bulk in report["bulks"]:
        for item in bulk.get("items") or []:
            if item.get("index") == report["actionIndex"]:
                shards = item.get("shards") or {}
                receipt_histogram[(item.get("status"), shards.get("total"), shards.get("successful"), shards.get("failed"))] += 1
    queue_peaks = {}
    for snapshot in report["snapshots"]:
        for queue in snapshot["queues"]:
            peak = queue_peaks.setdefault(queue["name"], {"messages": 0, "ready": 0, "unacked": 0})
            for field in peak:
                require(isinstance(queue[field], int), "Missing queue accounting")
                peak[field] = max(peak[field], queue[field])
    return {"mode": label, "status": report["status"], "startedAt": report["startedAt"], "completedAt": report["completedAt"],
            "runtime": report["runtime"], "fixtureRun": report["state"]["run"], "chain": report["chain"], "actionIndex": report["actionIndex"],
            "nominalPhaseSecondsTotal": report["seconds"], "targetPublisherActionsPerSecond": report["rate"],
            "publisherConfirmedActions": report["confirmedDocuments"], "exactPhysicalCopies": copies,
            "actionReceiptCopyHistogram": [{"status": key[0], "total": key[1], "successful": key[2], "failed": key[3], "itemReceipts": count}
                                           for key, count in sorted(receipt_histogram.items(), key=lambda row: str(row[0]))],
            "phases": phases, "queryWallMsAll": distribution(row["wallMs"] for row in report["queries"]),
            "bulkProxyWallMsAll": distribution(row["wallMs"] for row in report["bulks"]), "bulkResponses": len(report["bulks"]),
            "queueThresholds": report["config"]["scaling"], "queuePeaks": queue_peaks, "backpressureWaves": waves,
            "workers": summarize_workers(directory, rows, label == "profile", recovery_at),
            "serverNodes": server_summary(report), "server": report["server"],
            "cleanup": report["cleanup"], "recoverySampleCount": len(report["recoveryObservations"])}


def fixture_evidence(archive, scratch, report, number, final, postflight_path=None):
    state_path = scratch / f"es198-workers-state{number}.json"
    state_bytes = state_path.read_bytes()
    state = json.loads(state_bytes)
    require(report["fixtureManifestSha256"] == sha(state_bytes) and report["state"]["run"] == state["run"], "Final report references a different fixture manifest")
    core = read_json(Path(str(state_path) + ".core.json"))
    require(state["core"]["clusterUuid"] == core["clusterUuid"], "Core fixture journal disagrees with final manifest")
    cleanup = read_json(Path(str(state_path) + ".cleanup.json"))
    core_cleanup = read_json(Path(str(state_path) + ".core.json.cleanup.json"))
    require(cleanup["run"] == core_cleanup["run"] == state["run"] and cleanup.get("completedAt"), "Fixture cleanup identity is invalid")
    for field in ["remainingContainers", "remainingVolumes", "remainingNetworks"]:
        require(core_cleanup[field] == cleanup["coreCleanup"][field] == 0, f"Fixture cleanup residue: {field}")
    expected_extras = {state[kind]["containerId"] for kind in ["redis", "mongo", "spring"]}
    expected_core = {node["containerId"] for node in state["core"]["nodes"]} | {state["core"]["broker"]["containerId"]}
    require(set(cleanup["extraContainers"]) == expected_extras and set(core_cleanup["containers"]) == expected_core, "Cleanup does not cover every expected container")
    require(set(cleanup["extraVolumes"]) == {state[kind]["volume"] for kind in ["redis", "mongo", "spring"]}, "Extra fixture volumes were not all removed")
    postflight_path = bounded_path(postflight_path or scratch / f"es198-workers-state{number}-postflight.json", scratch)
    postflight = read_json(postflight_path)
    require(postflight["run"] == state["run"] and postflight["fixtureManifestSha256"] == sha(state_bytes), "Postflight belongs to a different fixture")
    require(postflight["status"] == "passed" and postflight["consecutiveIdleSamples"] >= 3 and not postflight["survivingObservedProcesses"], "Final fixture postflight did not pass")
    for sample in postflight["samples"][-3:]:
        require(sample["idle"] and sample["remainingTasks"] == sample["remainingBrokerConnections"] == 0, "Final postflight retained work")
        require(all(queue["messages"] == queue["messages_ready"] == queue["messages_unacknowledged"] == 0 for queue in sample["brokerQueues"]), "Final Rabbit accounting retained work")
    final["postflight"] = {"file": "fixture/" + postflight_path.name, "status": postflight["status"], "observedProcessCount": postflight["observedProcessCount"],
                           "consecutiveIdleSamples": postflight["consecutiveIdleSamples"], "emptyDurableQueuesRetained": postflight["durableEmptyQueuesRemain"]}
    final["fixtureCleanup"] = {"completedAt": cleanup["completedAt"], "containersRemoved": len(expected_extras | expected_core),
                               "volumesRemoved": len(cleanup["extraVolumes"]) + len(core_cleanup["volumes"]),
                               "remainingContainers": 0, "remainingVolumes": 0, "remainingNetworks": 0}
    return state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--scratch", required=True, type=Path)
    parser.add_argument("--destination", required=True, type=Path)
    parser.add_argument("--control", default="es198-workers-node-control-final")
    parser.add_argument("--profile", default="es198-workers-node-profile-final")
    parser.add_argument("--control-state", type=int, default=4)
    parser.add_argument("--profile-state", type=int, default=5)
    parser.add_argument("--control-postflight", type=Path)
    parser.add_argument("--profile-postflight", type=Path)
    args = parser.parse_args()
    repo = args.repo.resolve(strict=True)
    scratch = args.scratch.resolve(strict=True)
    destination = args.destination.resolve()
    require((repo / "package.json").is_file() and (repo / "scripts/qualification/es955-workers.ts").is_file(), "Not the expected qualification repository")
    require(destination.parent == repo / "docs/performance/evidence" and destination.name == "es955-workers-20261019", "Unexpected evidence destination")
    require(not destination.exists(), "Refusing to overwrite an existing evidence destination")
    archive = Archive(repo, scratch)
    finals = []
    final_hashes = []
    states = []
    included_runs = set()
    for label, folder, number, postflight_path in [("control", args.control, args.control_state, args.control_postflight),
                                                 ("profile", args.profile, args.profile_state, args.profile_postflight)]:
        directory = bounded_path(scratch / folder, scratch)
        report = read_json(directory / "report.json")
        summary = summarize_final(report, directory, label)
        prefix = "runs/final/" + label
        archive.tree(prefix, directory, "passed final full-worker run; exact bytes", status="passed", run=report["state"]["run"])
        hashes = verify_sources(archive, report, prefix, directory)
        final_hashes.append(hashes)
        state = fixture_evidence(archive, scratch, report, number, summary, postflight_path)
        states.append(state)
        summary["archivePrefix"] = prefix
        finals.append(summary)
        included_runs.add(directory)
        del report
    require(final_hashes[0] == final_hashes[1], "Final control/profile measurements used different source/build bytes")
    require(states[0]["run"] != states[1]["run"] and states[0]["core"]["clusterUuid"] != states[1]["core"]["clusterUuid"], "Final control/profile did not use separate fresh fixtures")
    controls = []
    for number in range(1, 7):
        require((scratch / f"es198-workers-pilot{number}/report.json").is_file(), f"Missing required pilot{number} evidence")
    for directory in sorted(scratch.glob("es198-workers-*")):
        if not directory.is_dir() or directory.resolve() in included_runs or not (directory / "report.json").is_file():
            continue
        report_path = directory / "report.json"
        try:
            report = read_json(report_path)
            status = report.get("status", "unknown")
            fixture_run = at(report, "state", "run")
        except (ValueError, json.JSONDecodeError):
            report = None
            status = "incomplete-report-preserved"
            fixture_run = None
        prefix = "runs/development/" + directory.name
        archive.tree(prefix, directory, "development/control evidence; excluded from final totals", status=status, run=fixture_run)
        if report and report.get("sourceHashes"):
            verify_sources(archive, report, prefix, directory)
        controls.append({"name": directory.name, "status": status, "fixtureRun": fixture_run,
                         "archivePrefix": prefix, "confirmedActions": report.get("confirmedDocuments") if report else None,
                         "error": report.get("error") if report else "No complete report", "includedInFinalTotals": False})
        del report
    fixture_files = set()
    for number in range(1, max(5, args.control_state, args.profile_state) + 1):
        for suffix in [".json", ".json.core.json", ".json.cleanup.json", ".json.core.json.cleanup.json"]:
            path = scratch / f"es198-workers-state{number}{suffix}"
            require(path.is_file(), f"Missing original fixture/cleanup evidence: {path.name}")
        for path in sorted(scratch.glob(f"es198-workers-state{number}*")):
            if path.is_file():
                archive.add("fixture/" + path.name, path=path, role="original fixture, postflight, setup-failure or cleanup evidence", status="raw")
                fixture_files.add(path.resolve())
    old_postflight = read_json(scratch / "es198-workers-state3-postflight.json")
    require(old_postflight["status"] == "failed", "Development fixture retained backlog postflight unexpectedly changed")
    validation = []
    patterns = ["es198-workers-*", "es198-worker-*", "es198-observer-*", "es198-reader-active-close-*",
                "es198-reader-drain-*", "es198-reader-lifecycle-*", "es198-reader-onconnect-*",
                "es198-reader-confirm*", "es198-*host*", "es198-*transport*"]
    paths = set()
    for pattern in patterns:
        paths.update(path for path in scratch.glob(pattern) if path.is_file() and path.suffix.lower() in {".log", ".json", ".ts", ".mjs", ".ps1", ".py", ".md"})
    paths.add(Path(__file__).resolve())
    for path in sorted(paths):
        if path.resolve() in fixture_files:
            continue
        archive.add("validation/" + path.name, path=path, role="root, reviewer, native-probe, test or packaging evidence")
        if path.suffix == ".log":
            text = path.read_text(encoding="utf-8", errors="replace")
            passes, failures, assertions = (re.findall(pattern, text) for pattern in [r"\b(\d+) pass\b", r"\b(\d+) fail\b", r"\b(\d+) expect\(\) calls\b"])
            if passes or failures:
                validation.append({"file": "validation/" + path.name,
                                   "purpose": "negative red control" if "-red" in path.name else "validation output",
                                   "passed": int(passes[-1]) if passes else None,
                                   "failed": int(failures[-1]) if failures else None, "assertions": int(assertions[-1]) if assertions else None})
    for name in ["es198-workers-native-node24.json", "es198-workers-native-bun143.json", "es198-workers-native-probe.mjs",
                 "es198-workers-unit-final2.log", "es198-reader-active-close-red-final.log", "es198-reader-active-close-green.log",
                 "es198-reader-active-close-spec-review.log", "es198-worker-cleanup-root-audit.json",
                 "es198-reader-confirm-replay-audit-20261019.md", "es198-workers-host.json",
                 "es198-workers-transport.json", "es198-workers-postflight-array-smoke.json"]:
        require("validation/" + name in archive.members, f"Required validation evidence absent: {name}")
    supporting = ["scripts/qualification/es955-replica-fixture.ps1", "scripts/qualification/fixture/worker-nodeos-config.ini",
                  "scripts/qualification/check-worker-cleanup.ps1", "scripts/qualification/check-worker-observer.mjs",
                  "tests/e2e/nodeos/genesis.json", "tests/unit/es955-workers.test.ts", "tests/unit/state-reader-backpressure.test.ts",
                  "tests/unit/module-loader-import.test.ts", "tests/unit/elastic-settlement-recovery.test.ts", ".github/workflows/build.yml",
                  "package.json", ".bun-version", "scripts/qualification/tsconfig.json"]
    for name in supporting:
        archive.add("sources/supporting/" + name, path=repo / name, role="supporting source at archive freeze; not represented as measured unless separately hashed by a run")
    native = {mode: read_json(scratch / f"es198-workers-native-{mode}.json") for mode in ["node24", "bun143"]}
    summary = {"schemaVersion": 1, "issue": "https://github.com/eosrio/hyperion-history-api/issues/198", "measuredDate": "2026-10-19",
               "runs": finals, "totals": {"passedFinalRuns": len(finals),
                   "publisherConfirmedActions": sum(row["publisherConfirmedActions"] for row in finals),
                   "bothPhysicalCopyActionVerifications": sum(len(row["exactPhysicalCopies"]) for row in finals),
                   "verifiedBackpressureWaves": sum(len(row["backpressureWaves"]) for row in finals)},
               "nativeProbes": native, "unitLogSummaries": validation, "developmentControls": controls,
               "developmentFixturePostflight": {"fixture": "state3", "status": old_postflight["status"],
                   "error": old_postflight.get("error"), "interpretation": "Failed pilot left a nonempty queue without consumers. Preserved as failed postflight, then removed by exact owned fixture cleanup; excluded from final acceptance."},
               "limits": LIMITS}
    archive.add("README.json", data=encoded({"schemaVersion": 1, "interpretation": "Final control and profiling runs are separate fresh fixtures. Development pilots and expected controls are excluded from final totals.",
                 "sourceProvenance": "Each run includes its original source snapshots. Every report.sourceHashes entry is checked against its archived bytes. Current Git HEAD is context only; normalized blobs can differ in line endings.",
                 "verification": "Manifest describes every raw archive member. Packaging reads back and hashes every archived member before publication.", "limits": LIMITS}), role="archive interpretation")
    candidate = scratch / ("es198-workers-package-candidate-" + uuid.uuid4().hex + ".tar.gz")
    archive.write_and_verify(candidate)
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
    manifest = {"schemaVersion": 1, "createdAt": datetime.now(timezone.utc).isoformat(), "archive": "raw-evidence.tar.gz",
                "archiveSha256": file_sha(candidate), "archiveSizeBytes": candidate.stat().st_size, "archiveFreezeHead": head,
                "sourceProvenance": "Exact per-run snapshots checked against every report.sourceHashes value. Git HEAD is context, not a replacement for measured byte hashes.",
                "finalSourceHashes": final_hashes[0], "memberCount": len(archive.members), "uncompressedBytes": archive.total,
                "members": [archive.members[name][0] for name in sorted(archive.members)]}
    destination.mkdir()
    outputs = {"manifest.json": encoded(manifest), "summary.json": encoded(summary),
               ".gitattributes": b"raw-evidence.tar.gz binary\nmanifest.json -text\nsummary.json -text\nSHA256SUMS -text\n"}
    for name, data in outputs.items():
        with (destination / name).open("xb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
    # Copy the already-verified candidate without renaming or deleting any source.
    with candidate.open("rb") as source, (destination / "raw-evidence.tar.gz").open("xb") as target:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            target.write(chunk)
        target.flush()
        os.fsync(target.fileno())
    checksums = "".join(f"{file_sha(destination / name)}  {name}\n" for name in ["raw-evidence.tar.gz", "manifest.json", "summary.json", ".gitattributes"])
    with (destination / "SHA256SUMS").open("xb") as output:
        output.write(checksums.encode())
        output.flush()
        os.fsync(output.fileno())
    require(file_sha(destination / "raw-evidence.tar.gz") == manifest["archiveSha256"], "Published archive copy mismatch")
    for line in checksums.splitlines():
        expected, name = line.split("  ", 1)
        require(file_sha(destination / name) == expected, f"Published checksum mismatch: {name}")
    print(json.dumps({"status": "passed", "destination": str(destination), "memberCount": len(archive.members),
                      "archiveSha256": manifest["archiveSha256"], "archiveSizeBytes": manifest["archiveSizeBytes"],
                      "summarySha256": file_sha(destination / "summary.json"), "totals": summary["totals"]}))


if __name__ == "__main__":
    main()
