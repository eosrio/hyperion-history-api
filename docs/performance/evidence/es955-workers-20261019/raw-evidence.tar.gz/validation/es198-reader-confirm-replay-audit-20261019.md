# Reader confirm and source replay follow-up audit

Read-only audit, 2026-10-19. Source baseline: `caa8fdb08367cffbdfc02de6c04dbc26e745c395` on `codex/es955-sustained-workers`, including reader continuation fix `ccf1c2e`. Workspace: `C:\Users\igorl\.codex\worktrees\hyperion45-es955\hyperion-history-api`.

This note records remaining reliability scope. It changes no runtime code, dependencies, cluster settings or GitHub issues. The current finite backpressure qualification is not a test of loss-free publisher-confirm recovery or arbitrary reader process restart. The six existing actual-method reader tests establish publisher-writability/cargo continuation and channel identity handling; their channel replacement fixture does not recreate a real AMQP connection or prove durable replay.

## 1. Enqueue progress, confirmation and completion are different boundaries

**Status: source-confirmed design limitation; failure outcome still needs a dedicated running-worker fault reproduction.**

- `src/indexer/workers/state-reader.ts:140-161` pops a payload, publishes it persistently on the confirm channel and handles the confirm callback. A callback error only prints `Message nacked!` and the error message (`150-151`). A successful callback sends `read_block` (`153-160`). There is no explicit negative/unknown-confirm retained-work disposition in that callback.
- The historical `local_distributed_count` advances outside the callback, immediately after `sendToQueue` returns, and starts `signalReaderCompletion()` once the range count is reached (`164-168`). This starts completion tracking before successful confirms. **Do not describe this as an unconditional immediate `completed` event before healthy confirms**: `signalReaderCompletion` starts a 200 ms interval and normally waits for truthy entries in `this.cch.unconfirmed` to disappear (`346-367`).
- The completion condition reads the *current* channel's private callback window (`355-365`), not a range-scoped set of successful receipts with a captured publisher generation. When it sees zero, it emits `completed`, or advances an internal range (`367-383`). That condition cannot distinguish successful ACK removal from a NACK/closed-channel error or a newly created channel's initially empty callback window.
- The installed, pinned `amqplib` 2.0.1 source supports that distinction: `node_modules/amqplib/lib/channel.js:29-42` invokes errors on NACK/close, then removes or filters the unconfirmed callbacks. These local dependency lines are implementation evidence, not a Hyperion fault experiment.
- `processIncomingBlocks` credits SHIP after awaiting the processing/cargo path (`state-reader.ts:390-402`); `ackBlockRange` sends `get_blocks_ack_request_v0` (`978-979`). Ordinary distribution can complete when writes are accepted/drained rather than confirmed (`173-180`). SHIP message credits are flow control; they must not be labeled a durable source checkpoint or proof that RabbitMQ persisted all downstream work. Historical source retention/replay availability is a separate question.

The current continuation fix deliberately retains only *unsent* payloads and a running cargo callback (`state-reader.ts:183-200`), then resumes that cargo once replacement queues are asserted (`217-234`). It does not blindly republish an already popped accepted message, and it does not add negative/unknown-confirm recovery. A late callback cannot double-finish that cargo in the current regression, but this does not establish loss-free recovery for accepted messages without a successful confirm.

Source links: [publication and enqueue progress](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/workers/state-reader.ts#L135-L201), [completion and SHIP credit path](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/workers/state-reader.ts#L346-L402), [SHIP credit encoding](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/workers/state-reader.ts#L978-L979).

## 2. A channel-only closure does not itself create replacement channels

**Status: already tracked explicitly in API #187, item 3; not a new issue.**

The actual base worker and reader close handlers clear readiness/pause cargo (`hyperionWorker.ts:143-159`, `state-reader.ts:217-225`). `connectAMQP` binds replacement channels when its connection manager's reconnect callback fires (`hyperionWorker.ts:125-141`). The AMQP helper installs reconnection on `connection.on('close')` (`src/indexer/connections/amqp.ts:50-65`), not on an isolated channel close while the connection remains open. The new pending-cargo continuation recovers once replacement happens; it does not independently ensure that replacement is scheduled in every channel-only failure.

Source links: [base-worker channel lifecycle](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/workers/hyperionWorker.ts#L125-L159), [connection-driven reconnect](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/connections/amqp.ts#L50-L65).

## 3. Historical worker restart retains its initial assignment, not necessarily its active range

**Status: source-confirmed missing restart metadata; possible skipped-range consequence is an inference requiring a real supervisor/replay regression.**

- Initial parallel-reader definitions contain `first_block` and `last_block` (`master.ts:995-1007`).
- The `completed` handler assigns subsequent ranges by IPC and advances global `lastAssignedBlock`, but does not update the corresponding `workerMap` definition's first/last range (`master.ts:375-398`). The reader stores the incoming end only locally (`state-reader.ts:238-250`).
- Disconnect recovery clears the worker reference and relaunches it after five seconds (`master.ts:1953-1978`); `launchWorkers` forks from that retained worker definition (`1115-1124`). Thus blindly making a reader exit on publisher errors is not yet a proven safe replay mechanism.
- Illustrative inferred failure with one worker: initial range `[1,101)` completes; `[101,201)` is assigned; the worker dies partway through it; a relaunch using the original definition replays `[1,101)`; its next `completed` may advance the global scheduler from 201, leaving the interrupted range unproven. This exact sequence has **not** been executed in the current finite qualification.

Source links: [initial historical and live assignments](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/modules/master.ts#L993-L1024), [subsequent assignment](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/modules/master.ts#L375-L398), [forked worker definition](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/modules/master.ts#L1115-L1124), [disconnect supervision](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/modules/master.ts#L1953-L1978).

## 4. Repair work needs an explicitly retained active assignment

**Status: source-confirmed unretained active repair instruction; interrupted-repair behavior is not yet fault-qualified.**

`sendPendingRepairRanges` shifts an instruction from the pending list before sending it to the repair worker (`master.ts:1491-1503`). Both a repair worker's ready event and its completion event call that method (`362-363`, `375-378`). A fresh repair worker sends `repair_reader_ready` and waits for an instruction (`state-reader.ts:459-466`); its initial definition contains role/server information, not an active range (`master.ts:1479-1484`). Therefore after a process replacement, simply proceeding to the next pending range does not demonstrate completion of the interrupted active range. Merely changing first/last environment variables would also be insufficient while the repair-reader startup path still waits for a fresh instruction.

Source links: [repair setup and dispatch](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/modules/master.ts#L1465-L1508), [repair startup](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/workers/state-reader.ts#L459-L466).

## 5. A continuous-reader restart watermark cannot safely be the largest confirmed block

**Status: conservative startup replay observed in source; an optimized contiguous, fork-aware watermark is not implemented/qualified here.**

The live worker definition starts with `worker_last_processed_block` equal to the startup head (`master.ts:1014-1023`), and the reader requests from that environment value (`state-reader.ts:85-86`, `453-455`). The master's `read_block` handler increments aggregate historical/live counters; it does not update the worker definition's resume point (`master.ts:441-447`). A reader process relaunch therefore retains the startup position, subject to SHIP retention/availability, rather than a newly qualified per-range durable watermark.

Do not replace this with `max(read_block.block_num)` as a shortcut. `recursiveDistribute` publishes `data.pop()` (`state-reader.ts:140-141`), so a cargo batch can publish a larger block before its lower-numbered neighbors. A largest successful confirm does not establish an unbroken confirmed prefix. A correct improvement must define contiguous progress, publisher generation/outcomes and branch identity; avoid claiming that a numeric high-water mark alone resolves fork/replay correctness.

Source links: [live assignment](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/modules/master.ts#L1014-L1023), [counter-only read handler](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/modules/master.ts#L441-L447), [reverse cargo publication](https://github.com/eosrio/hyperion-history-api/blob/caa8fdb08367cffbdfc02de6c04dbc26e745c395/src/indexer/workers/state-reader.ts#L135-L160).

## Duplicate search and recommended issue placement

As of this audit, GitHub CLI retrieved all **72 API issues** and **7 Tools issues** in open/closed states, then searched titles/bodies for reader, publisher, confirm, replay, resilience, durability, reliability and backpressure. Separate GitHub issue searches for `reader`, `publisher`, `replay` and `resilience` were checked; `publisher` returned none. API #187 has zero comments. Local captured inventories are `es198-reader-issue-inventory-api.json`, `es198-reader-issue-inventory-tools.json` and `es198-reader-187-comments.json` in this scratch directory. This is an audit of issue titles/bodies and #187 comments, not every historical PR or every issue comment.

- [API #187 — indexer resilience & observability](https://github.com/eosrio/hyperion-history-api/issues/187), **OPEN**, already owns isolated AMQP channel closure (item 3), management-API fail-open (item 4), and contiguous/stalled progress observability (item 5). Keep those there; do not open duplicate channel-loss or queue-monitor issues.
- [API #195 — Replay one guarded fixture with verified ABI and output coverage](https://github.com/eosrio/hyperion-history-api/issues/195), **OPEN**, already requires real workers, output/count/order coverage, failed/retried work and durable progress. It is the integration-oracle home for the eventual reader replay fix.
- [API #196 — Persist one reader-to-ack profile with CPU and wait attribution](https://github.com/eosrio/hyperion-history-api/issues/196), **OPEN**, already includes durable/freshness watermarks and stage distributions. It should measure the eventual verified boundaries; a profile alone does not implement them.
- [API #198 — ES9.5.5 qualification](https://github.com/eosrio/hyperion-history-api/issues/198), **OPEN**, should link the remaining reliability gate and retain its bounded measurement limits. These source-side semantics are not an Elasticsearch release regression.
- [Tools #28 — component profiling program](https://github.com/eosrio/hyperion-tools/issues/28), **OPEN**, is the cross-component parent; [Tools #21](https://github.com/eosrio/hyperion-tools/issues/21) covers state-projection rollback/restart and must not be treated as an existing reader/publisher replay fix. API #188 is fork-cleanup-on-RPC-failure scope, also distinct. Closed historical reader-stall issues are symptom precedents, not duplicates of a verified current confirm/replay contract.

**Recommendation, not an issue write:** place a focused follow-up in `eosrio/hyperion-history-api` under the existing #187 reliability program, crosslinked to #195, #196 and #198. Suggested title: `4.5: Preserve reader progress across publisher failure and worker replay`. If the project prefers avoiding a separate child ticket, append this exact source-backed checklist to #187 instead. No existing dedicated issue matching the negative/unknown-confirm plus active-range replay contract was found in the inspected titles/bodies.

Suggested acceptance for that future ticket:

1. Define successful range completion and source credit/checkpoint boundaries; track per-publisher confirm success/failure without relying only on private callback-window emptiness.
2. Reproduce a final-message NACK, accepted-but-unconfirmed connection loss, channel-only close, replacement before a completion poll, and late old-generation callbacks using actual broker/worker processes. Assert no unsupported progress signal or unaccounted work.
3. Persist and reissue the actual active historical and repair range before allowing reader supervised restart. Crash after a later `new_range`, and verify complete output with no holes; document any intentional at-least-once duplicates and required idempotency.
4. Qualify a contiguous, branch-aware live resume point; include reverse cargo publication and a missing lower-numbered confirm so `max(block_num)` cannot accidentally pass.
5. Preserve shared-reader queue backpressure and live priority, retain finite resource bounds, and expose incomplete/unknown recovery distinctly. Do not claim arbitrary source retention or power-loss acceptance from a process-only test.

No new issue was opened or modified by this audit. These remain follow-up reliability work rather than additional required code for the current finite load/backpressure slice.
