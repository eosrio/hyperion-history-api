import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {mkdtempSync,mkdirSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const cwd=process.cwd();
const dir=mkdtempSync(join(tmpdir(),'hyperion-reader-spec-'));
try {
 mkdirSync(join(dir,'config'));
 writeFileSync(join(dir,'chain.json'),JSON.stringify({settings:{chain:'drain-test'},indexer:{}}));
 writeFileSync(join(dir,'config','connections.json'),'{}');
 process.chdir(dir); process.env.CONFIG_JSON=join(dir,'chain.json');
 const {default:StateReader}=await import('file:///C:/Users/igorl/.codex/worktrees/hyperion45-es-targets/hyperion-history-api/src/indexer/workers/state-reader.ts');
 const old=new EventEmitter(); const replacement=new EventEmitter();
 const reader=Object.assign(Object.create(StateReader.prototype),{chain:'drain-test',conf:{scaling:{ds_queues:1}},ch:Object.assign(new EventEmitter(),{async assertQueue(){}}),cch:old,cch_ready:true,isLiveReader:false,stageOneDistQueue:{resume(){},pause(){}},events:new EventEmitter()});
 reader.onConnect(); await new Promise(resolve=>setImmediate(resolve));
 reader.cch=replacement;reader.onConnect();await new Promise(resolve=>setImmediate(resolve));
 assert.equal(reader.cch_ready,true);
 old.emit('close');
 console.log(JSON.stringify({oldCloseListeners:old.listenerCount('close'),replacementReadyAfterStaleClose:reader.cch_ready}));
 assert.equal(reader.cch_ready,true,'production onConnect stale close disabled replacement');
} finally {process.chdir(cwd);rmSync(dir,{recursive:true,force:true});}
