param([string]$Script='C:\Users\igorl\.codex\scratch\es198-workers-postflight.ps1')
$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($Script,[ref]$tokens,[ref]$errors)
if($errors){throw ($errors|Out-String)}
$helper=$ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Convert-PostflightJsonArray'},$true)
if(@($helper).Count -ne 1){throw 'Expected exact JSON-array helper definition'}
. ([scriptblock]::Create($helper.Extent.Text))
$results=@()
foreach($case in @(@{json='[]';count=0},@{json='[{"name":"one"}]';count=1},@{json='[{"name":"one"},{"name":"two"}]';count=2})){
    $value=Convert-PostflightJsonArray $case.json
    if($value -isnot [array] -or $value.Count -ne $case.count){throw 'Array cardinality was changed'}
    if(@($value|Where-Object {$_ -is [array]}).Count){throw 'REST JSON array was nested'}
    $results+=@(@{case=$case.json;count=$value.Count;passed=$true})
}
foreach($invalid in @('null','{}','{"name":"object"}')){
    $caught=$null
    try{$null=Convert-PostflightJsonArray $invalid}catch{$caught=$_.Exception.Message}
    if($caught -ne 'Expected a complete REST JSON array'){throw 'Non-array response was accepted'}
    $results+=@(@{case=$invalid;rejected=$true;passed=$true})
}
@{status='passed';cases=$results;realHttpCalls=0;realDockerCalls=0;sourceSha256=(Get-FileHash -LiteralPath $Script -Algorithm SHA256).Hash.ToLowerInvariant()}|ConvertTo-Json -Depth 6
