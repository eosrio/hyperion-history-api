# Final Spec review — portable state source admission

Reviewed immutable range `d1c265d80747dfe056ad5eb23fb6db6dd8dba25c...ad590df3fc820cbf9723c5d6530b5e88c4b967e4` against fresh HAPI #191 and accepted architecture/ADRs 0021, 0036, 0037 and 0039.

**0 actionable Spec findings.**

The production source establishes exact canonical proof/commit identity before awaiting durable admission, then performs retained-capture, ABI and provider interpretation. The same admission runs after the runtime's immutable header/change capture and before declarative mapping. The controller binds repeated callbacks to the same frozen target. A known evaluation failure therefore retains a non-serving pending intent even if its later diagnostic write rejects.

Admission rejection or CAS miss occurs before contract evaluation and preserves ordinary unadmitted lag. An uncertain receipt after persistence remains fenced by durable metadata. Mongo's majority/journaled compare-and-set retains checkpoint, pending and gap authority; exact-source transactional completion alone clears the intent. Recovery continues from checkpoint+1. Default runtime callers preserve receipt-based duplicate handling, while mutable caller frames cannot alter the captured target/effects.

The strict harness update reflects the explicit admission reason without dropping target, predecessor, digest or checkpoint checks. It additionally requires the invalid mapping to remain unavailable while the real Mongo update failpoint is active. No SDK schema, per-chain backend policy, source/history ACK barrier or global source-head serving requirement was added.

Independent focused validation on Bun 1.4.3: **48 tests passed, 0 failed, 256 assertions** across failure visibility, actual retained-source/controller/runtime and harness suites. These exercise the real adapter/read gate/Fastify route with constructed Mongo transport, including source decode failures, rejected diagnostics, uncertain admission receipts, exact recovery and immutable input handling. No persistent services or Hyperion-3 operations were performed.

This is an incremental Spec verdict. Fresh actual Mongo/full-worker Node22/24 acceptance remains the root lane; these component results do not establish process-crash, fork, Rust, Bun runtime, full Wire or release qualification. M2 auto-map and staged live mapping reload remain required follow-up slices.