# Standards review: durable source admission

Immutable range: `d1c265d80747dfe056ad5eb23fb6db6dd8dba25c...ad590df3fc820cbf9723c5d6530b5e88c4b967e4` in `eosrio/hyperion-history-api`.

**No actionable Standards findings.** No documented standard violations or actionable heuristic smells were identified in this increment.

Reviewed against the History API `AGENTS.md`, development build guide and MongoDB adapter contract; Tools `AGENTS.md`, architecture definition, ADRs 0021/0039 and the shared TypeScript policy; and all twelve supplied smell-baseline heuristics. Tooling-enforced style/type concerns were excluded from findings.

The controller coordinates an exact typed block reservation through the existing backend-neutral adapter contract. Native CAS and durability options remain confined to MongoDB. Source acquisition places admission after canonical authority resolution and before retained-source/ABI/provider interpretation. The runtime repeats the same target binding after its immutable capture, preserving ordinary callers' receipt-based duplicate behavior. These are required boundaries in the existing modules, without a new SDK or plugin abstraction. Independent projection lanes and history/source acknowledgments remain separate.

The diagnostic-write failure tests use actual runtime, adapter, read gate and Fastify consumers with explicit transport fixtures. They distinguish ordinary unadmitted lag, persisted admission with a lost receipt, failed detailed markers and transactional completion. The qualification harness retains exact target, predecessor, digest and checkpoint assertions, now requiring the explicit admission reason and invalid-projection unavailability while the update fault is active. Documentation states the durable fence without claiming full-run acceptance.

Independent focused validation on Bun 1.4.3: **48 tests passed, zero failed, 256 assertions** across the source, worker, runtime, failure-visibility and harness suites. No repository edits, Docker, Hyperion-3 operations or persistent services were performed. The review is limited to this frozen increment; actual Mongo/full-worker, native-runtime and complete-release acceptance remain separate evidence.
