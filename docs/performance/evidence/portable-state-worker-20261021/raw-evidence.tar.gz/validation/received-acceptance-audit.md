# Independent portable-state acceptance audit

Task: `task_191_acceptance_audit_20261021`; request `evt_20261021T142910_51818d90dc76`.
Audited code: `ad590df3fc820cbf9723c5d6530b5e88c4b967e4`.
Reviewer: `windows:codex:hyperion-tools`, lane `/root/action_admission_spec_final`.

**Result: the original evidence supports the bounded Linux Node22/24 portable Mongo primary-state qualification. No contradictory acceptance evidence was found.** This audit only read local archives; it did not execute services or modify repositories.

| Original archive | SHA256 | Ordinary files | Ordinary bytes |
| --- | --- | ---: | ---: |
| case24-e-full.tar.gz | dced7fbaa453733e78f1f935a367dff232b1bb37b8cca4199dda5042b4353394 | 20,722 | 129,583,236 |
| case22-a-full.tar.gz | 2717ac2b00e7bf76d82d893d7427823af9f8764dd5752c32000ee26860fadfd5 | 20,778 | 130,042,759 |

Both archive hashes and every ordinary member's manifest size/SHA256 matched. No links were extracted or followed. Each manifest explicitly records one omitted deserialization-error log symlink; the timestamped target remains an ordinary retained file. Original reports are passed, error arrays empty, and the code commit matches. Source identities and all 1,484 input-hash entries agree between runs: chain `9ccd94e823fda51363bd4265ad618a909c4985c445078c79f8d030fe9697b71d`, profile `wire-sysio-6508c9e8-engineering-v1`, upstream `6508c9e8f4044df8d5acb082a7af3be6a80cd9a0`. Plans differ only in source/oracle paths; oracle hashes remain exact.

Original prefix hashes matched their reports. At1244 and1480, actual HTTP200 responses exactly match the independently specified logical row keys/values, counts, binding checkpoints and served-view headers. `attseq.next` changes from decimal string5 to9; outenvelope IDs1/2 are replaced by3/4, proving their absence from the final complete query. Before source, API returns retryable503 without served-view headers.

Both actual Mongo failpoints rejected six update commands. Pending healthy projections retain checkpoint1243 with target1244 and non-null source digest; their APIs return retryable503. The invalid required-field projection also returns503 during that fault and remains pending at1244/checkpoint1243 at both later barriers. Healthy projections recover to the exact oracle, while the invalid projection remains unavailable. The existing history HTTP API returns200 and both selected physical Elasticsearch nodes independently return the correct source block at1244 and1480, including while Mongo writes are failing.

Source sends, SHiP ACKs, continuous-reader `read_block` and deserializer `consumed_block` each cover exactly1 through1480 once. The live RabbitMQ queue records1480 deliveries/ACKs and zero redelivery; all final queues are drained. These broker ACKs concern the durable source/history path, not direct Mongo-effect acknowledgments. Projection completion is evidenced separately by recovery views and successful HTTP reads. `productionProgressKey` remains null.

Node24 retained10,345 bulk request/response pairs (110,364,470 bytes); Node22 retained10,371 (110,365,494 bytes). Each has11,098 successful201 items and no response/item errors. **Both have five one-copy and11,093 two-copy acknowledgments.** The one-copy items are block1, ABI IDs `1sysio`, `1sysio.null`, `1sysio.prods`, and delta ID `h45h1:f248ebe48139b118a7e85be91b3ec19d9492786903d836197f6dbf8ac9c4f37b`. Later physical reads do not upgrade those original acknowledgment guarantees.

All14 observed processes per run exited0. Master receipts identify the same12 forked/exited child PIDs; shutdown succeeded without forced/unresolved/failed children. API/master OS exits are0 with null signal. Driver cleanup entries and owned Mongo container/network/volume verification passed. These archives do not independently establish subsequent absence of the separately managed core ES/Rabbit/Redis fixture; root's postflight must cover that.

| Process | Node24 CPU seconds / reported peak RSS MiB | Node22 CPU seconds / reported peak RSS MiB |
| --- | ---: | ---: |
| Projection owner | 223.986 /385.199 | 224.638 /337.016 |
| Active deserializer | 114.288 /395.445 | 124.464 /298.535 |
| Master | 78.671 /341.930 | 81.585 /208.062 |
| Reader | 11.850 /224.465 | 13.145 /167.430 |
| API host | 4.609 /196.914 | 5.196 /176.125 |

CPU is cumulative process user+system time from the last observed maximum; RSS is Linux `resourceUsage.maxRSS` in KiB converted to MiB. Sampling spans about471seconds/484seconds with deliberate pacing, prefix holds and faults. This is a workload-specific profiling lead, not a throughput comparison, exclusive-stage CPU attribution, simultaneous cluster-memory total, memory-recovery proof or optimization decision.

Keep Wire#15 action/onblock diagnostics explicit. Passed state assertions do not certify complete action decoding, whole Wire compatibility, AtomicAssets parity, WormDB, secondary-index projections, forks, process crashes, Bun, Rust execution or release readiness. Preserve the original bytes; publish scope-specific summaries alongside checksums. Local/container paths, process IDs and error diagnostics should be reviewed before public mirroring rather than silently altering the hashed originals.

Derived facts: `p191-acceptance-audit-facts-v2-20261021.json`, SHA256 `80067ee4a21e8e06e2adcaf9c340050f44faf222f7beeb4b469973a7386c90ef`.
