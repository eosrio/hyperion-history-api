param([ValidateSet('0ms','200ms')][string]$Interval,[string]$Stage)
$ErrorActionPreference='Stop'
$scratch='C:\Users\igorl\.codex\scratch'
$statePath=Join-Path $scratch 'es198-clock-state.json'
$state=Get-Content $statePath -Raw | ConvertFrom-Json
$ins= @(docker inspect $state.containerId | ConvertFrom-Json)[0]
if($LASTEXITCODE -ne 0){throw 'Cannot inspect fixture'}
if($ins.Config.Labels.'io.eosrio.qualifier' -ne 'es198-clock' -or $ins.Config.Labels.'io.eosrio.run' -ne $state.run -or $ins.Name -ne ('/'+$state.container)){throw 'Fixture ownership mismatch'}
$vol=@(docker volume inspect $state.volume | ConvertFrom-Json)[0]
if($LASTEXITCODE -ne 0 -or $vol.Labels.'io.eosrio.run' -ne $state.run -or $vol.Labels.'io.eosrio.qualifier' -ne 'es198-clock'){throw 'Volume ownership mismatch'}
$users=@(docker ps -a --no-trunc --filter "volume=$($state.volume)" --format '{{.ID}}')
if($LASTEXITCODE -ne 0 -or $users.Count -ne 1 -or $users[0] -ne $state.containerId){throw 'Unexpected volume consumer'}
$info=Invoke-RestMethod $state.url
if($info.cluster_uuid -ne $state.clusterUuid -or $info.cluster_name -ne $state.clusterName -or $info.version.number -ne '9.5.5'){throw 'Cluster identity mismatch'}
$cat=Invoke-WebRequest ($state.url+'/_cat/indices/hyp-es955-*?format=json&expand_wildcards=all')
$indices=ConvertFrom-Json -InputObject $cat.Content -NoEnumerate
if($indices.Count -ne 0){throw 'Probe indices left behind'}
Invoke-RestMethod ($state.url+'/_nodes/settings') | ConvertTo-Json -Depth 50 | Set-Content (Join-Path $scratch "es198-clock-before-$Stage-settings.json")
docker stop --timeout 20 $state.containerId | Out-Null
if($LASTEXITCODE -ne 0){throw 'Stop failed'}
docker rm $state.containerId | Out-Null
if($LASTEXITCODE -ne 0){throw 'Remove failed'}
$dockerArgs=@('run','-d','--name',$state.container,'--label','io.eosrio.qualifier=es198-clock','--label',"io.eosrio.run=$($state.run)",'--cpus','4','--memory','3g','-p','127.0.0.1::9200','--mount',"type=volume,src=$($state.volume),dst=/usr/share/elasticsearch/data",'-e',"cluster.name=$($state.clusterName)",'-e',"node.name=$($state.container)",'-e','discovery.type=single-node','-e','xpack.security.enabled=false','-e','xpack.security.autoconfiguration.enabled=false','-e','xpack.ml.enabled=false','-e','ingest.geoip.downloader.enabled=false','-e','cluster.routing.allocation.disk.watermark.low=20gb','-e','cluster.routing.allocation.disk.watermark.high=10gb','-e','cluster.routing.allocation.disk.watermark.flood_stage=5gb','-e','ES_JAVA_OPTS=-Xms1g -Xmx1g','-e',"thread_pool.estimated_time_interval=$Interval",$state.image)
$cid=docker @dockerArgs
if($LASTEXITCODE -ne 0){throw 'Recreate failed'}
$state.containerId=$cid.Trim()
$port=docker port $state.containerId 9200/tcp
if($LASTEXITCODE -ne 0 -or $port -notmatch '^127\.0\.0\.1:\d+$'){throw 'Unexpected port binding'}
$state.url='http://'+$port.Trim()
$state | Add-Member -Force -NotePropertyName clockInterval -NotePropertyValue $Interval
$state | ConvertTo-Json -Depth 10 | Set-Content $statePath
$ready=$false
for($attempt=0;$attempt -lt 90;$attempt++){
    try{
        $next=Invoke-RestMethod $state.url -TimeoutSec 2
        if($next.cluster_uuid -ne $state.clusterUuid -or $next.cluster_name -ne $state.clusterName -or $next.version.number -ne '9.5.5'){throw 'Recreated cluster identity mismatch'}
        $ready=$true;break
    }catch{Start-Sleep -Milliseconds 500}
}
if(-not $ready){throw 'Readiness timeout'}
Copy-Item $statePath (Join-Path $scratch "es198-clock-$Stage-state.json")
$settings=Invoke-RestMethod ($state.url+'/_nodes/settings')
$settings | ConvertTo-Json -Depth 50 | Set-Content (Join-Path $scratch "es198-clock-$Stage-settings.json")
$node=@($settings.nodes.PSObject.Properties.Value)[0]
if($node.settings.thread_pool.estimated_time_interval -ne $Interval){throw 'Clock setting not applied'}
$dockerArgs | ConvertTo-Json | Set-Content (Join-Path $scratch "es198-clock-$Stage-docker-args.json")
docker cp (Join-Path $scratch 'EsBulkClockProbe.java') "$($state.containerId):/tmp/EsBulkClockProbe.java"
if($LASTEXITCODE -ne 0){throw 'Copy failed'}
Write-Output "Ready $Stage clock=$Interval cluster=$($state.clusterUuid)"
