import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {open, readFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';

const [statePath, outputPath] = process.argv.slice(2);
assert.ok(statePath && outputPath, 'state and new output path required');
const state = JSON.parse(await readFile(statePath, 'utf8'));
assert.match(state.url, /^http:\/\/127\.0\.0\.1:\d+$/);
assert.match(state.clusterName, /^hyperion-es198-[a-z0-9]+$/);
const output = await open(outputPath, 'wx');
const owner = randomUUID();
const index = `hyp-es955-${owner.replaceAll('-', '').slice(0,12)}-clock`;
const report = {started: new Date().toISOString(), state, index, owner, samples: [], cleanup: null};
let attempted = false;
async function request(path, method = 'GET', body) {
    const start = performance.now();
    const response = await fetch(state.url + path, {method, headers: {'content-type': path === '/_bulk' ? 'application/x-ndjson' : 'application/json'}, body, signal: AbortSignal.timeout(45000)});
    const text = await response.text();
    const wallMs = performance.now() - start;
    assert.ok(response.ok, `${response.status}: ${text}`);
    return {body: JSON.parse(text), wallMs, raw: text};
}
async function identity() {
    const {body} = await request('/');
    assert.equal(body.version.number, '9.5.5');
    assert.equal(body.cluster_name, state.clusterName);
    if (state.clusterUuid) assert.equal(body.cluster_uuid, state.clusterUuid);
    return body;
}
try {
    report.server = await identity();
    const existing = await fetch(state.url+'/'+index,{method:'HEAD',signal:AbortSignal.timeout(5000)});
    assert.equal(existing.status,404,'index collision or unexpected HEAD status');
    attempted = true;
    await request('/'+index, 'PUT', JSON.stringify({settings: {number_of_shards: 1, number_of_replicas: 0, refresh_interval: '-1'}, mappings: {_meta: {clock_probe_owner: owner}, properties: {sequence: {type: 'integer'}}}}));
    const ready = await request('/_cluster/health/'+index+'?wait_for_status=green&timeout=30s');
    assert.equal(ready.body.timed_out, false);
    for (let i=0;i<100;i++) {
        const payload=JSON.stringify({index:{_index:index,_id:String(i)}})+'\n'+JSON.stringify({sequence:i})+'\n';
        const {body, wallMs, raw} = await request('/_bulk', 'POST', payload);
        assert.equal(body.errors,false); assert.equal(body.items.length,1);
        assert.equal(body.items[0].index.status,201); assert.equal(body.items[0].index._id,String(i));
        report.samples.push({sequence:i, wallMs, tookMs:body.took, anomalous:body.took>wallMs+5, raw});
    }
    report.anomalies=report.samples.filter(s=>s.anomalous).length;
    report.status=report.anomalies ? 'reproduced' : 'not-reproduced';
} catch(error) {report.status='failed';report.error=String(error.stack??error);}
finally {
    if(attempted) try {
        await identity();
        const {body:mapping} = await request('/'+index+'/_mapping');
        assert.equal(mapping[index].mappings._meta.clock_probe_owner,owner,'refusing unowned cleanup');
        await request('/'+index,'DELETE'); report.cleanup='deleted';
    } catch(error) {report.cleanup=String(error);report.status='failed';}
    report.completed=new Date().toISOString();
    try {await output.writeFile(JSON.stringify(report,null,2)+'\n');} finally {await output.close();}
}
console.log(JSON.stringify({status:report.status,anomalies:report.anomalies,samples:report.samples.length,cleanup:report.cleanup,error:report.error}));
process.exitCode=report.status==='reproduced'?1:report.status==='not-reproduced'?0:2;
