import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.UUID;
import java.util.regex.Pattern;

class EsBulkClockProbe {
    static HttpClient client;
    static String base, cluster, uuid;
    static String call(String path, String method, String body) throws Exception {
        var builder=HttpRequest.newBuilder(URI.create(base+path)).timeout(Duration.ofSeconds(45));
        builder.header("Content-Type",path.equals("/_bulk")?"application/x-ndjson":"application/json");
        var request=builder.method(method,body==null?HttpRequest.BodyPublishers.noBody():HttpRequest.BodyPublishers.ofString(body)).build();
        var response=client.send(request,HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()<200||response.statusCode()>=300)throw new Exception(response.statusCode()+": "+response.body());
        return response.body();
    }
    static boolean field(String body,String name,String value){return Pattern.compile("\""+Pattern.quote(name)+"\"\\s*:\\s*\""+Pattern.quote(value)+"\"").matcher(body).find();}
    static void identity() throws Exception {
        var info=call("/","GET",null);
        if(!field(info,"cluster_name",cluster)||!field(info,"cluster_uuid",uuid)||!field(info,"number","9.5.5"))throw new Exception("Unexpected fixture identity");
    }
    static String quote(String v){return "\""+v.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";}
    public static void main(String[] args)throws Exception {
        base=args[0];cluster=args[1];uuid=args[2];
        if(!base.equals("http://127.0.0.1:9200")||!cluster.matches("hyperion-es198-[a-z0-9]+"))throw new Exception("Not a dedicated local fixture");
        client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).version(HttpClient.Version.HTTP_1_1).build();
        var owner=UUID.randomUUID().toString();
        var index="hyp-es955-"+owner.replace("-","").substring(0,12)+"-javaclock";
        boolean created=false;int anomalies=0;int completed=0;String cleanup="not-created";String failure=null;
        System.out.println("{\"java\":"+quote(System.getProperty("java.version"))+",\"os\":"+quote(System.getProperty("os.name"))+",\"index\":"+quote(index)+"}");
        try {
            identity();
            call("/"+index,"PUT","{\"settings\":{\"number_of_shards\":1,\"number_of_replicas\":0,\"refresh_interval\":\"-1\"},\"mappings\":{\"_meta\":{\"clock_probe_owner\":\""+owner+"\"}}}");created=true;
            for(int i=0;i<100;i++) {
                var payload="{\"index\":{\"_index\":\""+index+"\",\"_id\":\""+i+"\"}}\n{\"sequence\":"+i+"}\n";
                long start=System.nanoTime();long date=System.currentTimeMillis();
                var response=call("/_bulk","POST",payload);
                double wallMs=(System.nanoTime()-start)/1e6;long dateMs=System.currentTimeMillis()-date;
                var matcher=Pattern.compile("\"took\"\\s*:\\s*(\\d+)").matcher(response);
                if(!matcher.find()||!Pattern.compile("\"errors\"\\s*:\\s*false").matcher(response).find()||!field(response,"_id",String.valueOf(i)))throw new Exception("Unexpected bulk response "+response);
                long took=Long.parseLong(matcher.group(1));boolean anomalous=took>wallMs+5;if(anomalous)anomalies++;completed++;
                System.out.println("{\"sequence\":"+i+",\"tookMs\":"+took+",\"wallMs\":"+wallMs+",\"dateMs\":"+dateMs+",\"anomalous\":"+anomalous+",\"raw\":"+quote(response)+"}");
            }
        } catch(Exception error){failure=error.toString();}
        finally {
            if(created)try {identity();var mapping=call("/"+index+"/_mapping","GET",null);if(!field(mapping,"clock_probe_owner",owner))throw new Exception("Unowned cleanup");call("/"+index,"DELETE",null);cleanup="deleted";}catch(Exception error){cleanup=error.toString();failure=cleanup;}
            client.close();
        }
        System.out.println("{\"status\":"+quote(failure!=null?"failed":anomalies>0?"reproduced":"not-reproduced")+",\"samples\":"+completed+",\"anomalies\":"+anomalies+",\"cleanup\":"+quote(cleanup)+",\"error\":"+(failure==null?"null":quote(failure))+"}");
        System.exit(failure!=null?2:anomalies>0?1:0);
    }
}
